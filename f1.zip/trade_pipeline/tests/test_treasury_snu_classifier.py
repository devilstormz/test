"""
Unit tests for TreasurySNUClassifier.
"""

import unittest
import pandas as pd
import numpy as np
from unittest.mock import patch, MagicMock

from trading_analytics_framework.trade_pipeline.treasury_snu_classifier import TreasurySNUClassifier


class TestTreasurySNUClassifier(unittest.TestCase):
    """Test cases for TreasurySNUClassifier."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.classifier = TreasurySNUClassifier()
        
        # Create sample test data
        self.sample_data = {
            'LegArg.IsSecured': [False, True, False, True],
            'LegArg.IsCollateralSwap': [True, False, True, False],
            'CollateralSwapType': ['Upgrade', 'Neutral', 'Upgrade', 'Neutral'],
            'DealAttr.ProjectName': ['PGI_Project1', 'Xmt_Project1', 'Other_Project', 'Other_Project'],
            'BondLqdty.Hqlalevel': [1, '2A', '2B', 3],
            'Book.System': ['K-E', 'K-E', 'K-E', 'K-E'],
            'Book': ['CMMM-CFSF', 'CMMM-CFSFA', 'Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['LO-0751464', 'LO-0751464', 'Other_CPTY', 'Other_CPTY'],
            'Leg.Type': ['REV', 'TRV', 'REV', 'TRV'],
            'isSFT': [True, True, False, False],
            'Cpty.IsInternal': [True, True, False, False],
            'BondLiquidityLevel': [1, '2A', '2B', 3],
            'Deal.BBG': [1000000, 2000000, 3000000, 4000000],
            'K': [500000, 600000, 700000, 800000]
        }
        
        self.df = pd.DataFrame(self.sample_data)
    
    def test_init(self):
        """Test classifier initialization."""
        classifier = TreasurySNUClassifier()
        self.assertIsNotNone(classifier)
    
    def test_classify_basic(self):
        """Test basic classification."""
        result = self.classifier.classify(self.df)
        
        # Check that all expected columns are present
        expected_cols = [
            'TreasurySNU_Source_Classification', 'TreasurySNU_Use_Classification',
            'TreasurySNU_Funding_Source_Use', 'TreasurySNU_Combined_Classification'
        ]
        for col in expected_cols:
            self.assertIn(col, result.columns)
        
        # Check that DataFrame length is preserved
        self.assertEqual(len(result), len(self.df))
    
    def test_source_classification(self):
        """Test source classification."""
        # Create data that should trigger different source classifications
        source_data = {
            'LegArg.IsSecured': [False, True, True, True, True, True, True, True],
            'LegArg.IsCollateralSwap': [True, True, True, True, False, False, False, False],
            'CollateralSwapType': ['Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Neutral', 'Neutral', 'Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['PGI_Project1', 'Xmt_Project1', 'Other_Project', 'Other_Project', 'Xmt_Project2', 'Other_Project', 'Other_Project', 'Other_Project'],
            'BondLqdty.Hqlalevel': [1, 1, 1, 4, 1, 1, 1, 1],
            'Book.System': ['K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E'],
            'Book': ['CMMM-CFSF', 'CMMM-CFSFA', 'Other_Book', 'Other_Book', 'Other_Book', 'CMMM-CFSF', 'CMMM-CFSFA', 'Other_Book'],
            'Deal.BSCpty': ['LO-0751464', 'LO-0751464', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'LO-0751464', 'LO-0751464', 'Other_CPTY'],
            'Leg.Type': ['REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV'],
            'isSFT': [True, True, True, True, True, True, True, True],
            'Cpty.IsInternal': [True, True, True, True, True, True, True, True],
            'BondLiquidityLevel': [1, 1, 1, 1, 1, 1, 1, 1],
            'Deal.BBG': [1000000, 2000000, 3000000, 4000000, 5000000, 6000000, 7000000, 8000000],
            'K': [500000, 600000, 700000, 800000, 900000, 1000000, 1100000, 1200000]
        }
        
        source_df = pd.DataFrame(source_data)
        result = self.classifier.classify(source_df)
        
        # Check specific source classifications
        unsecured_mask = source_df['LegArg.IsSecured'] == False
        self.assertIn('Unsecured Bond Borrows', 
                     result.loc[unsecured_mask, 'TreasurySNU_Source_Classification'].values)
        
        pgi_xmt_mask = (source_df['LegArg.IsCollateralSwap'] == True) & \
                      (source_df['CollateralSwapType'] == 'Upgrade') & \
                      (source_df['DealAttr.ProjectName'].str.startswith('PGI') | 
                       source_df['DealAttr.ProjectName'].str.startswith('Xmt'))
        self.assertIn('Using PGI/X-Mkts', 
                     result.loc[pgi_xmt_mask, 'TreasurySNU_Source_Classification'].values)
        
        non_hqla_mask = (source_df['LegArg.IsCollateralSwap'] == True) & \
                       (source_df['CollateralSwapType'] == 'Upgrade') & \
                       ~(source_df['DealAttr.ProjectName'].str.startswith('PGI') | 
                         source_df['DealAttr.ProjectName'].str.startswith('Xmt')) & \
                       ~source_df['BondLqdty.Hqlalevel'].isin([1, 2, 'A', '2B'])
        self.assertIn('Using other non-HQLA', 
                     result.loc[non_hqla_mask, 'TreasurySNU_Source_Classification'].values)
    
    def test_use_classification(self):
        """Test use classification."""
        # Create data that should trigger different use classifications
        use_data = {
            'LegArg.IsSecured': [True, True, True, True],
            'LegArg.IsCollateralSwap': [False, False, False, False],
            'CollateralSwapType': ['Neutral', 'Neutral', 'Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['Other_Project', 'Other_Project', 'Other_Project', 'Other_Project'],
            'BondLqdty.Hqlalevel': [1, 1, 1, 1],
            'Book.System': ['K-E', 'K-E', 'K-E', 'K-E'],
            'Book': ['Other_Book', 'Other_Book', 'Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY'],
            'Leg.Type': ['REV', 'TRV', 'REV', 'TRV'],
            'isSFT': [True, True, True, False],
            'Cpty.IsInternal': [True, True, False, True],
            'BondLiquidityLevel': [1, '2A', '2B', 3],
            'Deal.BBG': [1000000, 2000000, 3000000, 4000000],
            'K': [500000, 600000, 700000, 800000]
        }
        
        use_df = pd.DataFrame(use_data)
        result = self.classifier.classify(use_df)
        
        # Check specific use classifications
        reverse_repo_mask = use_df['Leg.Type'].isin(['REV', 'TRV'])
        self.assertIn('Reverse Repo financing', 
                     result.loc[reverse_repo_mask, 'TreasurySNU_Use_Classification'].values)
        
        hqla_mask = (use_df['Leg.Type'].isin(['REV', 'TRV'])) & \
                   (use_df['isSFT'] == True) & \
                   (use_df['Cpty.IsInternal'] == True) & \
                   use_df['BondLiquidityLevel'].isin([1, '2A', '2B']) & \
                   (use_df['LegArg.IsCollateralSwap'] == False)
        self.assertIn('HQLA', 
                     result.loc[hqla_mask, 'TreasurySNU_Use_Classification'].values)
        
        non_hqla_mask = (use_df['Leg.Type'].isin(['REV', 'TRV'])) & \
                       (use_df['isSFT'] == True) & \
                       (use_df['Cpty.IsInternal'] == True) & \
                       ~use_df['BondLiquidityLevel'].isin([1, '2A', '2B']) & \
                       (use_df['LegArg.IsCollateralSwap'] == False)
        self.assertIn('Non-HQLA', 
                     result.loc[non_hqla_mask, 'TreasurySNU_Use_Classification'].values)
    
    def test_abcp_classification(self):
        """Test ABCP classification."""
        # Create data for ABCP classification
        abcp_data = {
            'LegArg.IsSecured': [True, True],
            'LegArg.IsCollateralSwap': [False, False],
            'CollateralSwapType': ['Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['Other_Project', 'Other_Project'],
            'BondLqdty.Hqlalevel': [1, 1],
            'Book.System': ['K-E', 'K-E'],
            'Book': ['CMMM-CFSF', 'CMMM-CFSFA'],
            'Deal.BSCpty': ['LO-0751464', 'LO-0751464'],
            'Leg.Type': ['REV', 'REV'],
            'isSFT': [True, True],
            'Cpty.IsInternal': [True, True],
            'BondLiquidityLevel': [1, 1],
            'Deal.BBG': [1000000, 2000000],
            'K': [500000, 600000]
        }
        
        abcp_df = pd.DataFrame(abcp_data)
        result = self.classifier.classify(abcp_df)
        
        # Check ABCP classifications
        cfsf_mask = abcp_df['Book'] == 'CMMM-CFSF'
        cfsfa_mask = abcp_df['Book'] == 'CMMM-CFSFA'
        
        self.assertIn('ABCP (using PGI pledge)', 
                     result.loc[cfsf_mask, 'TreasurySNU_Source_Classification'].values)
        self.assertIn('ABCP (using Rev Repo asset pledge)', 
                     result.loc[cfsfa_mask, 'TreasurySNU_Source_Classification'].values)
    
    def test_secured_x_mkt_notes(self):
        """Test secured X-Market notes classification."""
        # Create data for secured X-Market notes
        x_mkt_data = {
            'LegArg.IsSecured': [True],
            'LegArg.IsCollateralSwap': [False],
            'CollateralSwapType': ['Neutral'],
            'DealAttr.ProjectName': ['Xmt_Project1'],
            'BondLqdty.Hqlalevel': [1],
            'Book.System': ['K-E'],
            'Book': ['Other_Book'],
            'Deal.BSCpty': ['Other_CPTY'],
            'Leg.Type': ['REV'],
            'isSFT': [True],
            'Cpty.IsInternal': [True],
            'BondLiquidityLevel': [1],
            'Deal.BBG': [1000000],
            'K': [500000]
        }
        
        x_mkt_df = pd.DataFrame(x_mkt_data)
        result = self.classifier.classify(x_mkt_df)
        
        # Check that BBG + K != 0 triggers secured X-Market notes
        self.assertIn('Secured X-Mkt Notes', 
                     result['TreasurySNU_Source_Classification'].values)
    
    def test_funding_source_use_determination(self):
        """Test Funding Source/Use determination."""
        result = self.classifier.classify(self.df)
        
        # Check that Funding Source/Use column is populated
        funding_source_use_values = result['TreasurySNU_Funding_Source_Use'].values
        expected_values = ['Source', 'Use']
        
        for value in funding_source_use_values:
            self.assertIn(value, expected_values + ['Other'])
    
    def test_combined_classification(self):
        """Test combined classification column."""
        result = self.classifier.classify(self.df)
        
        # Check that combined classification shows the actual classification for each row
        source_mask = result['TreasurySNU_Funding_Source_Use'] == 'Source'
        use_mask = result['TreasurySNU_Funding_Source_Use'] == 'Use'
        
        # For source rows, combined classification should match source classification
        if source_mask.any():
            self.assertTrue(all(
                result.loc[source_mask, 'TreasurySNU_Combined_Classification'] == 
                result.loc[source_mask, 'TreasurySNU_Source_Classification']
            ))
        
        # For use rows, combined classification should match use classification
        if use_mask.any():
            self.assertTrue(all(
                result.loc[use_mask, 'TreasurySNU_Combined_Classification'] == 
                result.loc[use_mask, 'TreasurySNU_Use_Classification']
            ))
    
    def test_missing_columns_error_handling(self):
        """Test error handling for missing columns."""
        # Create data with missing required columns
        incomplete_df = self.df.drop(columns=['LegArg.IsSecured', 'LegArg.IsCollateralSwap'])
        
        result = self.classifier.classify(incomplete_df)
        
        # Check that error columns are populated
        error_cols = ['TreasurySNU_Source_Classification', 'TreasurySNU_Use_Classification',
                     'TreasurySNU_Funding_Source_Use', 'TreasurySNU_Combined_Classification']
        
        for col in error_cols:
            self.assertIn('Error - Missing Column', result[col].values)
    
    def test_edge_cases(self):
        """Test edge cases and boundary conditions."""
        # Test with empty DataFrame
        empty_df = pd.DataFrame()
        result = self.classifier.classify(empty_df)
        self.assertEqual(len(result), 0)
        
        # Test with single row
        single_row_df = self.df.iloc[:1]
        result = self.classifier.classify(single_row_df)
        self.assertEqual(len(result), 1)
        
        # Test with all null values
        null_df = self.df.copy()
        null_df['LegArg.IsSecured'] = None
        null_df['LegArg.IsCollateralSwap'] = None
        
        result = self.classifier.classify(null_df)
        # Should handle nulls gracefully
        self.assertEqual(len(result), len(null_df))
    
    def test_other_classification(self):
        """Test 'Other' classification for unmatched cases."""
        # Create data that doesn't match any specific conditions
        other_data = {
            'LegArg.IsSecured': [True, True],
            'LegArg.IsCollateralSwap': [False, False],
            'CollateralSwapType': ['Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['Other_Project', 'Other_Project'],
            'BondLqdty.Hqlalevel': [1, 1],
            'Book.System': ['Other_System', 'Other_System'],
            'Book': ['Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['Other_CPTY', 'Other_CPTY'],
            'Leg.Type': ['Other_Type', 'Other_Type'],
            'isSFT': [False, False],
            'Cpty.IsInternal': [False, False],
            'BondLiquidityLevel': [1, 1],
            'Deal.BBG': [1000000, 2000000],
            'K': [500000, 600000]
        }
        
        other_df = pd.DataFrame(other_data)
        result = self.classifier.classify(other_df)
        
        # Check that 'Other' classifications are applied
        self.assertIn('Other', result['TreasurySNU_Source_Classification'].values)
        self.assertIn('Other', result['TreasurySNU_Use_Classification'].values)
    
    def test_performance_large_dataset(self):
        """Test performance with larger dataset."""
        # Create larger dataset
        large_df = pd.concat([self.df] * 100, ignore_index=True)
        
        import time
        start_time = time.time()
        result = self.classifier.classify(large_df)
        end_time = time.time()
        
        # Check that processing completed successfully
        self.assertEqual(len(result), len(large_df))
        
        # Check that processing time is reasonable (less than 5 seconds for 400 rows)
        processing_time = end_time - start_time
        self.assertLess(processing_time, 5.0)
    
    def test_data_consistency(self):
        """Test data consistency across classifications."""
        result = self.classifier.classify(self.df)
        
        # Check that all classification columns are strings
        classification_cols = ['TreasurySNU_Source_Classification', 'TreasurySNU_Use_Classification',
                             'TreasurySNU_Funding_Source_Use', 'TreasurySNU_Combined_Classification']
        
        for col in classification_cols:
            self.assertTrue(pd.api.types.is_string_dtype(result[col]))
        
        # Check that no null values in classification columns
        for col in classification_cols:
            self.assertFalse(result[col].isna().any())
    
    def test_specific_classification_validation(self):
        """Test validation of specific classifications."""
        # Test unsecured bond borrows
        unsecured_data = {
            'LegArg.IsSecured': [False],
            'LegArg.IsCollateralSwap': [False],
            'CollateralSwapType': ['Neutral'],
            'DealAttr.ProjectName': ['Other_Project'],
            'BondLqdty.Hqlalevel': [1],
            'Book.System': ['K-E'],
            'Book': ['Other_Book'],
            'Deal.BSCpty': ['Other_CPTY'],
            'Leg.Type': ['REV'],
            'isSFT': [True],
            'Cpty.IsInternal': [True],
            'BondLiquidityLevel': [1],
            'Deal.BBG': [1000000],
            'K': [500000]
        }
        
        unsecured_df = pd.DataFrame(unsecured_data)
        result = self.classifier.classify(unsecured_df)
        
        self.assertEqual(result.loc[0, 'TreasurySNU_Source_Classification'], 'Unsecured Bond Borrows')
        self.assertEqual(result.loc[0, 'TreasurySNU_Funding_Source_Use'], 'Source')
        self.assertEqual(result.loc[0, 'TreasurySNU_Combined_Classification'], 'Unsecured Bond Borrows')
    
    def test_comprehensive_classification_coverage(self):
        """Test comprehensive coverage of all classifications."""
        # Create data covering all possible classifications
        comprehensive_data = {
            'LegArg.IsSecured': [False, True, True, True, True, True, True, True, True, True, True, True, True, True],
            'LegArg.IsCollateralSwap': [True, True, True, True, True, True, True, True, False, False, False, False, False, False],
            'CollateralSwapType': ['Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['PGI_Project1', 'Xmt_Project1', 'Other_Project', 'Other_Project', 'Other_Project', 'Other_Project', 'Other_Project', 'Other_Project', 'Xmt_Project2', 'Other_Project', 'Other_Project', 'Other_Project', 'Other_Project', 'Other_Project'],
            'BondLqdty.Hqlalevel': [1, 1, 1, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            'Book.System': ['K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E'],
            'Book': ['CMMM-CFSF', 'CMMM-CFSFA', 'Other_Book', 'Other_Book', 'Other_Book', 'Other_Book', 'Other_Book', 'Other_Book', 'Other_Book', 'CMMM-CFSF', 'CMMM-CFSFA', 'Other_Book', 'Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['LO-0751464', 'LO-0751464', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'LO-0751464', 'LO-0751464', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY'],
            'Leg.Type': ['REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV', 'REV'],
            'isSFT': [True, True, True, True, True, True, True, True, True, True, True, True, True, True],
            'Cpty.IsInternal': [True, True, True, True, True, True, True, True, True, True, True, True, True, True],
            'BondLiquidityLevel': [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            'Deal.BBG': [1000000, 2000000, 3000000, 4000000, 5000000, 6000000, 7000000, 8000000, 9000000, 10000000, 11000000, 12000000, 13000000, 14000000],
            'K': [500000, 600000, 700000, 800000, 900000, 1000000, 1100000, 1200000, 1300000, 1400000, 1500000, 1600000, 1700000, 1800000]
        }
        
        comprehensive_df = pd.DataFrame(comprehensive_data)
        result = self.classifier.classify(comprehensive_df)
        
        # Check that all expected classifications are present
        expected_source_classifications = [
            'Unsecured Bond Borrows', 'Coll. Swap, upgrades (PGI & other non-HQLA)',
            'Using PGI/X-Mkts', 'Using other non-HQLA', 'Secured X-Mkt Notes',
            'ABCP (using PGI pledge)', 'ABCP (using Rev Repo asset pledge)',
            'Secured deposit (using securities pledge)'
        ]
        
        expected_use_classifications = [
            'Reverse Repo financing', 'HQLA', 'Non-HQLA'
        ]
        
        for classification in expected_source_classifications:
            self.assertIn(classification, result['TreasurySNU_Source_Classification'].values)
        
        for classification in expected_use_classifications:
            self.assertIn(classification, result['TreasurySNU_Use_Classification'].values)
    
    def test_boolean_logic_validation(self):
        """Test validation of boolean logic in conditions."""
        # Test that boolean conditions work correctly
        test_data = {
            'LegArg.IsSecured': [False, True, True, True],
            'LegArg.IsCollateralSwap': [True, True, False, False],
            'CollateralSwapType': ['Upgrade', 'Neutral', 'Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['Other_Project', 'Other_Project', 'Other_Project', 'Other_Project'],
            'BondLqdty.Hqlalevel': [1, 1, 1, 1],
            'Book.System': ['K-E', 'K-E', 'K-E', 'K-E'],
            'Book': ['Other_Book', 'Other_Book', 'Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY'],
            'Leg.Type': ['REV', 'REV', 'REV', 'REV'],
            'isSFT': [True, True, True, True],
            'Cpty.IsInternal': [True, True, True, True],
            'BondLiquidityLevel': [1, 1, 1, 1],
            'Deal.BBG': [1000000, 2000000, 3000000, 4000000],
            'K': [500000, 600000, 700000, 800000]
        }
        
        test_df = pd.DataFrame(test_data)
        result = self.classifier.classify(test_df)
        
        # Check that boolean conditions are evaluated correctly
        unsecured_mask = test_df['LegArg.IsSecured'] == False
        self.assertIn('Unsecured Bond Borrows', 
                     result.loc[unsecured_mask, 'TreasurySNU_Source_Classification'].values)
        
        collateral_swap_mask = test_df['LegArg.IsCollateralSwap'] == True
        self.assertIn('Coll. Swap, upgrades (PGI & other non-HQLA)', 
                     result.loc[collateral_swap_mask, 'TreasurySNU_Source_Classification'].values)
    
    def test_string_pattern_matching(self):
        """Test string pattern matching in conditions."""
        # Test that string pattern matching works correctly
        pattern_data = {
            'LegArg.IsSecured': [True, True, True, True],
            'LegArg.IsCollateralSwap': [True, True, True, True],
            'CollateralSwapType': ['Upgrade', 'Upgrade', 'Upgrade', 'Upgrade'],
            'DealAttr.ProjectName': ['PGI_Project1', 'Xmt_Project1', 'PGI_Project2', 'Xmt_Project2'],
            'BondLqdty.Hqlalevel': [1, 1, 1, 1],
            'Book.System': ['K-E', 'K-E', 'K-E', 'K-E'],
            'Book': ['Other_Book', 'Other_Book', 'Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY'],
            'Leg.Type': ['REV', 'REV', 'REV', 'REV'],
            'isSFT': [True, True, True, True],
            'Cpty.IsInternal': [True, True, True, True],
            'BondLiquidityLevel': [1, 1, 1, 1],
            'Deal.BBG': [1000000, 2000000, 3000000, 4000000],
            'K': [500000, 600000, 700000, 800000]
        }
        
        pattern_df = pd.DataFrame(pattern_data)
        result = self.classifier.classify(pattern_df)
        
        # Check that PGI and Xmt patterns are matched correctly
        pgi_mask = pattern_df['DealAttr.ProjectName'].str.startswith('PGI')
        xmt_mask = pattern_df['DealAttr.ProjectName'].str.startswith('Xmt')
        
        self.assertIn('Using PGI/X-Mkts', 
                     result.loc[pgi_mask, 'TreasurySNU_Source_Classification'].values)
        self.assertIn('Using PGI/X-Mkts', 
                     result.loc[xmt_mask, 'TreasurySNU_Source_Classification'].values)


if __name__ == '__main__':
    unittest.main()
