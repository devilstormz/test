"""
Unit tests for BondAssetClassificationEngine.
"""

import unittest
import pandas as pd
import numpy as np
import tempfile
import os
from unittest.mock import patch, MagicMock

from trading_analytics_framework.trade_pipeline.bond_asset_classification_engine import BondAssetClassificationEngine


class TestBondAssetClassificationEngine(unittest.TestCase):
    """Test cases for BondAssetClassificationEngine."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.engine = BondAssetClassificationEngine(debug_mode=False)
        self.engine_debug = BondAssetClassificationEngine(debug_mode=True)
        
        # Create sample test data
        self.sample_data = {
            'BondHaircut.AssetClass': ['Govt', 'Govt', 'EM', 'ABS', 'MBS', 'SSA', 'Own Issued Debt', 'N/A'],
            'Bond.IssuerCode': ['UKT001', 'US123', 'BR789', 'CLO001', 'MBS001', 'MUNI001', 'COVERED001', 'TRIPARTY001'],
            'Bond.Issuer.Name': ['UK Treasury', 'United States Treasury', 'Brazil', 'CLO Issuer', 'MBS Issuer', 
                                'Municipal Corp', 'Covered Bond Issuer', 'Triparty System'],
            'Bond.Country': ['GBR', 'USA', 'BRA', 'USA', 'USA', 'USA', 'DEU', 'USA'],
            'Bond.CRNCY': ['GBP', 'USD', 'BRL', 'USD', 'USD', 'USD', 'EUR', 'USD'],
            'Bond.Desc': ['UK Gilt 2%', 'UST 10Y', 'Brazil Bond', 'CLO 2023-1', 'RMBS 2023', 
                         'Municipal Bond', 'Covered Bond', 'Triparty Collateral'],
            'Bond.IGFlag': [True, True, False, True, True, True, True, True],
            'Bond.RtgAvg': ['AAA', 'AAA', 'BB', 'A', 'AA', 'AA', 'AA', 'NR'],
            'Bond.IsMuni': [False, False, False, False, False, True, False, False],
            'Bond.IsAgency': [False, False, False, False, False, False, False, False],
            'Bond.SecurityType': ['Govt', 'Govt', 'Corp', 'ABS', 'MBS', 'Muni', 'Covered', 'Unknown'],
            'Bond.ProgramType': [None, None, None, None, None, None, None, None],
            'Bond.SourceSystem': ['Internal', 'Internal', 'Internal', 'Internal', 'Internal', 
                                 'Internal', 'Internal', 'Triparty']
        }
        
        self.df = pd.DataFrame(self.sample_data)
    
    def test_init(self):
        """Test engine initialization."""
        engine = BondAssetClassificationEngine(debug_mode=True)
        self.assertTrue(engine.debug_mode)
        
        engine = BondAssetClassificationEngine(debug_mode=False)
        self.assertFalse(engine.debug_mode)
    
    def test_classify_bonds_success(self):
        """Test successful bond classification."""
        result = self.engine.classify_bonds(self.df)
        
        # Check that all required columns are present
        expected_cols = ['Classification_Level_1', 'Classification_Level_2', 
                        'Classification_Level_3', 'Classification_Level_4']
        for col in expected_cols:
            self.assertIn(col, result.columns)
        
        # Check that no rows have 'Mapping Failed' for Level 1
        self.assertNotIn('Mapping Failed', result['Classification_Level_1'].values)
        
        # Check specific classifications
        uk_gilt_mask = result['Bond.Desc'] == 'UK Gilt 2%'
        self.assertIn('UK Gilts', result.loc[uk_gilt_mask, 'Classification_Level_2'].values)
        
        ust_mask = result['Bond.Desc'] == 'UST 10Y'
        self.assertIn('UST', result.loc[ust_mask, 'Classification_Level_2'].values)
    
    def test_classify_bonds_missing_columns(self):
        """Test classification with missing required columns."""
        incomplete_df = self.df.drop(columns=['Bond.Country', 'Bond.CRNCY'])
        
        with self.assertRaises(ValueError) as context:
            self.engine.classify_bonds(incomplete_df)
        
        self.assertIn('Missing required columns', str(context.exception))
    
    def test_dynamic_naming_em(self):
        """Test EM dynamic naming with IG/Non-IG suffix."""
        # Create test data with EM bonds
        em_data = {
            'BondHaircut.AssetClass': ['EM', 'EM'],
            'Bond.Country': ['BRA', 'BRA'],
            'Bond.CRNCY': ['BRL', 'BRL'],
            'Bond.Desc': ['Brazil Bond IG', 'Brazil Bond Non-IG'],
            'Bond.IGFlag': [True, False],
            'Bond.RtgAvg': ['AA', 'BB'],
            'Bond.IsMuni': [False, False],
            'Bond.IsAgency': [False, False],
            'Bond.SecurityType': ['Corp', 'Corp'],
            'Bond.ProgramType': [None, None],
            'Bond.SourceSystem': ['Internal', 'Internal'],
            'Bond.IssuerCode': ['BR001', 'BR002'],
            'Bond.Issuer.Name': ['Brazil Corp', 'Brazil Corp']
        }
        
        em_df = pd.DataFrame(em_data)
        result = self.engine.classify_bonds(em_df)
        
        # Check EM_IG and EM_Non-IG classifications
        ig_mask = result['Bond.IGFlag'] == True
        non_ig_mask = result['Bond.IGFlag'] == False
        
        self.assertIn('EM_IG', result.loc[ig_mask, 'Classification_Level_2'].values)
        self.assertIn('EM_Non-IG', result.loc[non_ig_mask, 'Classification_Level_2'].values)
    
    def test_dynamic_naming_clo(self):
        """Test CLO dynamic naming with currency, IG flag, and rating."""
        # Create test data with CLO bonds
        clo_data = {
            'BondHaircut.AssetClass': ['ABS', 'ABS'],
            'Bond.Country': ['USA', 'USA'],
            'Bond.CRNCY': ['USD', 'EUR'],
            'Bond.Desc': ['CLO 2023-1', 'CLO 2023-2'],
            'Bond.IGFlag': [True, False],
            'Bond.RtgAvg': ['A', 'BB'],
            'Bond.IsMuni': [False, False],
            'Bond.IsAgency': [False, False],
            'Bond.SecurityType': ['ABS', 'ABS'],
            'Bond.ProgramType': [None, None],
            'Bond.SourceSystem': ['Internal', 'Internal'],
            'Bond.IssuerCode': ['CLO001', 'CLO002'],
            'Bond.Issuer.Name': ['CLO Issuer', 'CLO Issuer']
        }
        
        clo_df = pd.DataFrame(clo_data)
        result = self.engine.classify_bonds(clo_df)
        
        # Check CLO dynamic naming
        clo_mask = result['Bond.Desc'].str.contains('CLO')
        clo_classifications = result.loc[clo_mask, 'Classification_Level_3'].values
        
        self.assertTrue(any('CLO_USD_IG_A' in str(classification) for classification in clo_classifications))
        self.assertTrue(any('CLO_EUR_NonIG_BB' in str(classification) for classification in clo_classifications))
    
    def test_debug_mode(self):
        """Test debug mode functionality."""
        result = self.engine_debug.classify_bonds(self.df)
        
        # Check that debug columns are added
        debug_cols = [col for col in result.columns if col.startswith('Debug_')]
        self.assertGreater(len(debug_cols), 0)
        
        # Check specific debug columns
        expected_debug_cols = ['Debug_HasCountry', 'Debug_HasCurrency', 'Debug_ValidAssetClass']
        for col in expected_debug_cols:
            self.assertIn(col, result.columns)
    
    def test_get_failed_mappings(self):
        """Test failed mappings identification."""
        # Add some problematic data
        problematic_data = self.sample_data.copy()
        problematic_data['BondHaircut.AssetClass'].extend(['InvalidClass', ''])
        problematic_data['Bond.Country'].extend(['', 'XXX'])
        problematic_data['Bond.Desc'].extend(['', 'Unknown Bond'])
        
        problematic_df = pd.DataFrame(problematic_data)
        result = self.engine.classify_bonds(problematic_df)
        
        failed_mappings = self.engine.get_failed_mappings(result)
        
        # Should have some failed mappings
        self.assertGreater(len(failed_mappings), 0)
        
        # Check that failed mappings contain 'Mapping Failed'
        classification_cols = [col for col in failed_mappings.columns if col.startswith('Classification_Level_')]
        for col in classification_cols:
            self.assertIn('Mapping Failed', failed_mappings[col].values)
    
    def test_get_classification_summary(self):
        """Test classification summary generation."""
        result = self.engine.classify_bonds(self.df)
        summary = self.engine.get_classification_summary(result)
        
        # Check that summary contains all levels
        expected_levels = ['Level_1', 'Level_2', 'Level_3', 'Level_4']
        for level in expected_levels:
            self.assertIn(level, summary)
            self.assertIsInstance(summary[level], pd.DataFrame)
        
        # Check summary structure
        for level_data in summary.values():
            self.assertIn('Count', level_data.columns)
            self.assertIn('Percentage', level_data.columns)
    
    def test_validate_classification(self):
        """Test classification validation."""
        result = self.engine.classify_bonds(self.df)
        validation = self.engine.validate_classification(result)
        
        # Check validation structure
        expected_keys = ['total_bonds', 'unclassified_bonds', 'classification_coverage', 'potential_issues']
        for key in expected_keys:
            self.assertIn(key, validation)
        
        # Check total bonds count
        self.assertEqual(validation['total_bonds'], len(self.df))
    
    def test_classify_from_excel(self):
        """Test classification from Excel file."""
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp_file:
            # Create Excel file
            self.df.to_excel(tmp_file.name, index=False)
            
            try:
                result = self.engine.classify_from_excel(tmp_file.name)
                
                # Check that classification was successful
                self.assertIn('Classification_Level_1', result.columns)
                self.assertEqual(len(result), len(self.df))
                
            finally:
                # Clean up
                os.unlink(tmp_file.name)
    
    def test_export_to_excel(self):
        """Test export to Excel functionality."""
        result = self.engine.classify_bonds(self.df)
        
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp_file:
            try:
                self.engine.export_to_excel(result, tmp_file.name)
                
                # Check that file was created
                self.assertTrue(os.path.exists(tmp_file.name))
                
                # Check file size
                self.assertGreater(os.path.getsize(tmp_file.name), 0)
                
            finally:
                # Clean up
                os.unlink(tmp_file.name)
    
    def test_export_to_excel_with_debug(self):
        """Test export to Excel with debug columns."""
        result = self.engine_debug.classify_bonds(self.df)
        
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp_file:
            try:
                self.engine_debug.export_to_excel(result, tmp_file.name, include_debug=True)
                
                # Check that file was created
                self.assertTrue(os.path.exists(tmp_file.name))
                
            finally:
                # Clean up
                os.unlink(tmp_file.name)
    
    def test_performance_large_dataset(self):
        """Test performance with larger dataset."""
        # Create larger dataset
        large_df = pd.concat([self.df] * 100, ignore_index=True)
        
        import time
        start_time = time.time()
        result = self.engine.classify_bonds(large_df)
        end_time = time.time()
        
        # Check that processing completed successfully
        self.assertEqual(len(result), len(large_df))
        
        # Check that processing time is reasonable (less than 5 seconds for 800 rows)
        processing_time = end_time - start_time
        self.assertLess(processing_time, 5.0)
    
    def test_edge_cases(self):
        """Test edge cases and boundary conditions."""
        # Test with empty DataFrame
        empty_df = pd.DataFrame()
        with self.assertRaises(ValueError):
            self.engine.classify_bonds(empty_df)
        
        # Test with single row
        single_row_df = self.df.iloc[:1]
        result = self.engine.classify_bonds(single_row_df)
        self.assertEqual(len(result), 1)
        
        # Test with all null values in key columns
        null_df = self.df.copy()
        null_df['Bond.Country'] = None
        null_df['Bond.Desc'] = None
        
        result = self.engine.classify_bonds(null_df)
        # Should still complete without error
        self.assertEqual(len(result), len(null_df))
    
    def test_specific_classifications(self):
        """Test specific classification scenarios."""
        # Test French OAT classification
        oat_data = {
            'BondHaircut.AssetClass': ['Govt'],
            'Bond.Country': ['FRA'],
            'Bond.CRNCY': ['EUR'],
            'Bond.Desc': ['French OAT 1%'],
            'Bond.IGFlag': [True],
            'Bond.RtgAvg': ['AAA'],
            'Bond.IsMuni': [False],
            'Bond.IsAgency': [False],
            'Bond.SecurityType': ['Govt'],
            'Bond.ProgramType': [None],
            'Bond.SourceSystem': ['Internal'],
            'Bond.IssuerCode': ['FR001'],
            'Bond.Issuer.Name': ['French Govt']
        }
        
        oat_df = pd.DataFrame(oat_data)
        result = self.engine.classify_bonds(oat_df)
        
        self.assertIn('French OATs', result['Classification_Level_4'].values)
        self.assertIn('EGB Core', result['Classification_Level_3'].values)
        self.assertIn('EGB', result['Classification_Level_2'].values)
    
    def test_hierarchical_classification_order(self):
        """Test that hierarchical classification follows correct order."""
        result = self.engine.classify_bonds(self.df)
        
        # Check that Level 4 is more specific than Level 3
        level4_values = result['Classification_Level_4'].value_counts()
        level3_values = result['Classification_Level_3'].value_counts()
        
        # Level 4 should have more specific classifications (fewer unique values)
        self.assertLessEqual(len(level4_values), len(level3_values))


if __name__ == '__main__':
    unittest.main()
