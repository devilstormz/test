"""
Unit tests for MarketValueCalculator.
"""

import unittest
import pandas as pd
import numpy as np
from unittest.mock import patch, MagicMock

from trading_analytics_framework.trade_pipeline.market_value_calculator import (
    MarketValueCalculator, MarketValueEnrichmentConfig, ProductType, TradeDirection, SystemType
)


class TestMarketValueCalculator(unittest.TestCase):
    """Test cases for MarketValueCalculator."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.config = MarketValueEnrichmentConfig()
        self.calculator = MarketValueCalculator(self.config)
        
        # Create sample test data
        self.sample_data = {
            'PRD': ['CASH_DEPOSIT', 'REPO', 'GOVERNMENT_BOND', 'INTEREST_RATE_SWAP', 'CROSS_CURRENCY_SWAP'],
            'CCY': ['EUR', 'USD', 'GBP', 'EUR', 'USD'],
            'Leg.PayRec': ['Pay', 'Receive', 'Pay', 'Receive', 'Pay'],
            'Leg.Type': ['Deposit', 'Repo', 'Buy', 'Swap', 'FX_Swap'],
            'Leg.StartCash': [1000000, None, None, None, 2000000],
            'LegArg.Notional': [1000000, 2000000, 500000, 1000000, 2000000],
            'FX': [1.0, 1.1, 1.2, 1.0, 1.1],
            'PoolFactor': [1.0, 1.0, 0.95, 1.0, 1.0],
            'Mkt Price of security': [1.0, 1.0, 1.05, 1.0, 1.0],
            'system': ['B-E', 'MAG', 'B-E', 'MAG', 'B-E'],
            'Bond.Currency': ['EUR', 'USD', 'GBP', 'EUR', 'USD']
        }
        
        self.df = pd.DataFrame(self.sample_data)
    
    def test_init(self):
        """Test calculator initialization."""
        calculator = MarketValueCalculator()
        self.assertIsNotNone(calculator.config)
        
        calculator = MarketValueCalculator(self.config)
        self.assertEqual(calculator.config, self.config)
    
    def test_calculate_market_values_basic(self):
        """Test basic market value calculation."""
        result = self.calculator.calculate_market_values(self.df)
        
        # Check that all expected columns are present
        expected_cols = [
            'Product Type Bucket', 'Cash CCY', 'Security CCY', 'Cash Amt', 'Security Amt',
            'EUR Cash Amt', 'EUR Security MV', 'Trade Direction',
            'EUR Directional Cash Amt', 'EUR Directional Security MV'
        ]
        for col in expected_cols:
            self.assertIn(col, result.columns)
        
        # Check that DataFrame length is preserved
        self.assertEqual(len(result), len(self.df))
    
    def test_create_product_type_bucket(self):
        """Test product type bucket creation."""
        result = self.calculator._create_product_type_bucket(self.df)
        
        # Check that product type bucket is created
        self.assertIn(self.config.PRODUCT_TYPE_BUCKET_COLUMN, result.columns)
        
        # Check specific product type classifications
        cash_mask = result[self.config.PRD_COLUMN] == 'CASH_DEPOSIT'
        self.assertIn(ProductType.CASH.value, result.loc[cash_mask, self.config.PRODUCT_TYPE_BUCKET_COLUMN].values)
        
        repo_mask = result[self.config.PRD_COLUMN] == 'REPO'
        self.assertIn(ProductType.REPO.value, result.loc[repo_mask, self.config.PRODUCT_TYPE_BUCKET_COLUMN].values)
        
        bond_mask = result[self.config.PRD_COLUMN] == 'GOVERNMENT_BOND'
        self.assertIn(ProductType.BOND.value, result.loc[bond_mask, self.config.PRODUCT_TYPE_BUCKET_COLUMN].values)
    
    def test_populate_ccy_columns(self):
        """Test currency column population."""
        result = self.calculator._populate_ccy_columns(self.df)
        
        # Check cash CCY
        cash_mask = (result[self.config.PRD_COLUMN].isin(self.config.CASH_PRD_LIST) |
                    result[self.config.PRD_COLUMN].isin(self.config.REPO_PRD_LIST))
        self.assertTrue(all(result.loc[cash_mask, self.config.CASH_CCY_COLUMN] == 
                           result.loc[cash_mask, self.config.CCY_COLUMN]))
        
        # Check security CCY
        security_mask = (result[self.config.PRD_COLUMN].isin(self.config.REPO_PRD_LIST) |
                        result[self.config.PRD_COLUMN].isin(self.config.BOND_PRD_LIST))
        self.assertTrue(all(result.loc[security_mask, self.config.SECURITY_CCY_COLUMN] == 
                           result.loc[security_mask, self.config.BOND_CURRENCY_COLUMN]))
    
    def test_create_cash_amt(self):
        """Test cash amount creation."""
        result = self.calculator._create_cash_amt(self.df)
        
        # Check cash products
        cash_mask = result[self.config.PRD_COLUMN].isin(self.config.CASH_PRD_LIST)
        self.assertTrue(all(result.loc[cash_mask, self.config.CASH_AMT_COLUMN] == 
                           result.loc[cash_mask, self.config.LEG_ARG_NOTIONAL_COLUMN]))
        
        # Check XCCY products
        xccy_mask = result[self.config.PRD_COLUMN].isin(self.config.XCCY_LIST)
        self.assertTrue(all(result.loc[xccy_mask, self.config.CASH_AMT_COLUMN] == 
                           result.loc[xccy_mask, self.config.LEG_START_CASH_COLUMN]))
    
    def test_create_security_amt(self):
        """Test security amount creation."""
        result = self.calculator._create_security_amt(self.df)
        
        # Check security products
        security_mask = (~result[self.config.PRD_COLUMN].isin(self.config.CASH_PRD_LIST) &
                        (result[self.config.PRD_COLUMN].isin(self.config.REPO_PRD_LIST) |
                         result[self.config.PRD_COLUMN].isin(self.config.BOND_PRD_LIST) |
                         result[self.config.PRD_COLUMN].isin(self.config.SWAP_HEDGE_PRD_LIST)))
        
        self.assertTrue(all(result.loc[security_mask, self.config.SECURITY_AMT_COLUMN] == 
                           result.loc[security_mask, self.config.LEG_ARG_NOTIONAL_COLUMN]))
    
    def test_create_eur_cash_amt(self):
        """Test EUR cash amount creation."""
        result = self.calculator._create_eur_cash_amt(self.df)
        
        # Check that EUR cash amount is calculated correctly
        expected_eur_cash = (result[self.config.CASH_AMT_COLUMN] * result[self.config.FX_COLUMN])
        pd.testing.assert_series_equal(result[self.config.EUR_CASH_AMT_COLUMN], expected_eur_cash)
    
    def test_create_eur_security_mv(self):
        """Test EUR security market value creation."""
        result = self.calculator._create_eur_security_mv(self.df)
        
        # Check that EUR security MV is calculated correctly
        expected_eur_security = (result[self.config.SECURITY_AMT_COLUMN] * 
                                result[self.config.FX_COLUMN] * 
                                result[self.config.POOL_FACTOR_COLUMN] * 
                                result[self.config.MKT_PRICE_COLUMN])
        pd.testing.assert_series_equal(result[self.config.EUR_SECURITY_MV_COLUMN], expected_eur_security)
    
    def test_determine_trade_direction(self):
        """Test trade direction determination."""
        result = self.calculator._determine_trade_direction(self.df)
        
        # Check B-E system
        be_mask = result[self.config.SYSTEM_COLUMN] == SystemType.B_E.value
        self.assertTrue(all(result.loc[be_mask, self.config.TRADE_DIRECTION_COLUMN] == TradeDirection.LONG.value))
        
        # Check non-B-E system with Pay
        pay_mask = (result[self.config.SYSTEM_COLUMN] != SystemType.B_E.value) & (result[self.config.LEG_PAY_REC_COLUMN] == 'Pay')
        self.assertTrue(all(result.loc[pay_mask, self.config.TRADE_DIRECTION_COLUMN] == TradeDirection.SHORT.value))
    
    def test_create_eur_directional_amounts(self):
        """Test EUR directional amounts creation."""
        result = self.calculator._create_eur_directional_amounts(self.df)
        
        # Check EUR directional cash amount
        expected_eur_directional_cash = (result[self.config.EUR_CASH_AMT_COLUMN] * 
                                        result[self.config.TRADE_DIRECTION_COLUMN])
        pd.testing.assert_series_equal(result[self.config.EUR_DIRECTIONAL_CASH_AMT_COLUMN], 
                                      expected_eur_directional_cash)
        
        # Check EUR directional security MV
        expected_eur_directional_security = (result[self.config.EUR_SECURITY_MV_COLUMN] * 
                                            result[self.config.TRADE_DIRECTION_COLUMN])
        pd.testing.assert_series_equal(result[self.config.EUR_DIRECTIONAL_SECURITY_MV_COLUMN], 
                                      expected_eur_directional_security)
    
    def test_mag_direction_mapping(self):
        """Test MAG system direction mapping."""
        # Create data with MAG system
        mag_data = {
            'PRD': ['REPO', 'REPO'],
            'CCY': ['EUR', 'USD'],
            'Leg.PayRec': ['Pay', 'Receive'],
            'Leg.Type': ['Pay', 'Receive'],
            'Leg.StartCash': [None, None],
            'LegArg.Notional': [1000000, 2000000],
            'FX': [1.0, 1.1],
            'PoolFactor': [1.0, 1.0],
            'Mkt Price of security': [1.0, 1.0],
            'system': ['MAG', 'MAG'],
            'Bond.Currency': ['EUR', 'USD']
        }
        
        mag_df = pd.DataFrame(mag_data)
        result = self.calculator._determine_trade_direction(mag_df)
        
        # Check MAG direction mapping
        pay_mask = result[self.config.LEG_TYPE_COLUMN] == 'Pay'
        receive_mask = result[self.config.LEG_TYPE_COLUMN] == 'Receive'
        
        self.assertTrue(all(result.loc[pay_mask, self.config.TRADE_DIRECTION_COLUMN] == TradeDirection.SHORT.value))
        self.assertTrue(all(result.loc[receive_mask, self.config.TRADE_DIRECTION_COLUMN] == TradeDirection.LONG.value))
    
    def test_unknown_product_type(self):
        """Test handling of unknown product types."""
        # Create data with unknown product type
        unknown_data = {
            'PRD': ['UNKNOWN_PRODUCT'],
            'CCY': ['EUR'],
            'Leg.PayRec': ['Pay'],
            'Leg.Type': ['Unknown'],
            'Leg.StartCash': [None],
            'LegArg.Notional': [1000000],
            'FX': [1.0],
            'PoolFactor': [1.0],
            'Mkt Price of security': [1.0],
            'system': ['B-E'],
            'Bond.Currency': ['EUR']
        }
        
        unknown_df = pd.DataFrame(unknown_data)
        result = self.calculator.calculate_market_values(unknown_df)
        
        # Check that unknown product type is handled
        self.assertIn(ProductType.UNKNOWN.value, result[self.config.PRODUCT_TYPE_BUCKET_COLUMN].values)
    
    def test_edge_cases(self):
        """Test edge cases and boundary conditions."""
        # Test with empty DataFrame
        empty_df = pd.DataFrame()
        result = self.calculator.calculate_market_values(empty_df)
        self.assertEqual(len(result), 0)
        
        # Test with single row
        single_row_df = self.df.iloc[:1]
        result = self.calculator.calculate_market_values(single_row_df)
        self.assertEqual(len(result), 1)
        
        # Test with null values
        null_df = self.df.copy()
        null_df['LegArg.Notional'] = None
        null_df['FX'] = None
        
        result = self.calculator.calculate_market_values(null_df)
        # Should handle nulls gracefully
        self.assertEqual(len(result), len(null_df))
    
    def test_numeric_calculations(self):
        """Test numeric calculation accuracy."""
        # Create simple test data with known values
        test_data = {
            'PRD': ['CASH_DEPOSIT'],
            'CCY': ['EUR'],
            'Leg.PayRec': ['Pay'],
            'Leg.Type': ['Deposit'],
            'Leg.StartCash': [None],
            'LegArg.Notional': [1000000],
            'FX': [1.0],
            'PoolFactor': [1.0],
            'Mkt Price of security': [1.0],
            'system': ['B-E'],
            'Bond.Currency': ['EUR']
        }
        
        test_df = pd.DataFrame(test_data)
        result = self.calculator.calculate_market_values(test_df)
        
        # Check specific calculations
        self.assertEqual(result.loc[0, self.config.CASH_AMT_COLUMN], 1000000)
        self.assertEqual(result.loc[0, self.config.EUR_CASH_AMT_COLUMN], 1000000)
        self.assertEqual(result.loc[0, self.config.TRADE_DIRECTION_COLUMN], TradeDirection.LONG.value)
        self.assertEqual(result.loc[0, self.config.EUR_DIRECTIONAL_CASH_AMT_COLUMN], 1000000)
    
    def test_product_type_classification_comprehensive(self):
        """Test comprehensive product type classification."""
        # Test all product types
        all_products = {
            'CASH_PRD_LIST': ['CASH_DEPOSIT', 'CASH_LOAN', 'CASH_OVERDRAFT', 'MONEY_MARKET'],
            'REPO_PRD_LIST': ['REPO', 'REVERSE_REPO', 'SELL_BUY_BACK', 'BUY_SELL_BACK'],
            'BOND_PRD_LIST': ['GOVERNMENT_BOND', 'CORPORATE_BOND', 'MUNICIPAL_BOND', 'TREASURY_BILL'],
            'SWAP_HEDGE_PRD_LIST': ['INTEREST_RATE_SWAP', 'BASIS_SWAP', 'OVERNIGHT_INDEX_SWAP'],
            'XCCY_LIST': ['CROSS_CURRENCY_SWAP', 'FX_SWAP', 'CURRENCY_SWAP']
        }
        
        for product_type, products in all_products.items():
            for product in products:
                test_data = {
                    'PRD': [product],
                    'CCY': ['EUR'],
                    'Leg.PayRec': ['Pay'],
                    'Leg.Type': ['Test'],
                    'Leg.StartCash': [None],
                    'LegArg.Notional': [1000000],
                    'FX': [1.0],
                    'PoolFactor': [1.0],
                    'Mkt Price of security': [1.0],
                    'system': ['B-E'],
                    'Bond.Currency': ['EUR']
                }
                
                test_df = pd.DataFrame(test_data)
                result = self.calculator.calculate_market_values(test_df)
                
                # Check that product type is correctly classified
                if product_type == 'CASH_PRD_LIST':
                    self.assertIn(ProductType.CASH.value, result[self.config.PRODUCT_TYPE_BUCKET_COLUMN].values)
                elif product_type == 'REPO_PRD_LIST':
                    self.assertIn(ProductType.REPO.value, result[self.config.PRODUCT_TYPE_BUCKET_COLUMN].values)
                elif product_type == 'BOND_PRD_LIST':
                    self.assertIn(ProductType.BOND.value, result[self.config.PRODUCT_TYPE_BUCKET_COLUMN].values)
                elif product_type == 'SWAP_HEDGE_PRD_LIST':
                    self.assertIn(ProductType.SWAP_HEDGES.value, result[self.config.PRODUCT_TYPE_BUCKET_COLUMN].values)
                elif product_type == 'XCCY_LIST':
                    self.assertIn(ProductType.XCCY_SWAP.value, result[self.config.PRODUCT_TYPE_BUCKET_COLUMN].values)
    
    def test_currency_handling(self):
        """Test currency handling and FX rate application."""
        # Create data with different currencies
        currency_data = {
            'PRD': ['CASH_DEPOSIT', 'CASH_DEPOSIT', 'CASH_DEPOSIT'],
            'CCY': ['EUR', 'USD', 'GBP'],
            'Leg.PayRec': ['Pay', 'Pay', 'Pay'],
            'Leg.Type': ['Deposit', 'Deposit', 'Deposit'],
            'Leg.StartCash': [None, None, None],
            'LegArg.Notional': [1000000, 1000000, 1000000],
            'FX': [1.0, 1.1, 1.2],
            'PoolFactor': [1.0, 1.0, 1.0],
            'Mkt Price of security': [1.0, 1.0, 1.0],
            'system': ['B-E', 'B-E', 'B-E'],
            'Bond.Currency': ['EUR', 'USD', 'GBP']
        }
        
        currency_df = pd.DataFrame(currency_data)
        result = self.calculator.calculate_market_values(currency_df)
        
        # Check that FX rates are applied correctly
        self.assertEqual(result.loc[0, self.config.EUR_CASH_AMT_COLUMN], 1000000)  # EUR
        self.assertEqual(result.loc[1, self.config.EUR_CASH_AMT_COLUMN], 1100000)  # USD * 1.1
        self.assertEqual(result.loc[2, self.config.EUR_CASH_AMT_COLUMN], 1200000)  # GBP * 1.2
    
    def test_performance_large_dataset(self):
        """Test performance with larger dataset."""
        # Create larger dataset
        large_df = pd.concat([self.df] * 100, ignore_index=True)
        
        import time
        start_time = time.time()
        result = self.calculator.calculate_market_values(large_df)
        end_time = time.time()
        
        # Check that processing completed successfully
        self.assertEqual(len(result), len(large_df))
        
        # Check that processing time is reasonable (less than 5 seconds for 500 rows)
        processing_time = end_time - start_time
        self.assertLess(processing_time, 5.0)
    
    def test_config_validation(self):
        """Test configuration validation."""
        # Test with custom config
        custom_config = MarketValueEnrichmentConfig()
        custom_config.CASH_PRD_LIST = frozenset(['CUSTOM_CASH'])
        
        custom_calculator = MarketValueCalculator(custom_config)
        result = custom_calculator.calculate_market_values(self.df)
        
        # Should work with custom config
        self.assertEqual(len(result), len(self.df))
    
    def test_data_consistency(self):
        """Test data consistency across calculations."""
        result = self.calculator.calculate_market_values(self.df)
        
        # Check that all numeric columns are numeric
        numeric_cols = [self.config.CASH_AMT_COLUMN, self.config.SECURITY_AMT_COLUMN,
                       self.config.EUR_CASH_AMT_COLUMN, self.config.EUR_SECURITY_MV_COLUMN,
                       self.config.TRADE_DIRECTION_COLUMN, self.config.EUR_DIRECTIONAL_CASH_AMT_COLUMN,
                       self.config.EUR_DIRECTIONAL_SECURITY_MV_COLUMN]
        
        for col in numeric_cols:
            self.assertTrue(pd.api.types.is_numeric_dtype(result[col]))
        
        # Check that string columns are strings
        string_cols = [self.config.PRODUCT_TYPE_BUCKET_COLUMN, self.config.CASH_CCY_COLUMN, 
                      self.config.SECURITY_CCY_COLUMN]
        
        for col in string_cols:
            self.assertTrue(pd.api.types.is_string_dtype(result[col]))


if __name__ == '__main__':
    unittest.main()
