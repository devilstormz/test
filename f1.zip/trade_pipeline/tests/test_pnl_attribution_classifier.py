"""
Unit tests for PnLAttributionClassifier.
"""

import unittest
import pandas as pd
import numpy as np
from unittest.mock import patch, MagicMock

from trading_analytics_framework.trade_pipeline.pnl_attribution_classifier import PnLAttributionClassifier


class TestPnLAttributionClassifier(unittest.TestCase):
    """Test cases for PnLAttributionClassifier."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.classifier = PnLAttributionClassifier()
        
        # Create sample test data
        self.sample_data = {
            'Funding/Financing Category': ['Financing', 'Financing', 'Funding', 'Funding'],
            'Cpty.BusinessGroup': ['HedgeFund', 'Bank', 'Bank', 'Bank'],
            'LegArg.Maturity': [12, 6, 18, 24],
            'Book.System': ['K-E', 'MAG', 'K-E', 'MAG'],
            'Leg.Type': ['Repo', 'Reverse', 'Repo', 'Reverse'],
            'MaturityType': ['Term', 'Open', 'Term', 'Evergreen'],
            'Leg.Underl': ['B:DE000A30VS64', 'B:IT0005496788', 'B:DE000A351T77', 'B:US123456'],
            'LegArg.IsCollateralSwap': [True, False, True, False],
            'CollateralSwapType': ['Upgrade', 'Neutral', 'Upgrade', 'Neutral'],
            'DealAttr.ProjectName': ['PGI_Project1', 'Xmt_Project1', 'Xmts_Project1', 'Other_Project'],
            'Book': ['CMMM-CFSF', 'CMMM-CFSFA', 'Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['LO-0751464', 'Other_CPTY', 'LO-0751464', 'Other_CPTY'],
            'Ccy': ['EUR', 'USD', 'EUR', 'USD'],
            'Bond.Issuer': ['WENDL', 'Other_Issuer', 'Other_Issuer', 'Other_Issuer']
        }
        
        self.df = pd.DataFrame(self.sample_data)
    
    def test_init(self):
        """Test classifier initialization."""
        classifier = PnLAttributionClassifier()
        self.assertIsNotNone(classifier)
    
    def test_classify_basic(self):
        """Test basic classification."""
        result = self.classifier.classify(self.df)
        
        # Check that all expected columns are present
        expected_cols = [
            'PnLAttribution_Financing_Strategy', 'PnLAttribution_Funding_Strategy',
            'PnLAttribution_Financing_Funding', 'PnLAttribution_Combined_Strategy'
        ]
        for col in expected_cols:
            self.assertIn(col, result.columns)
        
        # Check that DataFrame length is preserved
        self.assertEqual(len(result), len(self.df))
    
    def test_financing_classification(self):
        """Test financing strategy classification."""
        # Create data that should trigger different financing strategies
        financing_data = {
            'Funding/Financing Category': ['Financing', 'Financing', 'Financing', 'Financing', 'Financing'],
            'Cpty.BusinessGroup': ['HedgeFund', 'Bank', 'Bank', 'Bank', 'Bank'],
            'LegArg.Maturity': [12, 12, 6, 6, 12],
            'Book.System': ['K-E', 'K-E', 'K-E', 'MAG', 'K-E'],
            'Leg.Type': ['Repo', 'Repo', 'Repo', 'Repo', 'Repo'],
            'MaturityType': ['Term', 'Term', 'Term', 'Open', 'Term'],
            'Leg.Underl': ['B:DE000A30VS64', 'B:IT0005496788', 'B:DE000A351T77', 'B:US123456', 'B:US789'],
            'LegArg.IsCollateralSwap': [False, False, False, False, False],
            'CollateralSwapType': ['Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['Other_Project', 'Other_Project', 'Other_Project', 'Other_Project', 'Other_Project'],
            'Book': ['Other_Book', 'Other_Book', 'Other_Book', 'Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY'],
            'Ccy': ['EUR', 'USD', 'EUR', 'USD', 'EUR'],
            'Bond.Issuer': ['Other_Issuer', 'Other_Issuer', 'Other_Issuer', 'Other_Issuer', 'Other_Issuer']
        }
        
        financing_df = pd.DataFrame(financing_data)
        result = self.classifier.classify(financing_df)
        
        # Check specific financing strategies
        hedge_fund_mask = financing_df['Cpty.BusinessGroup'] == 'HedgeFund'
        self.assertIn('Hedge Fund Financing', 
                     result.loc[hedge_fund_mask, 'PnLAttribution_Financing_Strategy'].values)
        
        long_term_bank_mask = (financing_df['Cpty.BusinessGroup'] == 'Bank') & (financing_df['LegArg.Maturity'] > 9)
        self.assertIn('Long Term (>9m) Bank Financing', 
                     result.loc[long_term_bank_mask, 'PnLAttribution_Financing_Strategy'].values)
        
        short_term_bank_mask = (financing_df['Cpty.BusinessGroup'] == 'Bank') & (financing_df['LegArg.Maturity'] <= 9)
        self.assertIn('Short Term (<9m) Bank Financing + Tsy Initiatives (Financing)', 
                     result.loc[short_term_bank_mask, 'PnLAttribution_Financing_Strategy'].values)
    
    def test_funding_classification(self):
        """Test funding strategy classification."""
        # Create data that should trigger different funding strategies
        funding_data = {
            'Funding/Financing Category': ['Funding', 'Funding', 'Funding', 'Funding', 'Funding', 'Funding', 'Funding'],
            'Cpty.BusinessGroup': ['Bank', 'Bank', 'Bank', 'Bank', 'Bank', 'Bank', 'Bank'],
            'LegArg.Maturity': [12, 12, 12, 12, 12, 12, 12],
            'Book.System': ['K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E'],
            'Leg.Type': ['Repo', 'Repo', 'Repo', 'Repo', 'Repo', 'Repo', 'Repo'],
            'MaturityType': ['Term', 'Term', 'Term', 'Term', 'Term', 'Term', 'Term'],
            'Leg.Underl': ['B:DE000A30VS64', 'B:DE000A351T77', 'B:IT0005496788', 'B:US123456', 'B:US789', 'B:US101', 'B:US102'],
            'LegArg.IsCollateralSwap': [False, False, False, False, False, False, False],
            'CollateralSwapType': ['Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['Other_Project', 'Other_Project', 'Other_Project', 'Xmts_Project1', 'Xmts_Project2', 'Other_Project', 'Other_Project'],
            'Book': ['Other_Book', 'Other_Book', 'Other_Book', 'Other_Book', 'Other_Book', 'Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY', 'Other_CPTY'],
            'Ccy': ['EUR', 'USD', 'EUR', 'EUR', 'USD', 'EUR', 'EUR'],
            'Bond.Issuer': ['Other_Issuer', 'Other_Issuer', 'Other_Issuer', 'Other_Issuer', 'Other_Issuer', 'WENDL', 'Other_Issuer']
        }
        
        funding_df = pd.DataFrame(funding_data)
        result = self.classifier.classify(funding_df)
        
        # Check specific funding strategies
        alpspitze_mask = funding_df['Leg.Underl'].isin(['B:DE000A30VS64', 'B:DE000A351T77'])
        self.assertIn('Treasury Funding Initiatives (Alpspitze)', 
                     result.loc[alpspitze_mask, 'PnLAttribution_Funding_Strategy'].values)
        
        it_obg_mask = funding_df['Leg.Underl'] == 'B:IT0005496788'
        self.assertIn('Treasury Funding Initiatives (IT OBG)', 
                     result.loc[it_obg_mask, 'PnLAttribution_Funding_Strategy'].values)
        
        wendl_mask = funding_df['Bond.Issuer'] == 'WENDL'
        self.assertIn('Treasury Funding Initiatives (WENDL)', 
                     result.loc[wendl_mask, 'PnLAttribution_Funding_Strategy'].values)
    
    def test_collateral_swap_upgrade_classification(self):
        """Test collateral swap upgrade classification."""
        # Create data with collateral swap upgrades
        upgrade_data = {
            'Funding/Financing Category': ['Funding', 'Funding'],
            'Cpty.BusinessGroup': ['Bank', 'Bank'],
            'LegArg.Maturity': [12, 12],
            'Book.System': ['K-E', 'K-E'],
            'Leg.Type': ['Repo', 'Repo'],
            'MaturityType': ['Term', 'Term'],
            'Leg.Underl': ['B:US123456', 'B:US789'],
            'LegArg.IsCollateralSwap': [True, True],
            'CollateralSwapType': ['Upgrade', 'Upgrade'],
            'DealAttr.ProjectName': ['PGI_Project1', 'Xmt_Project1'],
            'Book': ['Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['Other_CPTY', 'Other_CPTY'],
            'Ccy': ['EUR', 'USD'],
            'Bond.Issuer': ['Other_Issuer', 'Other_Issuer']
        }
        
        upgrade_df = pd.DataFrame(upgrade_data)
        result = self.classifier.classify(upgrade_df)
        
        # Check that collateral swap upgrades are classified correctly
        self.assertIn('FTP Capacity - Bond Borrows + PGI/X-mkt Upgrades', 
                     result['PnLAttribution_Funding_Strategy'].values)
    
    def test_abcp_initiative_classification(self):
        """Test ABCP initiative classification."""
        # Create data for ABCP initiative
        abcp_data = {
            'Funding/Financing Category': ['Funding'],
            'Cpty.BusinessGroup': ['Bank'],
            'LegArg.Maturity': [12],
            'Book.System': ['K-E'],
            'Leg.Type': ['Repo'],
            'MaturityType': ['Term'],
            'Leg.Underl': ['B:US123456'],
            'LegArg.IsCollateralSwap': [False],
            'CollateralSwapType': ['Neutral'],
            'DealAttr.ProjectName': ['Other_Project'],
            'Book': ['CMMM-CFSF'],
            'Deal.BSCpty': ['LO-0751464'],
            'Ccy': ['EUR'],
            'Bond.Issuer': ['Other_Issuer']
        }
        
        abcp_df = pd.DataFrame(abcp_data)
        result = self.classifier.classify(abcp_df)
        
        # Check ABCP initiative classification
        self.assertIn('ABCP Initiative', result['PnLAttribution_Funding_Strategy'].values)
    
    def test_xmts_classification(self):
        """Test XMTS classification."""
        # Create data for XMTS projects
        xmts_data = {
            'Funding/Financing Category': ['Funding', 'Funding'],
            'Cpty.BusinessGroup': ['Bank', 'Bank'],
            'LegArg.Maturity': [12, 12],
            'Book.System': ['K-E', 'K-E'],
            'Leg.Type': ['Repo', 'Repo'],
            'MaturityType': ['Term', 'Term'],
            'Leg.Underl': ['B:US123456', 'B:US789'],
            'LegArg.IsCollateralSwap': [False, False],
            'CollateralSwapType': ['Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['Xmts_Project1', 'Xmts_Project2'],
            'Book': ['Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['Other_CPTY', 'Other_CPTY'],
            'Ccy': ['EUR', 'USD'],
            'Bond.Issuer': ['Other_Issuer', 'Other_Issuer']
        }
        
        xmts_df = pd.DataFrame(xmts_data)
        result = self.classifier.classify(xmts_df)
        
        # Check XMTS classifications
        eur_mask = xmts_df['Ccy'] == 'EUR'
        usd_mask = xmts_df['Ccy'] == 'USD'
        
        self.assertIn('UCC Tsy DB X-mkts (EUR)', 
                     result.loc[eur_mask, 'PnLAttribution_Funding_Strategy'].values)
        self.assertIn('UCC Tsy DB X-mkts (USD)', 
                     result.loc[usd_mask, 'PnLAttribution_Funding_Strategy'].values)
    
    def test_financing_funding_determination(self):
        """Test Financing/Funding determination."""
        result = self.classifier.classify(self.df)
        
        # Check that Financing/Funding column is populated
        financing_funding_values = result['PnLAttribution_Financing_Funding'].values
        expected_values = ['Financing', 'Funding']
        
        for value in financing_funding_values:
            self.assertIn(value, expected_values + ['Other'])
    
    def test_combined_strategy(self):
        """Test combined strategy column."""
        result = self.classifier.classify(self.df)
        
        # Check that combined strategy shows the actual strategy for each row
        financing_mask = result['PnLAttribution_Financing_Funding'] == 'Financing'
        funding_mask = result['PnLAttribution_Financing_Funding'] == 'Funding'
        
        # For financing rows, combined strategy should match financing strategy
        if financing_mask.any():
            self.assertTrue(all(
                result.loc[financing_mask, 'PnLAttribution_Combined_Strategy'] == 
                result.loc[financing_mask, 'PnLAttribution_Financing_Strategy']
            ))
        
        # For funding rows, combined strategy should match funding strategy
        if funding_mask.any():
            self.assertTrue(all(
                result.loc[funding_mask, 'PnLAttribution_Combined_Strategy'] == 
                result.loc[funding_mask, 'PnLAttribution_Funding_Strategy']
            ))
    
    def test_missing_columns_error_handling(self):
        """Test error handling for missing columns."""
        # Create data with missing required columns
        incomplete_df = self.df.drop(columns=['Funding/Financing Category', 'Cpty.BusinessGroup'])
        
        result = self.classifier.classify(incomplete_df)
        
        # Check that error columns are populated
        error_cols = ['PnLAttribution_Financing_Strategy', 'PnLAttribution_Funding_Strategy',
                     'PnLAttribution_Financing_Funding', 'PnLAttribution_Combined_Strategy']
        
        for col in error_cols:
            self.assertIn('Error - Missing Column', result[col].values)
    
    def test_get_strategy_summary(self):
        """Test strategy summary generation."""
        result = self.classifier.classify(self.df)
        
        # Get strategy summary
        financing_summary, funding_summary, financing_funding_summary = self.classifier.get_strategy_summary(result)
        
        # Check that summaries are DataFrames
        self.assertIsInstance(financing_summary, pd.DataFrame)
        self.assertIsInstance(funding_summary, pd.DataFrame)
        self.assertIsInstance(financing_funding_summary, pd.DataFrame)
        
        # Check that summaries have expected columns
        self.assertIn('Trade_Count', financing_summary.columns)
        self.assertIn('Trade_Count', funding_summary.columns)
        self.assertIn('Trade_Count', financing_funding_summary.columns)
    
    def test_get_strategy_summary_missing_columns(self):
        """Test strategy summary with missing columns."""
        # Try to get summary without running classify first
        with self.assertRaises(ValueError):
            self.classifier.get_strategy_summary(self.df)
    
    def test_edge_cases(self):
        """Test edge cases and boundary conditions."""
        # Test with empty DataFrame
        empty_df = pd.DataFrame()
        result = self.classifier.classify(empty_df)
        self.assertEqual(len(result), 0)
        
        # Test with single row
        single_row_df = self.df.iloc[:1]
        result = self.classifier.classify(single_row_df)
        self.assertEqual(len(result), 1)
        
        # Test with all null values
        null_df = self.df.copy()
        null_df['Funding/Financing Category'] = None
        null_df['Cpty.BusinessGroup'] = None
        
        result = self.classifier.classify(null_df)
        # Should handle nulls gracefully
        self.assertEqual(len(result), len(null_df))
    
    def test_other_classification(self):
        """Test 'Other' classification for unmatched cases."""
        # Create data that doesn't match any specific conditions
        other_data = {
            'Funding/Financing Category': ['Financing', 'Funding'],
            'Cpty.BusinessGroup': ['Other_Group', 'Other_Group'],
            'LegArg.Maturity': [12, 12],
            'Book.System': ['Other_System', 'Other_System'],
            'Leg.Type': ['Other_Type', 'Other_Type'],
            'MaturityType': ['Other_Maturity', 'Other_Maturity'],
            'Leg.Underl': ['B:OTHER1', 'B:OTHER2'],
            'LegArg.IsCollateralSwap': [False, False],
            'CollateralSwapType': ['Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['Other_Project', 'Other_Project'],
            'Book': ['Other_Book', 'Other_Book'],
            'Deal.BSCpty': ['Other_CPTY', 'Other_CPTY'],
            'Ccy': ['EUR', 'USD'],
            'Bond.Issuer': ['Other_Issuer', 'Other_Issuer']
        }
        
        other_df = pd.DataFrame(other_data)
        result = self.classifier.classify(other_df)
        
        # Check that 'Other' classifications are applied
        self.assertIn('Other', result['PnLAttribution_Financing_Strategy'].values)
        self.assertIn('Other', result['PnLAttribution_Funding_Strategy'].values)
    
    def test_performance_large_dataset(self):
        """Test performance with larger dataset."""
        # Create larger dataset
        large_df = pd.concat([self.df] * 100, ignore_index=True)
        
        import time
        start_time = time.time()
        result = self.classifier.classify(large_df)
        end_time = time.time()
        
        # Check that processing completed successfully
        self.assertEqual(len(result), len(large_df))
        
        # Check that processing time is reasonable (less than 5 seconds for 400 rows)
        processing_time = end_time - start_time
        self.assertLess(processing_time, 5.0)
    
    def test_data_consistency(self):
        """Test data consistency across classifications."""
        result = self.classifier.classify(self.df)
        
        # Check that all classification columns are strings
        classification_cols = ['PnLAttribution_Financing_Strategy', 'PnLAttribution_Funding_Strategy',
                             'PnLAttribution_Financing_Funding', 'PnLAttribution_Combined_Strategy']
        
        for col in classification_cols:
            self.assertTrue(pd.api.types.is_string_dtype(result[col]))
        
        # Check that no null values in classification columns
        for col in classification_cols:
            self.assertFalse(result[col].isna().any())
    
    def test_specific_strategy_validation(self):
        """Test validation of specific strategy classifications."""
        # Test hedge fund financing
        hedge_fund_data = {
            'Funding/Financing Category': ['Financing'],
            'Cpty.BusinessGroup': ['HedgeFund'],
            'LegArg.Maturity': [12],
            'Book.System': ['K-E'],
            'Leg.Type': ['Repo'],
            'MaturityType': ['Term'],
            'Leg.Underl': ['B:US123456'],
            'LegArg.IsCollateralSwap': [False],
            'CollateralSwapType': ['Neutral'],
            'DealAttr.ProjectName': ['Other_Project'],
            'Book': ['Other_Book'],
            'Deal.BSCpty': ['Other_CPTY'],
            'Ccy': ['EUR'],
            'Bond.Issuer': ['Other_Issuer']
        }
        
        hedge_fund_df = pd.DataFrame(hedge_fund_data)
        result = self.classifier.classify(hedge_fund_df)
        
        self.assertEqual(result.loc[0, 'PnLAttribution_Financing_Strategy'], 'Hedge Fund Financing')
        self.assertEqual(result.loc[0, 'PnLAttribution_Financing_Funding'], 'Financing')
        self.assertEqual(result.loc[0, 'PnLAttribution_Combined_Strategy'], 'Hedge Fund Financing')
    
    def test_comprehensive_strategy_coverage(self):
        """Test comprehensive coverage of all strategies."""
        # Create data covering all possible strategies
        comprehensive_data = {
            'Funding/Financing Category': ['Financing', 'Financing', 'Financing', 'Financing', 'Financing',
                                         'Funding', 'Funding', 'Funding', 'Funding', 'Funding', 'Funding', 'Funding'],
            'Cpty.BusinessGroup': ['HedgeFund', 'Bank', 'Bank', 'Bank', 'Bank',
                                 'Bank', 'Bank', 'Bank', 'Bank', 'Bank', 'Bank', 'Bank'],
            'LegArg.Maturity': [12, 12, 6, 6, 12,
                              12, 12, 12, 12, 12, 12, 12],
            'Book.System': ['K-E', 'K-E', 'K-E', 'MAG', 'K-E',
                           'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E'],
            'Leg.Type': ['Repo', 'Repo', 'Repo', 'Repo', 'Repo',
                        'Repo', 'Repo', 'Repo', 'Repo', 'Repo', 'Repo', 'Repo'],
            'MaturityType': ['Term', 'Term', 'Term', 'Open', 'Term',
                           'Term', 'Term', 'Term', 'Term', 'Term', 'Term', 'Term'],
            'Leg.Underl': ['B:US1', 'B:US2', 'B:US3', 'B:US4', 'B:US5',
                          'B:DE000A30VS64', 'B:IT0005496788', 'B:US6', 'B:US7', 'B:US8', 'B:US9', 'B:US10'],
            'LegArg.IsCollateralSwap': [False, False, False, False, False,
                                       True, False, False, False, False, False, False],
            'CollateralSwapType': ['Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral',
                                 'Upgrade', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral'],
            'DealAttr.ProjectName': ['Other', 'Other', 'Other', 'Other', 'Other',
                                   'PGI_Project', 'Other', 'Xmts_Project1', 'Xmts_Project2', 'Other', 'Other', 'Other'],
            'Book': ['Other', 'Other', 'Other', 'Other', 'Other',
                    'Other', 'CMMM-CFSF', 'Other', 'Other', 'Other', 'Other', 'Other'],
            'Deal.BSCpty': ['Other', 'Other', 'Other', 'Other', 'Other',
                           'Other', 'LO-0751464', 'Other', 'Other', 'Other', 'Other', 'Other'],
            'Ccy': ['EUR', 'EUR', 'EUR', 'EUR', 'EUR',
                   'EUR', 'EUR', 'EUR', 'USD', 'EUR', 'EUR', 'EUR'],
            'Bond.Issuer': ['Other', 'Other', 'Other', 'Other', 'Other',
                           'Other', 'Other', 'Other', 'Other', 'WENDL', 'Other', 'Other']
        }
        
        comprehensive_df = pd.DataFrame(comprehensive_data)
        result = self.classifier.classify(comprehensive_df)
        
        # Check that all expected strategies are present
        expected_financing_strategies = [
            'Hedge Fund Financing', 'Long Term (>9m) Bank Financing', 
            'Short Term (<9m) Bank Financing + Tsy Initiatives (Financing)',
            'Other Financing P&L (OPEN)', 'Other Financing P&L (Specs)'
        ]
        
        expected_funding_strategies = [
            'Treasury Funding Initiatives (Alpspitze)', 'FTP Capacity - Bond Borrows + PGI/X-mkt Upgrades',
            'ABCP Initiative', 'UCC Tsy DB X-mkts (EUR)', 'UCC Tsy DB X-mkts (USD)',
            'Treasury Funding Initiatives (WENDL)', 'Treasury Funding Initiatives (IT OBG)'
        ]
        
        for strategy in expected_financing_strategies:
            self.assertIn(strategy, result['PnLAttribution_Financing_Strategy'].values)
        
        for strategy in expected_funding_strategies:
            self.assertIn(strategy, result['PnLAttribution_Funding_Strategy'].values)


if __name__ == '__main__':
    unittest.main()
