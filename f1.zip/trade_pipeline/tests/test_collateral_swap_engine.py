"""
Unit tests for CollateralSwapEngine.
"""

import unittest
import pandas as pd
import numpy as np
from unittest.mock import patch, MagicMock

from trading_analytics_framework.trade_pipeline.collateral_swap_engine import (
    CollateralSwapEngine, create_default_config
)
from trading_analytics_framework.trade_pipeline.config import (
    MagTradeType, SwapType, TransactionType, HqlaStatus, BondAssetType, ColumnName
)


class TestCollateralSwapEngine(unittest.TestCase):
    """Test cases for CollateralSwapEngine."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create default configuration
        config = create_default_config()
        
        # Create engine instance
        self.engine = CollateralSwapEngine(**config)
        
        # Create sample test data
        self.sample_data = {
            ColumnName.TRADE_ID.value: ['T001', 'T002', 'T003', 'T004'],
            ColumnName.BOOKING_SYSTEM.value: ['B-E', 'MAG', 'B-E', 'MAG'],
            ColumnName.TRADE_TYPE.value: ['REP', 'REV', 'BB', 'BL'],
            ColumnName.COUNTERPARTY.value: ['CPTY1', 'CPTY2', 'CPTY3', 'CPTY4'],
            ColumnName.COUNTERPARTY_ID.value: ['CC001', 'CC002', 'CC003', 'CC004'],
            ColumnName.NOTIONAL.value: [1000000, 2000000, 500000, 750000],
            ColumnName.CURRENCY.value: ['EUR', 'USD', 'GBP', 'EUR'],
            ColumnName.MARKET_PRICE.value: [1.0, 1.0, 0.95, 1.05],
            ColumnName.MATURITY_DATE.value: ['2024-12-31', '2024-12-31', '2024-12-31', '2024-12-31'],
            ColumnName.CONTRACT_ID.value: ['CON001', 'CON001', 'CON002', 'CON002'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [True, True, False, False],
            'is_secured': [True, True, False, False],
            ColumnName.FX_RATE.value: [1.0, 1.1, 1.2, 1.0],
            ColumnName.LEG_START_CASH.value: [1000000, 2000000, None, None],
            ColumnName.ACCOUNTING_TREATMENT.value: ['ACA', 'ACA', 'ACA', 'ACA'],
            ColumnName.HQLA_STATUS.value: ['Level 1', 'Level 2A', 'Non-HQLA', 'Level 1'],
            'worst_rating': ['AAA', 'AA', 'BBB', 'A'],
            ColumnName.BOND_RATING_SP.value: ['AAA', 'AA', 'BBB', 'A'],
            ColumnName.BOND_RATING_MOODY.value: ['Aaa', 'Aa2', 'Baa2', 'A2'],
            ColumnName.BOND_RATING_FITCH.value: ['AAA', 'AA', 'BBB', 'A'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT', 'CORP_SENIOR', 'CORP_JUNIOR', 'GOVT'],
            ColumnName.PRD.value: ['REPO', 'REPO', 'BOND_BORROW', 'BOND_LEND']
        }
        
        self.df = pd.DataFrame(self.sample_data)
    
    def test_init(self):
        """Test engine initialization."""
        self.assertIsNotNone(self.engine)
        self.assertEqual(self.engine.swap_counter, 0)
        self.assertIsNotNone(self.engine.valid_swap_combinations)
        self.assertIsNotNone(self.engine.bond_rating_engine)
    
    def test_process_trades_basic(self):
        """Test basic trade processing."""
        result = self.engine.process_trades(self.df)
        
        # Check that result columns are added
        expected_cols = [
            self.engine.COLLATERAL_SWAP_INDICATOR, 
            self.engine.TRADE_GROUP_SYNTHETIC_KEY,
            self.engine.COLLATERAL_SWAP_ID, 
            self.engine.COLLATERAL_SWAP_TYPE, 
            self.engine.TRANSACTION_TYPE
        ]
        for col in expected_cols:
            self.assertIn(col, result.columns)
        
        # Check that DataFrame length is preserved
        self.assertEqual(len(result), len(self.df))
    
    def test_desk_logic_approach(self):
        """Test desk logic approach."""
        # Create data that should trigger desk logic
        desk_data = {
            ColumnName.TRADE_ID.value: ['T001', 'T002'],
            ColumnName.BOOKING_SYSTEM.value: ['B-E', 'B-E'],
            ColumnName.TRADE_TYPE.value: ['REP', 'REV'],
            ColumnName.COUNTERPARTY.value: ['CPTY1', 'CPTY1'],
            ColumnName.COUNTERPARTY_ID.value: ['CC001', 'CC001'],
            ColumnName.NOTIONAL.value: [1000000, 2000000],
            ColumnName.CURRENCY.value: ['EUR', 'EUR'],
            ColumnName.MARKET_PRICE.value: [1.0, 1.0],
            ColumnName.MATURITY_DATE.value: ['2024-12-31', '2024-12-31'],
            ColumnName.CONTRACT_ID.value: ['CON001', 'CON001'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [True, True],
            'is_secured': [True, True],
            ColumnName.FX_RATE.value: [1.0, 1.0],
            ColumnName.LEG_START_CASH.value: [1000000, 2000000],
            ColumnName.ACCOUNTING_TREATMENT.value: ['Other', 'Other'],
            ColumnName.HQLA_STATUS.value: ['Level 1', 'Level 2A'],
            'worst_rating': ['AAA', 'AA'],
            ColumnName.BOND_RATING_SP.value: ['AAA', 'AA'],
            ColumnName.BOND_RATING_MOODY.value: ['Aaa', 'Aa2'],
            ColumnName.BOND_RATING_FITCH.value: ['AAA', 'AA'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT', 'CORP_SENIOR'],
            ColumnName.PRD.value: ['REPO', 'REPO']
        }
        
        desk_df = pd.DataFrame(desk_data)
        result = self.engine.process_trades(desk_df)
        
        # Check that some trades are identified as collateral swaps
        swap_indicators = result[self.engine.COLLATERAL_SWAP_INDICATOR]
        self.assertTrue(swap_indicators.any())
    
    def test_contract_id_approach(self):
        """Test contract ID approach."""
        # Create data that should trigger contract ID approach
        contract_data = {
            ColumnName.TRADE_ID.value: ['T001', 'T002'],
            ColumnName.BOOKING_SYSTEM.value: ['B-E', 'B-E'],
            ColumnName.TRADE_TYPE.value: ['BB', 'BL'],
            ColumnName.COUNTERPARTY.value: ['CPTY1', 'CPTY1'],
            ColumnName.COUNTERPARTY_ID.value: ['CC001', 'CC001'],
            ColumnName.NOTIONAL.value: [100000, 100000],  # Small amounts
            ColumnName.CURRENCY.value: ['EUR', 'EUR'],
            ColumnName.MARKET_PRICE.value: [1.0, 1.0],
            ColumnName.MATURITY_DATE.value: ['2024-12-31', '2024-12-31'],
            ColumnName.CONTRACT_ID.value: ['CON001', 'CON001'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [True, True],  # Changed to True to trigger contract approach
            'is_secured': [False, False],
            ColumnName.FX_RATE.value: [1.0, 1.0],
            ColumnName.LEG_START_CASH.value: [None, None],
            ColumnName.ACCOUNTING_TREATMENT.value: ['ACA', 'ACA'],
            ColumnName.HQLA_STATUS.value: ['Level 1', 'Level 1'],
            'worst_rating': ['AAA', 'AAA'],
            ColumnName.BOND_RATING_SP.value: ['AAA', 'AAA'],
            ColumnName.BOND_RATING_MOODY.value: ['Aaa', 'Aaa'],
            ColumnName.BOND_RATING_FITCH.value: ['AAA', 'AAA'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT', 'GOVT'],
            ColumnName.PRD.value: ['BOND_BORROW', 'BOND_LEND']
        }
        
        contract_df = pd.DataFrame(contract_data)
        result = self.engine.process_trades(contract_df)
        
        # Check that some trades are identified as collateral swaps
        swap_indicators = result[self.engine.COLLATERAL_SWAP_INDICATOR]
        self.assertTrue(swap_indicators.any())
    
    def test_secured_flag_approach(self):
        """Test secured flag approach - REMOVED as this approach was removed from the engine."""
        # This test is no longer applicable as the secured flag approach was removed
        # The engine now only uses desk logic and contract ID approaches
        pass
    
    def test_swap_type_classification(self):
        """Test swap type classification."""
        # Create data for upgrade/downgrade testing
        swap_data = {
            ColumnName.TRADE_ID.value: ['T001', 'T002', 'T003', 'T004'],
            ColumnName.BOOKING_SYSTEM.value: ['B-E', 'B-E', 'B-E', 'B-E'],
            ColumnName.TRADE_TYPE.value: ['REP', 'REV', 'BB', 'BL'],
            ColumnName.COUNTERPARTY.value: ['CPTY1', 'CPTY1', 'CPTY1', 'CPTY1'],
            ColumnName.COUNTERPARTY_ID.value: ['CC001', 'CC001', 'CC001', 'CC001'],
            ColumnName.NOTIONAL.value: [1000000, 2000000, 500000, 750000],
            ColumnName.CURRENCY.value: ['EUR', 'EUR', 'EUR', 'EUR'],
            ColumnName.MARKET_PRICE.value: [1.0, 1.0, 0.95, 1.05],
            ColumnName.MATURITY_DATE.value: ['2024-12-31', '2024-12-31', '2024-12-31', '2024-12-31'],
            ColumnName.CONTRACT_ID.value: ['CON001', 'CON001', 'CON002', 'CON002'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [True, True, False, False],
            'is_secured': [True, True, False, False],
            ColumnName.FX_RATE.value: [1.0, 1.0, 1.0, 1.0],
            ColumnName.LEG_START_CASH.value: [1000000, 2000000, None, None],
            ColumnName.ACCOUNTING_TREATMENT.value: ['Other', 'Other', 'Other', 'Other'],
            ColumnName.HQLA_STATUS.value: ['Level 1', 'Non-HQLA', 'Level 1', 'Non-HQLA'],
            'worst_rating': ['AAA', 'BBB', 'AAA', 'BBB'],
            ColumnName.BOND_RATING_SP.value: ['AAA', 'BBB', 'AAA', 'BBB'],
            ColumnName.BOND_RATING_MOODY.value: ['Aaa', 'Baa2', 'Aaa', 'Baa2'],
            ColumnName.BOND_RATING_FITCH.value: ['AAA', 'BBB', 'AAA', 'BBB'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT', 'CORP_JUNIOR', 'GOVT', 'CORP_JUNIOR'],
            ColumnName.PRD.value: ['REPO', 'REPO', 'BOND_BORROW', 'BOND_LEND']
        }
        
        swap_df = pd.DataFrame(swap_data)
        result = self.engine.process_trades(swap_df)
        
        # Check that swap types are assigned
        swap_mask = result[self.engine.COLLATERAL_SWAP_INDICATOR] == True
        if swap_mask.any():
            swap_types = result.loc[swap_mask, self.engine.COLLATERAL_SWAP_TYPE].values
            self.assertTrue(any(swap_type in [SwapType.UPGRADE.value, SwapType.DOWNGRADE.value, SwapType.NEUTRAL.value] 
                              for swap_type in swap_types))
    
    def test_transaction_type_classification(self):
        """Test transaction type classification."""
        result = self.engine.process_trades(self.df)
        
        # Check that transaction types are assigned
        transaction_types = result[self.engine.TRANSACTION_TYPE].values
        expected_types = [TransactionType.FINANCING.value, TransactionType.FUNDING.value,
                         TransactionType.COLLATERAL_SWAP.value, TransactionType.UNSECURED_BOND.value]
        
        for tx_type in transaction_types:
            self.assertIn(tx_type, expected_types)
    
    def test_hierarchy_score_calculation(self):
        """Test hierarchy score calculation."""
        # Create data with different hierarchy components
        hierarchy_data = {
            ColumnName.TRADE_ID.value: ['T001'],
            ColumnName.BOOKING_SYSTEM.value: ['B-E'],
            ColumnName.TRADE_TYPE.value: ['REP'],
            ColumnName.COUNTERPARTY.value: ['CPTY1'],
            ColumnName.COUNTERPARTY_ID.value: ['CC001'],
            ColumnName.NOTIONAL.value: [1000000],
            ColumnName.CURRENCY.value: ['EUR'],
            ColumnName.MARKET_PRICE.value: [1.0],
            ColumnName.MATURITY_DATE.value: ['2024-12-31'],
            ColumnName.CONTRACT_ID.value: ['CON001'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [True],
            'is_secured': [True],
            ColumnName.FX_RATE.value: [1.0],
            ColumnName.LEG_START_CASH.value: [1000000],
            ColumnName.ACCOUNTING_TREATMENT.value: ['Other'],
            ColumnName.HQLA_STATUS.value: ['Level 1'],
            'worst_rating': ['AAA'],
            ColumnName.BOND_RATING_SP.value: ['AAA'],
            ColumnName.BOND_RATING_MOODY.value: ['Aaa'],
            ColumnName.BOND_RATING_FITCH.value: ['AAA'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT'],
            ColumnName.PRD.value: ['REPO']
        }
        
        hierarchy_df = pd.DataFrame(hierarchy_data)
        result = self.engine.process_trades(hierarchy_df)
        
        # Check that hierarchy scores are calculated
        if self.engine.HIERARCHY_SCORE in result.columns:
            scores = result[self.engine.HIERARCHY_SCORE].values
            self.assertTrue(all(score >= 0 for score in scores))
    
    def test_bond_rating_engine_integration(self):
        """Test that bond rating engine integration works correctly."""
        # Create data with different rating scenarios
        rating_test_data = {
            ColumnName.TRADE_ID.value: ['T001', 'T002', 'T003'],
            ColumnName.BOOKING_SYSTEM.value: ['B-E', 'B-E', 'B-E'],
            ColumnName.TRADE_TYPE.value: ['REP', 'REV', 'BB'],
            ColumnName.COUNTERPARTY.value: ['CPTY1', 'CPTY1', 'CPTY2'],
            ColumnName.COUNTERPARTY_ID.value: ['CC001', 'CC001', 'CC002'],
            ColumnName.NOTIONAL.value: [1000000, 2000000, 500000],
            ColumnName.CURRENCY.value: ['EUR', 'EUR', 'GBP'],
            ColumnName.MARKET_PRICE.value: [1.0, 1.0, 0.95],
            ColumnName.MATURITY_DATE.value: ['2024-12-31', '2024-12-31', '2024-12-31'],
            ColumnName.CONTRACT_ID.value: ['CON001', 'CON001', 'CON002'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [True, True, False],
            'is_secured': [True, True, False],
            ColumnName.FX_RATE.value: [1.0, 1.0, 1.2],
            ColumnName.LEG_START_CASH.value: [1000000, 2000000, None],
            ColumnName.ACCOUNTING_TREATMENT.value: ['Other', 'Other', 'Other'],
            ColumnName.HQLA_STATUS.value: ['Level 1', 'Level 2A', 'Non-HQLA'],
            'worst_rating': ['AAA', 'BBB', 'BB'],
            ColumnName.BOND_RATING_SP.value: ['AAA', 'BBB', 'BB'],
            ColumnName.BOND_RATING_MOODY.value: ['Aaa', 'Baa2', 'Ba2'],
            ColumnName.BOND_RATING_FITCH.value: ['AAA', 'BBB', 'BB'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT', 'CORP_SENIOR', 'CORP_JUNIOR'],
            ColumnName.PRD.value: ['REPO', 'REPO', 'BOND_BORROW']
        }
        
        rating_df = pd.DataFrame(rating_test_data)
        result = self.engine.process_trades(rating_df)
        
        # Check that hierarchy scores are calculated and include rating component
        if self.engine.HIERARCHY_SCORE in result.columns:
            scores = result[self.engine.HIERARCHY_SCORE].values
            self.assertTrue(all(score >= 0 for score in scores))
            
            # Verify that different ratings result in different scores
            # AAA should have lower score than BBB, BBB should have lower score than BB
            unique_scores = set(scores)
            self.assertGreater(len(unique_scores), 1, "Different ratings should result in different scores")
            
            # Check that bond rating engine is properly initialized
            self.assertIsNotNone(self.engine.bond_rating_engine)
            self.assertIsNotNone(self.engine.bond_rating_engine.rating_to_score)
            self.assertIsNotNone(self.engine.bond_rating_engine.max_rating_score)
    
    def test_bond_rating_engine_compute_scores_integration(self):
        """Test that the bond rating engine's compute_scores method is properly integrated."""
        # Create a simple test dataframe
        test_data = {
            ColumnName.TRADE_ID.value: ['T001'],
            ColumnName.BOOKING_SYSTEM.value: ['B-E'],
            ColumnName.TRADE_TYPE.value: ['REP'],
            ColumnName.COUNTERPARTY.value: ['CPTY1'],
            ColumnName.COUNTERPARTY_ID.value: ['CC001'],
            ColumnName.NOTIONAL.value: [1000000],
            ColumnName.CURRENCY.value: ['EUR'],
            ColumnName.MARKET_PRICE.value: [1.0],
            ColumnName.MATURITY_DATE.value: ['2024-12-31'],
            ColumnName.CONTRACT_ID.value: ['CON001'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [True],
            'is_secured': [True],
            ColumnName.FX_RATE.value: [1.0],
            ColumnName.LEG_START_CASH.value: [1000000],
            ColumnName.ACCOUNTING_TREATMENT.value: ['Other'],
            ColumnName.HQLA_STATUS.value: ['Level 1'],
            ColumnName.BOND_RATING_SP.value: ['AAA'],
            ColumnName.BOND_RATING_MOODY.value: ['Aaa'],
            ColumnName.BOND_RATING_FITCH.value: ['AAA'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT'],
            ColumnName.PRD.value: ['REPO']
        }
        
        test_df = pd.DataFrame(test_data)
        
        # Mock the bond rating engine's compute_scores method
        with patch.object(self.engine.bond_rating_engine, 'compute_scores') as mock_compute_scores:
            # Set up the mock to return a dataframe with final_score column (includes rating + asset classification)
            mock_result_df = pd.DataFrame({
                'rating_score': [1.0],  # AAA rating score
                'asset_class': ['GOVT'],
                'asset_score': [1],
                'final_score': [101.0]  # rating_score (1) + asset_score (1) * 100 = 101
            })
            mock_compute_scores.return_value = mock_result_df
            
            # Process the trades
            result = self.engine.process_trades(test_df)
            
            # Verify that compute_scores was called
            mock_compute_scores.assert_called_once()
            
            # Verify the call arguments
            call_args = mock_compute_scores.call_args
            self.assertEqual(call_args[1]['use_average'], False)
            self.assertEqual(call_args[1]['use_fallback_logic'], True)
            
            # Verify that the hierarchy score includes the bond rating engine component
            if self.engine.HIERARCHY_SCORE in result.columns:
                hierarchy_score = result[self.engine.HIERARCHY_SCORE].iloc[0]
                # Should include HQLA score (1) + final_score (101) = 102
                self.assertGreaterEqual(hierarchy_score, 100.0)
    
    def test_directional_market_value_calculation(self):
        """Test directional market value calculation."""
        result = self.engine.process_trades(self.df)
        
        # Check that directional market values are calculated
        if self.engine.DIRECTIONAL_MARKET_VALUE in result.columns:
            values = result[self.engine.DIRECTIONAL_MARKET_VALUE].values
            self.assertTrue(all(not pd.isna(value) for value in values))
    
    def test_debug_columns(self):
        """Test debug column functionality."""
        debug_engine = CollateralSwapEngine(enable_debug_columns=True)
        
        result = debug_engine.process_trades(self.df)
        
        # Check that debug columns are added
        debug_cols = [col for col in result.columns if col.startswith('debug_')]
        self.assertGreater(len(debug_cols), 0)
    
    def test_waterfall_rules(self):
        """Test waterfall rules application."""
        # Create data that should be excluded by waterfall rules
        excluded_data = {
            ColumnName.TRADE_ID.value: ['T001', 'T002'],
            ColumnName.BOOKING_SYSTEM.value: ['BOOK_A', 'B-E'],  # One excluded book
            ColumnName.TRADE_TYPE.value: ['BB', 'BL'],
            ColumnName.COUNTERPARTY.value: ['CPTY1', 'CPTY1'],
            ColumnName.COUNTERPARTY_ID.value: ['CPTY_A', 'CC001'],  # One excluded counterparty
            ColumnName.NOTIONAL.value: [1000000, 2000000],
            ColumnName.CURRENCY.value: ['EUR', 'EUR'],
            ColumnName.MARKET_PRICE.value: [1.0, 1.0],
            ColumnName.MATURITY_DATE.value: ['2024-12-31', '2024-12-31'],
            ColumnName.CONTRACT_ID.value: ['CON001', 'CON001'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [False, False],
            'is_secured': [False, False],
            ColumnName.FX_RATE.value: [1.0, 1.0],
            ColumnName.LEG_START_CASH.value: [None, None],
            ColumnName.ACCOUNTING_TREATMENT.value: ['ACA', 'ACA'],
            ColumnName.HQLA_STATUS.value: ['Level 1', 'Level 1'],
            'worst_rating': ['AAA', 'AAA'],
            ColumnName.BOND_RATING_SP.value: ['AAA', 'AAA'],
            ColumnName.BOND_RATING_MOODY.value: ['Aaa', 'Aaa'],
            ColumnName.BOND_RATING_FITCH.value: ['AAA', 'AAA'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT', 'GOVT'],
            ColumnName.PRD.value: ['BOND_BORROW', 'BOND_LEND']
        }
        
        excluded_df = pd.DataFrame(excluded_data)
        result = self.engine.process_trades(excluded_df)
        
        # Check that excluded trades are not identified as collateral swaps
        swap_indicators = result[self.engine.COLLATERAL_SWAP_INDICATOR]
        # Should have fewer swaps due to exclusions
        self.assertLessEqual(swap_indicators.sum(), len(excluded_df))
    
    def test_threshold_config(self):
        """Test threshold configuration."""
        # Create engine with different threshold
        high_threshold_engine = CollateralSwapEngine(market_value_threshold=1e8)  # Very high threshold
        
        result = high_threshold_engine.process_trades(self.df)
        
        # With high threshold, should have fewer swaps identified
        swap_indicators = result[self.engine.COLLATERAL_SWAP_INDICATOR]
        self.assertLessEqual(swap_indicators.sum(), len(self.df))
    
    def test_swap_construction(self):
        """Test swap construction identification."""
        # Create data with known trade type combinations
        construction_data = {
            ColumnName.TRADE_ID.value: ['T001', 'T002'],
            ColumnName.BOOKING_SYSTEM.value: ['B-E', 'B-E'],
            ColumnName.TRADE_TYPE.value: ['BB', 'BL'],  # Bond borrow/lend combination
            ColumnName.COUNTERPARTY.value: ['CPTY1', 'CPTY1'],
            ColumnName.COUNTERPARTY_ID.value: ['CC001', 'CC001'],
            ColumnName.NOTIONAL.value: [100000, 100000],
            ColumnName.CURRENCY.value: ['EUR', 'EUR'],
            ColumnName.MARKET_PRICE.value: [1.0, 1.0],
            ColumnName.MATURITY_DATE.value: ['2024-12-31', '2024-12-31'],
            ColumnName.CONTRACT_ID.value: ['CON001', 'CON001'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [False, False],
            'is_secured': [False, False],
            ColumnName.FX_RATE.value: [1.0, 1.0],
            ColumnName.LEG_START_CASH.value: [None, None],
            ColumnName.ACCOUNTING_TREATMENT.value: ['Other', 'Other'],
            ColumnName.HQLA_STATUS.value: ['Level 1', 'Level 1'],
            'worst_rating': ['AAA', 'AAA'],
            ColumnName.BOND_RATING_SP.value: ['AAA', 'AAA'],
            ColumnName.BOND_RATING_MOODY.value: ['Aaa', 'Aaa'],
            ColumnName.BOND_RATING_FITCH.value: ['AAA', 'AAA'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT', 'GOVT'],
            ColumnName.PRD.value: ['BOND_BORROW', 'BOND_LEND']
        }
        
        construction_df = pd.DataFrame(construction_data)
        result = self.engine.process_trades(construction_df)
        
        # Check that swap construction is identified
        if self.engine.COLLATERAL_SWAP_CONSTRUCTION in result.columns:
            constructions = result[self.engine.COLLATERAL_SWAP_CONSTRUCTION].values
            self.assertTrue(any('BB+BL' in str(construction) for construction in constructions))
    
    def test_edge_cases(self):
        """Test edge cases and boundary conditions."""
        # Test with empty DataFrame - should handle gracefully
        empty_df = pd.DataFrame()
        try:
            result = self.engine.process_trades(empty_df)
            self.assertEqual(len(result), 0)
        except Exception as e:
            # If it raises an error, it should be a meaningful one
            error_msg = str(e).lower()
            self.assertTrue('missing' in error_msg or 'empty' in error_msg or 'leg.type' in error_msg)
        
        # Test with single row
        single_row_df = self.df.iloc[:1]
        result = self.engine.process_trades(single_row_df)
        self.assertEqual(len(result), 1)
        
        # Test with missing columns
        incomplete_df = self.df.drop(columns=[ColumnName.TRADE_TYPE.value, ColumnName.COUNTERPARTY.value])
        # Should handle gracefully or raise appropriate error
        try:
            result = self.engine.process_trades(incomplete_df)
            self.assertEqual(len(result), len(incomplete_df))
        except Exception as e:
            # If it raises an error, it should be a meaningful one
            error_msg = str(e).lower()
            self.assertTrue('missing' in error_msg or 'leg.type' in error_msg or 'keyerror' in error_msg)
    
    def test_config_creation(self):
        """Test configuration creation functions."""
        # Test default config creation
        config = create_default_config()
        self.assertIsInstance(config, dict)
        self.assertIn('desk_logic', config)
        self.assertIn('contract_id', config)
        self.assertIn('enable_debug_columns', config)
    
    def test_performance_large_dataset(self):
        """Test performance with larger dataset."""
        # Create larger dataset
        large_df = pd.concat([self.df] * 100, ignore_index=True)
        
        import time
        start_time = time.time()
        result = self.engine.process_trades(large_df)
        end_time = time.time()
        
        # Check that processing completed successfully
        self.assertEqual(len(result), len(large_df))
        
        # Check that processing time is reasonable (less than 10 seconds for 400 rows)
        processing_time = end_time - start_time
        self.assertLess(processing_time, 10.0)


if __name__ == '__main__':
    unittest.main()
