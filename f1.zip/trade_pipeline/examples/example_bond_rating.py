"""
Example demonstrating the BondScoringEngine and bond rating enrichments.

This example shows how to use the BondScoringEngine directly and through
the enrichment pipeline to compute comprehensive bond credit scores.
"""

import pandas as pd
import numpy as np
from datetime import datetime
from trading_analytics_framework.trade_pipeline.simple_processor import DataProcessingPipeline
from trading_analytics_framework.trade_pipeline.bond_rating_engine import BondScoringEngine


def create_sample_bond_data():
    """Create sample bond data for testing rating calculations."""
    sample_data = {
        # Bond identification
        'Bond.ID': [f'BOND_{i:03d}' for i in range(1, 11)],
        
        # Bond ratings from different agencies (new column names)
        'Bond.RtyDB': ['AAA', 'AA+', 'BBB', 'BB+', 'B', 'CCC', 'AA', 'A+', 'BBB-', 'BB'],
        'Bond.RtySP': ['AA+', 'AA', 'BBB+', 'BB', 'B+', 'CCC+', 'AA-', 'A', 'BBB', 'BB-'],
        'Bond.RtyMDY': ['Aaa', 'Aa1', 'Baa1', 'Ba1', 'B1', 'Caa1', 'Aa2', 'A1', 'Baa3', 'Ba2'],
        'Bond.RtyFITCH': ['AAA', 'AA', 'BBB', 'BB+', 'B-', 'CCC', 'AA+', 'A+', 'BBB-', 'BB'],
        
        # Issuer ratings (new column names)
        'Bond.Issuer.RtyDB': ['AA+', 'AA', 'BBB+', 'BB+', 'B+', 'CCC', 'AA-', 'A+', 'BBB', 'BB'],
        'Bond.Issuer.RtySP': ['AA', 'AA-', 'BBB', 'BB', 'B', 'CCC+', 'A+', 'A', 'BBB-', 'BB-'],
        'Bond.Issuer.RtyMDY': ['Aa1', 'Aa2', 'Baa1', 'Ba1', 'B1', 'Caa1', 'Aa3', 'A1', 'Baa3', 'Ba2'],
        'Bond.Issuer.RtyFITCH': ['AA+', 'AA', 'BBB+', 'BB+', 'B', 'CCC', 'AA-', 'A+', 'BBB', 'BB'],
        
        # Bond characteristics
        'Bond.CollatType': ['GOVT', 'TRIPARTY', 'CLO/ABS', 'CORP', 'CORP', 'CLO/ABS', 'GOVT', 'GOVT', 'CLO/ABS', 'CORP'],
        'subordinated': [False, False, True, False, False, False, False, False, True, False],
        'RtgAvg': ['A', 'AA', 'BBB', 'BB+', 'B', 'CCC', 'AA', 'A+', 'BBB-', 'BB'],
        
        # Additional bond information
        'Bond.Issuer': [
            'US Treasury', 'UK Government', 'ABC Corp', 'XYZ Bank', 'DEF Corp',
            'GHI Financial', 'German Bund', 'French OAT', 'JKL Corp', 'MNO Bank'
        ],
        'coupon_rate': [0.025, 0.03, 0.045, 0.055, 0.075, 0.065, 0.02, 0.025, 0.06, 0.04],
        'Leg.Agr.MatDate': [
            '2025-01-15', '2026-03-20', '2027-06-10', '2028-09-05', '2029-12-01',
            '2030-02-14', '2025-07-30', '2026-11-12', '2027-04-25', '2028-08-18'
        ]
    }
    
    return pd.DataFrame(sample_data)


def demonstrate_bond_rating_engine():
    """Demonstrate the BondScoringEngine directly."""
    print("=" * 60)
    print("BOND SCORING ENGINE DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_bond_data()
    print("Original Bond Data:")
    print(df[['Bond.ID', 'Bond.RtyDB', 'Bond.RtySP', 'Bond.RtyMDY', 'Bond.CollatType']].to_string(index=False))
    print()
    
    # Initialize engine with dataframe
    print("=== Using API Rating Mapping ===")
    engine = BondScoringEngine(df)
    result_df = engine.compute_scores(use_average=False, use_fallback_logic=True)
    
    # Display results
    print("Bond Rating Results:")
    result_columns = [
        'Bond.ID', 'Bond.RtyDB', 'rating_score', 'asset_class', 
        'final_score'
    ]
    print(result_df[result_columns].to_string(index=False))
    print()
    
    # Show engine info
    print("=== Engine Information ===")
    print(f"Max rating score: {engine.max_rating_score}")
    print(f"Rating mapping size: {len(engine.rating_to_score)}")
    print(f"Trade dataframe shape: {engine.trade_df.shape}")
    print()
    
    # Show intermediate calculations
    print("Intermediate Calculations:")
    intermediate_cols = [col for col in result_df.columns if '_score' in col and 'final' not in col and 'rating' not in col]
    print(f"Added {len(intermediate_cols)} intermediate score columns:")
    for col in intermediate_cols:
        print(f"  - {col}")
    print()
    
    # Show asset classifications
    print("Asset Classifications:")
    asset_counts = result_df['asset_class'].value_counts()
    for asset_class, count in asset_counts.items():
        print(f"  {asset_class}: {count}")
    print()


def demonstrate_bond_rating_enrichment():
    """Demonstrate the bond rating enrichment through the pipeline."""
    print("=" * 60)
    print("BOND RATING ENRICHMENT DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_bond_data()
    
    # Use the pipeline with bond rating enrichment
    pipeline = DataProcessingPipeline(load_date=datetime(2024, 1, 15))
    
    try:
        processed_df = (pipeline
                       .set(df)
                       .enrich('bond_ratings')
                       .get())
        
        # Show enrichment results
        enrichment_columns = [
            'Bond.ID', 'Bond.RtyDB', 'bond_rating_score', 'bond_asset_class',
            'bond_final_score'
        ]
        
        print("Bond Rating Enrichment Results:")
        print(processed_df[enrichment_columns].to_string(index=False))
        print()
        
        # Show summary statistics
        print("Bond Rating Summary:")
        print(f"Total bonds: {len(processed_df)}")
        print(f"Average rating score: {processed_df['bond_rating_score'].mean():.2f}")
        print(f"Average final score: {processed_df['bond_final_score'].mean():.2f}")
        print()
        
        # Show asset class distribution
        print("Asset Class Distribution:")
        asset_counts = processed_df['bond_asset_class'].value_counts()
        for asset_class, count in asset_counts.items():
            print(f"  {asset_class}: {count}")
        print()
        
    except Exception as e:
        print(f"Error during bond rating enrichment: {e}")
        import traceback
        traceback.print_exc()


def demonstrate_bond_issuer_enrichment():
    """Demonstrate the bond issuer enrichment."""
    print("=" * 60)
    print("BOND ISSUER ENRICHMENT DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_bond_data()
    
    # Use the pipeline with bond issuer enrichment
    pipeline = DataProcessingPipeline(load_date=datetime(2024, 1, 15))
    
    try:
        processed_df = (pipeline
                       .set(df)
                       .enrich('bond_issuer')
                       .get())
        
        # Show issuer enrichment results
        issuer_columns = [
            'Bond.ID', 'Bond.Issuer', 'issuer_name', 'issuer_country', 'issuer_type'
        ]
        
        print("Bond Issuer Enrichment Results:")
        print(processed_df[issuer_columns].to_string(index=False))
        print()
        
        # Show issuer type distribution
        print("Issuer Type Distribution:")
        issuer_type_counts = processed_df['issuer_type'].value_counts()
        for issuer_type, count in issuer_type_counts.items():
            print(f"  {issuer_type}: {count}")
        print()
        
    except Exception as e:
        print(f"Error during bond issuer enrichment: {e}")


def demonstrate_comprehensive_bond_enrichment():
    """Demonstrate comprehensive bond data enrichment."""
    print("=" * 60)
    print("COMPREHENSIVE BOND ENRICHMENT DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_bond_data()
    
    # Use the pipeline with comprehensive bond enrichment
    pipeline = DataProcessingPipeline(load_date=datetime(2024, 1, 15))
    
    try:
        processed_df = (pipeline
                       .set(df)
                       .enrich('bond_enrichments')
                       .get())
        
        # Show comprehensive enrichment results
        comprehensive_columns = [
            'Bond.ID', 'Bond.Issuer', 'bond_coupon_rate', 'bond_type', 
            'maturity_classification'
        ]
        
        print("Comprehensive Bond Enrichment Results:")
        print(processed_df[comprehensive_columns].to_string(index=False))
        print()
        
        # Show bond type distribution
        print("Bond Type Distribution:")
        bond_type_counts = processed_df['bond_type'].value_counts()
        for bond_type, count in bond_type_counts.items():
            print(f"  {bond_type}: {count}")
        print()
        
        # Show maturity classification distribution
        print("Maturity Classification Distribution:")
        maturity_counts = processed_df['maturity_classification'].value_counts()
        for maturity, count in maturity_counts.items():
            print(f"  {maturity}: {count}")
        print()
        
    except Exception as e:
        print(f"Error during comprehensive bond enrichment: {e}")


def demonstrate_api_rating_mapping():
    """Demonstrate API rating mapping functionality."""
    print("=" * 60)
    print("API RATING MAPPING DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_bond_data()
    
    # Initialize engine with dataframe (automatically loads API mapping)
    engine = BondScoringEngine(df)
    
    print("Rating Mapping Information:")
    print(f"Max rating score: {engine.max_rating_score}")
    print(f"Rating mapping size: {len(engine.rating_to_score)}")
    print(f"Trade dataframe shape: {engine.trade_df.shape}")
    print()
    
    # Show sample mappings
    print("Sample Rating Mappings (from API):")
    sample_ratings = ['AAA', 'AA+', 'A', 'BBB', 'BB', 'B', 'CCC', 'CC', 'C/D']
    for rating in sample_ratings:
        if rating in engine.rating_to_score:
            print(f"  {rating}: {engine.rating_to_score[rating]}")
    print()
    
    # Compute scores
    result = engine.compute_scores(use_average=False)
    
    print("Bond Rating Results:")
    result_columns = [
        'Bond.ID', 'Bond.RtyDB', 'rating_score', 'asset_class', 
        'final_score'
    ]
    print(result[result_columns].to_string(index=False))
    print()
    
    # Show rating distribution
    print("Rating Score Distribution:")
    rating_counts = result['rating_score'].value_counts().sort_index()
    for score, count in rating_counts.items():
        print(f"  Score {score}: {count} bonds")
    print()


def demonstrate_rating_analysis():
    """Demonstrate rating analysis and insights."""
    print("=" * 60)
    print("RATING ANALYSIS DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_bond_data()
    
    # Use the pipeline with multiple enrichments
    pipeline = DataProcessingPipeline(load_date=datetime(2024, 1, 15))
    
    try:
        processed_df = (pipeline
                       .set(df)
                       .enrich(['bond_ratings', 'bond_issuer'])
                       .get())
        
        # Analyze rating scores by issuer type
        print("Rating Scores by Issuer Type:")
        issuer_analysis = processed_df.groupby('issuer_type').agg({
            'bond_rating_score': ['mean', 'min', 'max', 'count'],
            'bond_final_score': ['mean', 'min', 'max']
        }).round(2)
        print(issuer_analysis)
        print()
        
        # Analyze rating scores by asset class
        print("Rating Scores by Asset Class:")
        asset_analysis = processed_df.groupby('bond_asset_class').agg({
            'bond_rating_score': ['mean', 'min', 'max', 'count'],
            'bond_final_score': ['mean', 'min', 'max']
        }).round(2)
        print(asset_analysis)
        print()
        
        # Show asset score distribution
        print("Asset Score Distribution:")
        asset_score_analysis = processed_df.groupby('bond_asset_class').agg({
            'bond_asset_score': ['mean', 'count']
        }).round(2)
        print(asset_score_analysis)
        print()
        
    except Exception as e:
        print(f"Error during rating analysis: {e}")


def main():
    """Run all demonstrations."""
    try:
        demonstrate_bond_rating_engine()
        demonstrate_api_rating_mapping()
        demonstrate_bond_rating_enrichment()
        demonstrate_bond_issuer_enrichment()
        demonstrate_comprehensive_bond_enrichment()
        demonstrate_rating_analysis()
        
        print("=" * 60)
        print("DEMONSTRATION COMPLETE")
        print("=" * 60)
        print("The BondScoringEngine now provides comprehensive bond credit scoring")
        print("including:")
        print("- Multi-agency rating aggregation")
        print("- Asset classification based on Bond.CollatType")
        print("- Issuer type classification")
        print("- Fallback logic for missing ratings")
        print("- Excel LARGE function logic for worst-of ratings")
        print("- Configurable worst-of vs average rating approaches")
        print("- API-based rating mapping support")
        print("- Comprehensive bond data enrichment")
        
    except Exception as e:
        print(f"Demonstration failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
