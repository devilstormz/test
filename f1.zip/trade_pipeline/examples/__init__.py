"""
Examples package for the trading analytics framework.

This package contains example scripts demonstrating how to use various
components of the trade pipeline framework.
"""

__version__ = "1.0.0"
__author__ = "Trading Analytics Framework Team"

# Import all example modules for easy access
from .example_bond_asset_classification import (
    create_sample_bond_data,
    demonstrate_bond_asset_classification_engine,
    demonstrate_bond_asset_classification_enrichment
)

from .example_classification_enrichments import (
    create_sample_trade_data,
    demonstrate_treasury_snu_classifications,
    demonstrate_pnl_attribution_classifications
)

from .example_bond_rating import (
    create_sample_bond_data as create_sample_bond_rating_data,
    demonstrate_bond_rating_engine,
    demonstrate_bond_rating_enrichment
)

from .example_market_value import (
    create_sample_data as create_sample_market_value_data,
    demonstrate_market_value_calculator,
    demonstrate_market_value_enrichment
)

from .example_simplified_approach import (
    demonstrate_enhanced_pipeline,
    demonstrate_reporting_integration,
    demonstrate_data_loading_integration
)

__all__ = [
    # Bond Asset Classification
    'create_sample_bond_data',
    'demonstrate_bond_asset_classification_engine',
    'demonstrate_bond_asset_classification_enrichment',
    
    # Classification Enrichments
    'create_sample_trade_data',
    'demonstrate_treasury_snu_classifications',
    'demonstrate_pnl_attribution_classifications',
    
    # Bond Rating
    'create_sample_bond_rating_data',
    'demonstrate_bond_rating_engine',
    'demonstrate_bond_rating_enrichment',
    
    # Market Value
    'create_sample_market_value_data',
    'demonstrate_market_value_calculator',
    'demonstrate_market_value_enrichment',
    
    # Simplified Approach
    'demonstrate_enhanced_pipeline',
    'demonstrate_reporting_integration',
    'demonstrate_data_loading_integration'
]
