"""
Example usage of Bond Asset Classification enrichment.

This module demonstrates how to use the BondAssetClassificationEnrichment
to classify bonds according to a hierarchical classification system.
"""

import pandas as pd
import numpy as np
from datetime import datetime
from trading_analytics_framework.trade_pipeline.simple_processor import SimpleProcessor
from trading_analytics_framework.trade_pipeline.bond_asset_classification_engine import BondAssetClassificationEngine


def create_sample_bond_data() -> pd.DataFrame:
    """
    Create sample bond data for testing the classification engine.
    
    Returns:
        DataFrame with sample bond data
    """
    sample_data = {
        # Successful cases
        'BondHaircut.AssetClass': ['Govt', 'Govt', 'Govt', 'Govt', 'Govt', 'EM', 'ABS', 'MBS', 
                                   'SSA', 'SSA', 'Own Issued Debt', 'Own Issued Debt', 'N/A', 'N/A'],
        'Bond.IssuerCode': ['UKT001', 'US123', 'DE456', 'FR789', 'IT101', 'BR789', 'CLO001', 'MBS001',
                           'MUNI001', 'AGENCY001', 'COVERED001', 'RETAINED001', 'TRIPARTY001', 'UNKNOWN001'],
        'Bond.Issuer.Name': ['UK Treasury', 'United States Treasury', 'German Govt', 'French Govt', 'Italian Govt', 
                            'Brazil', 'CLO Issuer', 'MBS Issuer', 'Municipal Corp', 'Agency Corp', 
                            'Covered Bond Issuer', 'Retained Bond Issuer', 'Triparty System', 'Unknown Issuer'],
        'Bond.Country': ['GBR', 'USA', 'DEU', 'FRA', 'ITA', 'BRA', 'USA', 'USA', 'USA', 'USA', 'DEU', 'DEU', 'USA', 'XXX'],
        'Bond.CRNCY': ['GBP', 'USD', 'EUR', 'EUR', 'EUR', 'BRL', 'USD', 'USD', 'USD', 'USD', 'EUR', 'EUR', 'USD', 'XXX'],
        'Bond.Desc': ['UK Gilt 2%', 'UST 10Y', 'German Bund 1.5%', 'French OAT 1%', 'Italian BTP 2%', 
                     'Brazil Bond', 'CLO 2023-1', 'RMBS 2023', 'Municipal Bond', 'Agency Bond', 
                     'Covered Bond', 'Retained Bond', 'Triparty Collateral', 'Unknown Bond'],
        'Bond.IGFlag': [True, True, True, True, True, False, True, True, True, True, True, True, True, False],
        'Bond.RtgAvg': ['AAA', 'AAA', 'AAA', 'AA', 'BBB', 'BB', 'A', 'AA', 'AA', 'AAA', 'AA', 'A', 'NR', 'NR'],
        'Bond.IsMuni': [False, False, False, False, False, False, False, False, True, False, False, False, False, False],
        'Bond.IsAgency': [False, False, False, False, False, False, False, False, False, True, False, False, False, False],
        'Bond.SecurityType': ['Govt', 'Govt', 'Govt', 'Govt', 'Govt', 'Corp', 'ABS', 'MBS', 'Muni', 'Agency', 'Covered', 'Retained', 'Unknown', 'Unknown'],
        'Bond.ProgramType': [None, None, None, None, None, None, None, None, None, None, None, 'Retained', None, None],
        'Bond.SourceSystem': ['Internal', 'Internal', 'Internal', 'Internal', 'Internal', 'Internal', 'Internal', 'Internal',
                             'Internal', 'Internal', 'Internal', 'Internal', 'Triparty', 'External']
    }
    
    return pd.DataFrame(sample_data)


def demonstrate_bond_asset_classification_engine():
    """
    Demonstrate direct usage of the BondAssetClassificationEngine.
    """
    print("=== BOND ASSET CLASSIFICATION ENGINE DEMONSTRATION ===")
    
    # Create sample data
    df = create_sample_bond_data()
    print(f"Created sample data with {len(df)} bonds")
    
    # Test with debug mode
    print("\n--- Testing with Debug Mode ---")
    classifier_debug = BondAssetClassificationEngine(debug_mode=True)
    classified_df = classifier_debug.classify_bonds(df)
    
    print("\nSample Classification Results:")
    display_cols = ['Bond.Desc', 'Classification_Level_1', 'Classification_Level_2', 
                   'Classification_Level_3', 'Classification_Level_4']
    print(classified_df[display_cols].to_string(index=False))
    
    # Show failed mappings
    failed_mappings = classifier_debug.get_failed_mappings(classified_df)
    if not failed_mappings.empty:
        print(f"\n=== FAILED MAPPINGS ({len(failed_mappings)} bonds) ===")
        debug_display_cols = ['Bond.Desc', 'BondHaircut.AssetClass', 'Bond.Country', 'Bond.CRNCY',
                             'Classification_Level_2', 'Debug_ValidAssetClass', 'Debug_HasCountry', 
                             'Debug_HasDescription', 'Debug_PotentialIssue']
        available_debug_cols = [col for col in debug_display_cols if col in failed_mappings.columns]
        print(failed_mappings[available_debug_cols].to_string(index=False))
    
    # Get summary
    summary = classifier_debug.get_classification_summary(classified_df)
    print(f"\n=== CLASSIFICATION SUMMARY ===")
    for level, data in summary.items():
        print(f"\n{level}:")
        print(data.to_string(index=False))
    
    # Validation results
    validation = classifier_debug.validate_classification(classified_df)
    print(f"\n=== VALIDATION RESULTS ===")
    print(f"Total bonds: {validation['total_bonds']}")
    print(f"Classification coverage: {validation['classification_coverage']}")
    if validation['potential_issues']:
        print(f"Potential issues: {validation['potential_issues']}")


def demonstrate_bond_asset_classification_enrichment():
    """
    Demonstrate usage of the BondAssetClassificationEnrichment through the pipeline.
    """
    print("\n=== BOND ASSET CLASSIFICATION ENRICHMENT DEMONSTRATION ===")
    
    # Create sample data
    df = create_sample_bond_data()
    print(f"Created sample data with {len(df)} bonds")
    
    # Create processor and add data
    processor = SimpleProcessor()
    processor.add_data(df)
    
    # Apply the enrichment
    print("\n--- Applying Bond Asset Classification Enrichment ---")
    enriched_df = processor.enrich('bond_asset_classification')
    
    print(f"Enriched data shape: {enriched_df.shape}")
    
    # Show results
    print("\nEnrichment Results:")
    result_cols = ['Bond.Desc', 'Classification_Level_1', 'Classification_Level_2', 
                  'Classification_Level_3', 'Classification_Level_4']
    available_result_cols = [col for col in result_cols if col in enriched_df.columns]
    print(enriched_df[available_result_cols].to_string(index=False))
    
    # Get enrichment instance for additional analysis
    enrichment = processor.get_enrichment('bond_asset_classification')
    
    # Get classification summary
    print(f"\n=== CLASSIFICATION SUMMARY ===")
    summary = enrichment.get_classification_summary(enriched_df)
    for level, data in summary.items():
        print(f"\n{level}:")
        print(data.to_string(index=False))
    
    # Get failed mappings
    failed_mappings = enrichment.get_failed_mappings(enriched_df)
    if not failed_mappings.empty:
        print(f"\n=== FAILED MAPPINGS ({len(failed_mappings)} bonds) ===")
        failed_display_cols = ['Bond.Desc', 'BondHaircut.AssetClass', 'Bond.Country', 'Bond.CRNCY',
                              'Classification_Level_2']
        available_failed_cols = [col for col in failed_display_cols if col in failed_mappings.columns]
        print(failed_mappings[available_failed_cols].to_string(index=False))
    
    # Validation
    validation = enrichment.validate_classification(enriched_df)
    print(f"\n=== VALIDATION RESULTS ===")
    print(f"Total bonds: {validation['total_bonds']}")
    print(f"Classification coverage: {validation['classification_coverage']}")
    if validation['potential_issues']:
        print(f"Potential issues: {validation['potential_issues']}")


def demonstrate_debug_mode():
    """
    Demonstrate the debug mode functionality.
    """
    print("\n=== DEBUG MODE DEMONSTRATION ===")
    
    # Create sample data with some problematic records
    df = create_sample_bond_data()
    
    # Create processor with debug mode
    processor = SimpleProcessor()
    processor.add_data(df)
    
    # Apply enrichment with debug mode
    print("--- Applying Bond Asset Classification with Debug Mode ---")
    enriched_df = processor.enrich('bond_asset_classification', debug_mode=True)
    
    # Show debug columns
    debug_cols = [col for col in enriched_df.columns if col.startswith('Debug_')]
    print(f"\nDebug columns added: {len(debug_cols)}")
    print("Debug columns:")
    for col in debug_cols[:10]:  # Show first 10
        print(f"  - {col}")
    if len(debug_cols) > 10:
        print(f"  ... and {len(debug_cols) - 10} more debug columns")
    
    # Show potential issues
    if 'Debug_PotentialIssue' in enriched_df.columns:
        potential_issues = enriched_df[enriched_df['Debug_PotentialIssue'] == True]
        if not potential_issues.empty:
            print(f"\n=== POTENTIAL ISSUES ({len(potential_issues)} bonds) ===")
            issue_display_cols = ['Bond.Desc', 'BondHaircut.AssetClass', 'Bond.Country', 'Bond.CRNCY',
                                 'Debug_DataCompleteness', 'Debug_ValidAssetClass', 'Debug_HasCountry', 
                                 'Debug_HasDescription']
            available_issue_cols = [col for col in issue_display_cols if col in potential_issues.columns]
            print(potential_issues[available_issue_cols].to_string(index=False))


def main():
    """
    Main function to run all demonstrations.
    """
    print("BOND ASSET CLASSIFICATION EXAMPLE")
    print("=" * 50)
    
    # Demonstrate direct engine usage
    demonstrate_bond_asset_classification_engine()
    
    # Demonstrate enrichment usage
    demonstrate_bond_asset_classification_enrichment()
    
    # Demonstrate debug mode
    demonstrate_debug_mode()
    
    print("\n" + "=" * 50)
    print("BOND ASSET CLASSIFICATION EXAMPLE COMPLETE")


if __name__ == "__main__":
    main()
