"""
Market Value Calculator for trading analytics framework.

This module provides a comprehensive market value calculation engine that can be used
by enrichments to calculate cash and security market values following specific business logic.
"""

import pandas as pd
import numpy as np
from enum import Enum
from typing import Dict, FrozenSet, Any
import os


class ProductType(Enum):
    CASH = "Cash"
    REPO = "Repo"
    BOND = "Bond"
    SWAP_HEDGES = "SwapHedges"
    XCCY_SWAP = "XCCYSwap"
    UNKNOWN = "Unknown"


class TradeDirection(Enum):
    LONG = 1
    SHORT = -1


class SystemType(Enum):
    B_E = "B-E"
    MAG = "MAG"


class MarketValueEnrichmentConfig:
    """Configuration class containing all column mappings and product lists"""
    
    # Input columns
    PRD_COLUMN = "PRD"
    CCY_COLUMN = "CCY"
    LEG_PAY_REC_COLUMN = "Leg.PayRec"
    LEG_TYPE_COLUMN = "Leg.Type"
    LEG_START_CASH_COLUMN = "Leg.StartCash"
    LEG_ARG_NOTIONAL_COLUMN = "LegArg.Notional"
    FX_COLUMN = "FX"
    POOL_FACTOR_COLUMN = "PoolFactor"
    MKT_PRICE_COLUMN = "Mkt Price of security"
    SYSTEM_COLUMN = "system"
    BOND_CURRENCY_COLUMN = "Bond.Currency"
    
    # Output columns
    PRODUCT_TYPE_BUCKET_COLUMN = "Product Type Bucket"
    CASH_CCY_COLUMN = "Cash CCY"
    SECURITY_CCY_COLUMN = "Security CCY"
    CASH_AMT_COLUMN = "Cash Amt"
    SECURITY_AMT_COLUMN = "Security Amt"
    EUR_CASH_AMT_COLUMN = "EUR Cash Amt"
    EUR_SECURITY_MV_COLUMN = "EUR Security MV"
    TRADE_DIRECTION_COLUMN = "Trade Direction"
    EUR_DIRECTIONAL_CASH_AMT_COLUMN = "EUR Directional Cash Amt"
    EUR_DIRECTIONAL_SECURITY_MV_COLUMN = "EUR Directional Security MV"
    
    # Product lists as frozen sets
    CASH_PRD_LIST: FrozenSet[str] = frozenset({
        "CASH_DEPOSIT", "CASH_LOAN", "CASH_OVERDRAFT", "MONEY_MARKET"
    })
    
    REPO_PRD_LIST: FrozenSet[str] = frozenset({
        "REPO", "REVERSE_REPO", "SELL_BUY_BACK", "BUY_SELL_BACK"
    })
    
    BOND_PRD_LIST: FrozenSet[str] = frozenset({
        "GOVERNMENT_BOND", "CORPORATE_BOND", "MUNICIPAL_BOND", "TREASURY_BILL"
    })
    
    SWAP_HEDGE_PRD_LIST: FrozenSet[str] = frozenset({
        "INTEREST_RATE_SWAP", "BASIS_SWAP", "OVERNIGHT_INDEX_SWAP"
    })
    
    XCCY_LIST: FrozenSet[str] = frozenset({
        "CROSS_CURRENCY_SWAP", "FX_SWAP", "CURRENCY_SWAP"
    })
    
    # Trade direction mapping
    MAG_DIRECTION_MAP: Dict[str, int] = {
        "PAY": TradeDirection.SHORT.value,
        "RECEIVE": TradeDirection.LONG.value,
        "SELL": TradeDirection.SHORT.value,
        "BUY": TradeDirection.LONG.value
    }


class MarketValueCalculator:
    """
    Cash and Security Market Value Calculation Engine
    
    This class provides market value calculations following specific business logic
    for different product types. It can be used by enrichments to calculate
    cash and security market values.
    """
    
    def __init__(self, config: MarketValueEnrichmentConfig = None):
        """
        Initialize the calculator with configuration
        
        Args:
            config: Configuration object containing column mappings and product lists
        """
        self.config = config or MarketValueEnrichmentConfig()
    
    def load_from_excel(self, file_path: str, sheet_name: str = 'Sheet1') -> pd.DataFrame:
        """
        Load test data from Excel file for testing purposes.
        
        Parameters:
        -----------
        file_path : str
            Path to the Excel file
        sheet_name : str, default 'Sheet1'
            Name of the sheet to load
            
        Returns:
        --------
        pd.DataFrame
            Loaded dataframe
            
        Raises:
        -------
        FileNotFoundError
            If the Excel file doesn't exist
        ValueError
            If the file doesn't contain required columns
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Excel file not found: {file_path}")
        
        try:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            print(f"✓ Successfully loaded {len(df)} rows from {file_path}")
            
            # Validate required columns
            required_columns = [
                self.config.PRD_COLUMN,
                self.config.CCY_COLUMN,
                self.config.LEG_PAY_REC_COLUMN,
                self.config.LEG_TYPE_COLUMN,
                self.config.LEG_ARG_NOTIONAL_COLUMN,
                self.config.FX_COLUMN,
                self.config.POOL_FACTOR_COLUMN,
                self.config.MKT_PRICE_COLUMN,
                self.config.SYSTEM_COLUMN
            ]
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                print(f"⚠ Warning: Missing columns: {missing_columns}")
                print("Available columns:", list(df.columns))
            
            return df
            
        except Exception as e:
            raise ValueError(f"Error loading Excel file: {str(e)}")
    
    def create_sample_excel(self, file_path: str = "market_value_test_data.xlsx") -> str:
        """
        Create a sample Excel file with test data for market value calculator.
        
        Parameters:
        -----------
        file_path : str, default "market_value_test_data.xlsx"
            Path where to save the sample Excel file
            
        Returns:
        --------
        str
            Path to the created file
        """
        sample_data = {
            "PRD": ["CASH_DEPOSIT", "REPO", "GOVERNMENT_BOND", "INTEREST_RATE_SWAP", "CROSS_CURRENCY_SWAP",
                   "CASH_LOAN", "REVERSE_REPO", "CORPORATE_BOND", "BASIS_SWAP", "FX_SWAP"],
            "CCY": ["USD", "EUR", "GBP", "JPY", "USD", "EUR", "GBP", "USD", "EUR", "GBP"],
            "Leg.PayRec": ["Receive", "Pay", "Receive", "Pay", "Receive", "Pay", "Receive", "Pay", "Receive", "Pay"],
            "Leg.Type": ["RECEIVE", "PAY", "BUY", "SELL", "RECEIVE", "PAY", "RECEIVE", "BUY", "RECEIVE", "PAY"],
            "Leg.StartCash": [1000000, 500000, 750000, 0, 2000000, 1500000, 800000, 0, 1200000, 0],
            "LegArg.Notional": [1000000, 500000, 750000, 1500000, 2000000, 1500000, 800000, 1000000, 1200000, 900000],
            "FX": [0.85, 1.0, 1.15, 0.007, 0.85, 1.0, 1.15, 0.85, 1.0, 1.15],
            "PoolFactor": [1.0, 0.98, 1.02, 1.0, 1.0, 1.0, 0.99, 1.01, 1.0, 1.0],
            "Mkt Price of security": [100.5, 99.8, 101.2, 100.0, 100.0, 100.3, 99.9, 100.8, 100.1, 99.7],
            "system": ["B-E", "MAG", "B-E", "MAG", "B-E", "MAG", "B-E", "MAG", "B-E", "MAG"],
            "Bond.Currency": ["", "EUR", "GBP", "", "", "EUR", "GBP", "USD", "EUR", "GBP"]
        }
        
        df = pd.DataFrame(sample_data)
        
        try:
            df.to_excel(file_path, index=False, sheet_name='MarketValueData')
            print(f"✓ Sample Excel file created: {file_path}")
            return file_path
        except Exception as e:
            raise ValueError(f"Error creating sample Excel file: {str(e)}")
    
    def calculate_market_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Main method to calculate all market value columns
        
        Args:
            df: Input dataframe to process
            
        Returns:
            Dataframe with all calculated market value columns
        """
        df_calculated = df.copy()
        
        # Step 1: Create Product Type Bucket
        df_calculated = self._create_product_type_bucket(df_calculated)
        
        # Step 2: Populate Cash CCY and Security CCY
        df_calculated = self._populate_ccy_columns(df_calculated)
        
        # Step 3: Create Cash Amt column
        df_calculated = self._create_cash_amt(df_calculated)
        
        # Step 4: Create Security Amt column
        df_calculated = self._create_security_amt(df_calculated)
        
        # Step 5: Create EUR Cash Amt
        df_calculated = self._create_eur_cash_amt(df_calculated)
        
        # Step 6: Create EUR Security MV
        df_calculated = self._create_eur_security_mv(df_calculated)
        
        # Step 7: Determine Trade Direction
        df_calculated = self._determine_trade_direction(df_calculated)
        
        # Step 8: Create EUR Directional amounts
        df_calculated = self._create_eur_directional_amounts(df_calculated)
        
        return df_calculated
    
    def _create_product_type_bucket(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Step 1: Create Product Type Bucket column based on PRD classification
        """
        conditions = [
            df[self.config.PRD_COLUMN].isin(self.config.CASH_PRD_LIST),
            df[self.config.PRD_COLUMN].isin(self.config.REPO_PRD_LIST),
            df[self.config.PRD_COLUMN].isin(self.config.BOND_PRD_LIST),
            df[self.config.PRD_COLUMN].isin(self.config.SWAP_HEDGE_PRD_LIST),
            df[self.config.PRD_COLUMN].isin(self.config.XCCY_LIST)
        ]
        
        choices = [
            ProductType.CASH.value,
            ProductType.REPO.value,
            ProductType.BOND.value,
            ProductType.SWAP_HEDGES.value,
            ProductType.XCCY_SWAP.value
        ]
        
        df[self.config.PRODUCT_TYPE_BUCKET_COLUMN] = np.select(
            conditions, choices, default=ProductType.UNKNOWN.value
        )
        
        return df
    
    def _populate_ccy_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Step 2: Populate Cash CCY and Security CCY columns
        """
        # Cash CCY logic
        cash_ccy_condition = (
            df[self.config.PRD_COLUMN].isin(self.config.CASH_PRD_LIST) |
            df[self.config.PRD_COLUMN].isin(self.config.REPO_PRD_LIST)
        )
        
        df[self.config.CASH_CCY_COLUMN] = np.where(
            cash_ccy_condition,
            df[self.config.CCY_COLUMN],
            ""
        )
        
        # Security CCY logic
        security_ccy_condition = (
            df[self.config.PRD_COLUMN].isin(self.config.REPO_PRD_LIST) |
            df[self.config.PRD_COLUMN].isin(self.config.BOND_PRD_LIST)
        )
        
        df[self.config.SECURITY_CCY_COLUMN] = np.where(
            security_ccy_condition,
            df[self.config.BOND_CURRENCY_COLUMN],
            ""
        )
        
        return df
    
    def _create_cash_amt(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Step 3: Create Cash Amt column
        """
        cash_conditions = [
            df[self.config.PRD_COLUMN].isin(self.config.CASH_PRD_LIST),
            df[self.config.PRD_COLUMN].isin(self.config.XCCY_LIST),
            df[self.config.PRD_COLUMN].isin(self.config.REPO_PRD_LIST)
        ]
        
        cash_choices = [
            df[self.config.LEG_ARG_NOTIONAL_COLUMN],
            df[self.config.LEG_START_CASH_COLUMN],
            0
        ]
        
        df[self.config.CASH_AMT_COLUMN] = np.select(
            cash_conditions, cash_choices, default=0
        )
        
        return df
    
    def _create_security_amt(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Step 4: Create Security Amt column
        """
        # Condition: PRD not in CashPRDList AND PRD in RepoPRDList, BondPRDList, SwapHedges
        security_condition = (
            ~df[self.config.PRD_COLUMN].isin(self.config.CASH_PRD_LIST) &
            (df[self.config.PRD_COLUMN].isin(self.config.REPO_PRD_LIST) |
             df[self.config.PRD_COLUMN].isin(self.config.BOND_PRD_LIST) |
             df[self.config.PRD_COLUMN].isin(self.config.SWAP_HEDGE_PRD_LIST))
        )
        
        df[self.config.SECURITY_AMT_COLUMN] = np.where(
            security_condition,
            df[self.config.LEG_ARG_NOTIONAL_COLUMN],
            0
        )
        
        return df
    
    def _create_eur_cash_amt(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Step 5: Create EUR Cash Amt column
        """
        df[self.config.EUR_CASH_AMT_COLUMN] = (
            df[self.config.CASH_AMT_COLUMN] * df[self.config.FX_COLUMN]
        )
        
        return df
    
    def _create_eur_security_mv(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Step 6: Create EUR Security MV column
        """
        df[self.config.EUR_SECURITY_MV_COLUMN] = (
            df[self.config.SECURITY_AMT_COLUMN] * 
            df[self.config.FX_COLUMN] * 
            df[self.config.POOL_FACTOR_COLUMN] * 
            df[self.config.MKT_PRICE_COLUMN]
        )
        
        return df
    
    def _determine_trade_direction(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Step 7: Determine Trade Direction
        """
        conditions = [
            df[self.config.SYSTEM_COLUMN] == SystemType.B_E.value,
            (df[self.config.SYSTEM_COLUMN] != SystemType.B_E.value) & 
            (df[self.config.LEG_PAY_REC_COLUMN] == "Pay"),
            df[self.config.SYSTEM_COLUMN] == SystemType.MAG.value
        ]
        
        # For B-E system, direction = 1
        # For non-B-E system with Leg.PayRec = Pay, direction = -1, else 1
        # For MAG system, use Leg.Type to lookup direction in mag_direction_map, else 1
        def get_mag_direction(row):
            if row[self.config.SYSTEM_COLUMN] == SystemType.MAG.value:
                return self.config.MAG_DIRECTION_MAP.get(
                    row[self.config.LEG_TYPE_COLUMN], TradeDirection.LONG.value
                )
            return TradeDirection.LONG.value
        
        choices = [
            TradeDirection.LONG.value,  # B-E system
            TradeDirection.SHORT.value,  # Non-B-E with Pay
            df.apply(get_mag_direction, axis=1)  # MAG system
        ]
        
        df[self.config.TRADE_DIRECTION_COLUMN] = np.select(
            conditions, choices, default=TradeDirection.LONG.value
        )
        
        return df
    
    def _create_eur_directional_amounts(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Step 8: Create EUR Directional Cash Amt and EUR Directional Security MV
        """
        df[self.config.EUR_DIRECTIONAL_CASH_AMT_COLUMN] = (
            df[self.config.EUR_CASH_AMT_COLUMN] * 
            df[self.config.TRADE_DIRECTION_COLUMN]
        )
        
        df[self.config.EUR_DIRECTIONAL_SECURITY_MV_COLUMN] = (
            df[self.config.EUR_SECURITY_MV_COLUMN] * 
            df[self.config.TRADE_DIRECTION_COLUMN]
        )
        
        return df


# Main execution for testing
if __name__ == "__main__":
    print("=== MarketValueCalculator with Excel File Loading ===")
    
    try:
        # Create calculator
        calculator = MarketValueCalculator()
        
        # Create sample Excel file for testing
        excel_file = calculator.create_sample_excel("market_value_test_data.xlsx")
        
        # Load data from Excel file
        df = calculator.load_from_excel(excel_file, sheet_name='MarketValueData')
        
        print("\nOriginal DataFrame:")
        print(df.to_string(index=False))
        print()
        
        # Calculate market values
        calculated_df = calculator.calculate_market_values(df)
        
        print("Calculated Market Values:")
        new_columns = [
            calculator.config.PRODUCT_TYPE_BUCKET_COLUMN,
            calculator.config.CASH_CCY_COLUMN,
            calculator.config.SECURITY_CCY_COLUMN,
            calculator.config.CASH_AMT_COLUMN,
            calculator.config.SECURITY_AMT_COLUMN,
            calculator.config.EUR_CASH_AMT_COLUMN,
            calculator.config.EUR_SECURITY_MV_COLUMN,
            calculator.config.TRADE_DIRECTION_COLUMN,
            calculator.config.EUR_DIRECTIONAL_CASH_AMT_COLUMN,
            calculator.config.EUR_DIRECTIONAL_SECURITY_MV_COLUMN
        ]
        
        print(calculated_df[new_columns].to_string(index=False))
        print()
        
        # Show summary statistics
        print("=== Summary Statistics ===")
        print(f"Total EUR Cash Amount: {calculated_df[calculator.config.EUR_CASH_AMT_COLUMN].sum():,.2f}")
        print(f"Total EUR Security MV: {calculated_df[calculator.config.EUR_SECURITY_MV_COLUMN].sum():,.2f}")
        print(f"Total EUR Directional Cash: {calculated_df[calculator.config.EUR_DIRECTIONAL_CASH_AMT_COLUMN].sum():,.2f}")
        print(f"Total EUR Directional Security: {calculated_df[calculator.config.EUR_DIRECTIONAL_SECURITY_MV_COLUMN].sum():,.2f}")
        
        # Show product type distribution
        print("\n=== Product Type Distribution ===")
        product_counts = calculated_df[calculator.config.PRODUCT_TYPE_BUCKET_COLUMN].value_counts()
        for product_type, count in product_counts.items():
            print(f"  {product_type}: {count}")
            
    except Exception as e:
        print(f"Error during testing: {e}")
        print("Falling back to in-memory sample data...")
        
        # Fallback to in-memory data
        sample_data = pd.DataFrame({
            "PRD": ["CASH_DEPOSIT", "REPO", "GOVERNMENT_BOND", "INTEREST_RATE_SWAP", "CROSS_CURRENCY_SWAP"],
            "CCY": ["USD", "EUR", "GBP", "JPY", "USD"],
            "Leg.PayRec": ["Receive", "Pay", "Receive", "Pay", "Receive"],
            "Leg.Type": ["RECEIVE", "PAY", "BUY", "SELL", "RECEIVE"],
            "Leg.StartCash": [1000000, 500000, 750000, 0, 2000000],
            "LegArg.Notional": [1000000, 500000, 750000, 1500000, 2000000],
            "FX": [0.85, 1.0, 1.15, 0.007, 0.85],
            "PoolFactor": [1.0, 0.98, 1.02, 1.0, 1.0],
            "Mkt Price of security": [100.5, 99.8, 101.2, 100.0, 100.0],
            "system": ["B-E", "MAG", "B-E", "MAG", "B-E"],
            "Bond.Currency": ["", "EUR", "GBP", "", ""]
        })
        
        calculator = MarketValueCalculator()
        calculated_df = calculator.calculate_market_values(sample_data)
        print(calculated_df[calculator.config.PRODUCT_TYPE_BUCKET_COLUMN].value_counts())
