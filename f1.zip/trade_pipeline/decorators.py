"""
Decorators for trading dataset pipeline.
Provides essential decorators for the simplified architecture:
- Registration decorators for enrichments and filters
- Error handling for pipeline operations

Note on imports: We use absolute imports within decorators to avoid circular dependency issues.
The lazy import pattern (importing inside the decorator function) ensures that the base classes
are only imported when the decorator is actually used, preventing import cycles.
"""
from functools import wraps
from typing import Callable, Any, List, Type, Dict
from trading_analytics_framework.trade_pipeline.data_loader import PipelineError, EnrichmentError, DatabaseError, DataValidationError


# Lightweight registries populated by registration decorators
ENRICHMENT_REGISTRY: Dict[str, Dict[str, Any]] = {}
FILTER_REGISTRY: Dict[str, Dict[str, Any]] = {}


def register_enrichment(name: str, required_input: List[str]):
    """
    Class decorator to register enrichments by name with declared required input columns.

    Args:
        name: Registry key
        required_input: Columns the enrichment expects to find (must be non-empty)
    """
    if required_input is None or len(required_input) == 0:
        raise ValueError(f"register_enrichment('{name}') requires non-empty required_input list")

    def _decorator(cls):
        # Lazy import to avoid circular dependencies
        # Using absolute import to ensure we get the correct base class
        from trading_analytics_framework.trade_pipeline.base import BaseEnrichment
        if not issubclass(cls, BaseEnrichment):
            raise TypeError(f"{cls.__name__} must subclass BaseEnrichment")
        ENRICHMENT_REGISTRY[name] = {
            "cls": cls,
            "required_input": list(required_input),
        }
        # Stamp for introspection
        setattr(cls, "_registered_required_input", list(required_input))
        return cls
    return _decorator


def register_filter(name: str, required_columns: List[str]):
    """
    Class decorator to register filters by name with declared required input columns.

    Args:
        name: Registry key
        required_columns: Required input columns for the filter (must be non-empty)
    """
    if not required_columns:
        raise ValueError(f"register_filter('{name}') requires non-empty required_columns list")

    def _decorator(cls):
        # Using absolute import to ensure we get the correct base class
        from trading_analytics_framework.trade_pipeline.base import BaseFilter
        if not issubclass(cls, BaseFilter):
            raise TypeError(f"{cls.__name__} must subclass BaseFilter")
        FILTER_REGISTRY[name] = {
            "cls": cls,
            "required_columns": list(required_columns),
        }
        setattr(cls, "_registered_required_columns", list(required_columns))
        return cls
    return _decorator


def error_handler(error_types: List[Type[Exception]] = None):
    """
    Decorator for error handling in reporting classes.
    
    This decorator provides centralized error handling for methods
    in reporting classes, catching specific exceptions and providing
    appropriate error messages and logging.
    
    Usage:
        @error_handler([EnrichmentError, DatabaseError])
        def my_method(self):
            # method implementation
            
    Args:
        error_types: List of exception types to catch (defaults to common pipeline errors)
        
    Returns:
        Decorated function with error handling
    """
    if error_types is None:
        error_types = [EnrichmentError, DatabaseError, DataValidationError]
    
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except tuple(error_types) as e:
                # Log the error with context
                print(f"Error in {func.__name__}: {str(e)}")
                print(f"Error type: {type(e).__name__}")
                print(f"Args: {args}")
                print(f"Kwargs: {kwargs}")
                
                # Re-raise the exception for proper error handling
                raise
        return wrapper
    return decorator 