"""
PnL Attribution Classifier for trade classification.

This module contains the PnLAttributionClassifier class that provides
classification logic for PnL Attribution Financing and Funding strategies.
"""

import pandas as pd
import numpy as np
from typing import List, Tuple


class PnLAttributionClassifier:
    """
    PnL Attribution Asset Classification based on financing/funding strategies.
    Uses numpy.select for efficient classification.
    """
    
    # Column name definitions - easy to change if schema changes
    COL_FUNDING_FINANCING_CATEGORY = 'Funding/Financing Category'
    COL_CPTY_BUSINESS_GROUP = 'Cpty.BusinessGroup'
    COL_LEG_ARG_MATURITY = 'LegArg.Maturity'
    COL_BOOK_SYSTEM = 'Book.System'
    COL_LEG_TYPE = 'Leg.Type'
    COL_MATURITY_TYPE = 'MaturityType'
    COL_LEG_UNDERL = 'Leg.Underl'
    COL_LEG_ARG_IS_COLLATERAL_SWAP = 'LegArg.IsCollateralSwap'
    COL_COLLATERAL_SWAP_TYPE = 'CollateralSwapType'
    COL_DEAL_ATTR_PROJECT_NAME = 'DealAttr.ProjectName'
    COL_BOOK = 'Book'
    COL_DEAL_BS_CPTY = 'Deal.BSCpty'
    COL_CCY = 'Ccy'
    COL_BOND_ISSUER = 'Bond.Issuer'
    
    # Classification output columns with prefixed names
    COL_FINANCING_STRATEGY = 'PnLAttribution_Financing_Strategy'
    COL_FUNDING_STRATEGY = 'PnLAttribution_Funding_Strategy'
    COL_FINANCING_FUNDING = 'PnLAttribution_Financing_Funding'
    COL_COMBINED_STRATEGY = 'PnLAttribution_Combined_Strategy'
    
    # Constant values
    CATEGORY_FINANCING = 'Financing'
    CATEGORY_FUNDING = 'Funding'
    BUSINESS_GROUP_HEDGE_FUND = 'HedgeFund'
    BUSINESS_GROUP_BANK = 'Bank'
    MATURITY_THRESHOLD_MONTHS = 9
    BOOK_SYSTEM_KE = 'K-E'
    BOOK_SYSTEM_MAG = 'MAG'
    BOOK_CMMM_CFSF = 'CMMM-CFSF'
    BOOK_CMMM_CFSFA = 'CMMM-CFSFA'
    DEAL_BS_CPTY_LO = 'LO-0751464'
    LEG_TYPES_REPO = ['Repo', 'Reverse']
    MATURITY_TYPES_OPEN = ['Open', 'Evergreen']
    COLLATERAL_SWAP_UPGRADE = 'Upgrade'
    PROJECT_PREFIX_PGI = 'PGI'
    PROJECT_PREFIX_XMT = 'Xmt'
    PROJECT_PREFIX_XMTS = 'Xmts'
    CCY_EUR = 'EUR'
    CCY_USD = 'USD'
    BOND_ISSUER_WENDL = 'WENDL'
    
    # Specific instrument identifiers
    LEG_UNDERL_ALPSPITZE = ['B:DE000A30VS64', 'B:DE000A351T77']
    LEG_UNDERL_IT_OBG = 'B:IT0005496788'
    
    def __init__(self):
        pass
    
    def _get_financing_conditions_and_choices(self, df: pd.DataFrame) -> Tuple[List, List]:
        """Get conditions and choices for Financing classification using numpy arrays."""
        conditions = [
            (df[self.COL_FUNDING_FINANCING_CATEGORY] == self.CATEGORY_FINANCING) &
            (df[self.COL_CPTY_BUSINESS_GROUP] == self.BUSINESS_GROUP_HEDGE_FUND),
            
            (df[self.COL_FUNDING_FINANCING_CATEGORY] == self.CATEGORY_FINANCING) &
            (df[self.COL_LEG_ARG_MATURITY] > self.MATURITY_THRESHOLD_MONTHS) &
            (df[self.COL_CPTY_BUSINESS_GROUP] == self.BUSINESS_GROUP_BANK),
            
            (df[self.COL_FUNDING_FINANCING_CATEGORY] == self.CATEGORY_FINANCING) &
            (df[self.COL_LEG_ARG_MATURITY] <= self.MATURITY_THRESHOLD_MONTHS) &
            (df[self.COL_CPTY_BUSINESS_GROUP] == self.BUSINESS_GROUP_BANK),
            
            (df[self.COL_FUNDING_FINANCING_CATEGORY] == self.CATEGORY_FINANCING) &
            (df[self.COL_BOOK_SYSTEM] == self.BOOK_SYSTEM_MAG) &
            df[self.COL_LEG_TYPE].isin(self.LEG_TYPES_REPO) &
            df[self.COL_MATURITY_TYPE].isin(self.MATURITY_TYPES_OPEN),
            
            (df[self.COL_FUNDING_FINANCING_CATEGORY] == self.CATEGORY_FINANCING)
        ]
        
        choices = [
            'Hedge Fund Financing',
            'Long Term (>9m) Bank Financing',
            'Short Term (<9m) Bank Financing + Tsy Initiatives (Financing)',
            'Other Financing P&L (OPEN)',
            'Other Financing P&L (Specs)'
        ]
        
        return conditions, choices
    
    def _get_funding_conditions_and_choices(self, df: pd.DataFrame) -> Tuple[List, List]:
        """Get conditions and choices for Funding classification using numpy arrays."""
        conditions = [
            df[self.COL_LEG_UNDERL].isin(self.LEG_UNDERL_ALPSPITZE),
            
            (df[self.COL_LEG_ARG_IS_COLLATERAL_SWAP] == True) &
            (df[self.COL_COLLATERAL_SWAP_TYPE] == self.COLLATERAL_SWAP_UPGRADE) &
            (df[self.COL_DEAL_ATTR_PROJECT_NAME].str.startswith(self.PROJECT_PREFIX_PGI, na=False) |
             df[self.COL_DEAL_ATTR_PROJECT_NAME].str.startswith(self.PROJECT_PREFIX_XMT, na=False)),
            
            (df[self.COL_BOOK_SYSTEM] == self.BOOK_SYSTEM_KE) &
            df[self.COL_BOOK].isin([self.BOOK_CMMM_CFSF, self.BOOK_CMMM_CFSFA]) &
            (df[self.COL_DEAL_BS_CPTY] == self.DEAL_BS_CPTY_LO),
            
            (df[self.COL_DEAL_ATTR_PROJECT_NAME].str.startswith(self.PROJECT_PREFIX_XMTS, na=False)) &
            (df[self.COL_CCY] == self.CCY_EUR),
            
            (df[self.COL_DEAL_ATTR_PROJECT_NAME].str.startswith(self.PROJECT_PREFIX_XMTS, na=False)) &
            (df[self.COL_CCY] == self.CCY_USD),
            
            df[self.COL_BOND_ISSUER] == self.BOND_ISSUER_WENDL,
            
            df[self.COL_LEG_UNDERL] == self.LEG_UNDERL_IT_OBG
        ]
        
        choices = [
            'Treasury Funding Initiatives (Alpspitze)',
            'FTP Capacity - Bond Borrows + PGI/X-mkt Upgrades',
            'ABCP Initiative',
            'UCC Tsy DB X-mkts (EUR)',
            'UCC Tsy DB X-mkts (USD)',
            'Treasury Funding Initiatives (WENDL)',
            'Treasury Funding Initiatives (IT OBG)'
        ]
        
        return conditions, choices
    
    def classify(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Classify trades based on PnL Attribution rules for both Financing and Funding.
        
        Parameters:
        df: DataFrame with trade data
        
        Returns:
        DataFrame with additional columns:
        - 'PnLAttribution_Financing_Strategy': Financing strategy classification
        - 'PnLAttribution_Funding_Strategy': Funding strategy classification
        - 'PnLAttribution_Financing_Funding': Whether it's Financing or Funding
        - 'PnLAttribution_Combined_Strategy': Combined strategy string
        """
        df_copy = df.copy()
        
        try:
            # Financing classification
            financing_conditions, financing_choices = self._get_financing_conditions_and_choices(df_copy)
            df_copy[self.COL_FINANCING_STRATEGY] = np.select(financing_conditions, financing_choices, default='Other')
            
            # Funding classification
            funding_conditions, funding_choices = self._get_funding_conditions_and_choices(df_copy)
            df_copy[self.COL_FUNDING_STRATEGY] = np.select(funding_conditions, funding_choices, default='Other')
            
            # Determine if each row is Financing or Funding based on conditions
            # Financing conditions: when any financing condition is True
            financing_condition = np.any(financing_conditions, axis=0)
            # Funding conditions: when any funding condition is True
            funding_condition = np.any(funding_conditions, axis=0)
            
            # Create Financing/Funding column
            df_copy[self.COL_FINANCING_FUNDING] = np.where(
                financing_condition, 'Financing',
                np.where(funding_condition, 'Funding', 'Other')
            )
            
            # Create combined strategy column - show the actual strategy for the row
            df_copy[self.COL_COMBINED_STRATEGY] = np.where(
                financing_condition, df_copy[self.COL_FINANCING_STRATEGY],
                np.where(funding_condition, df_copy[self.COL_FUNDING_STRATEGY], 'Other')
            )
            
        except KeyError as e:
            print(f"Missing required column: {e}")
            df_copy[self.COL_FINANCING_STRATEGY] = 'Error - Missing Column'
            df_copy[self.COL_FUNDING_STRATEGY] = 'Error - Missing Column'
            df_copy[self.COL_FINANCING_FUNDING] = 'Error - Missing Column'
            df_copy[self.COL_COMBINED_STRATEGY] = 'Error - Missing Column'
        except Exception as e:
            print(f"Classification error: {e}")
            df_copy[self.COL_FINANCING_STRATEGY] = 'Error'
            df_copy[self.COL_FUNDING_STRATEGY] = 'Error'
            df_copy[self.COL_FINANCING_FUNDING] = 'Error'
            df_copy[self.COL_COMBINED_STRATEGY] = 'Error'
            
        return df_copy
    
    def get_strategy_summary(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Get summary statistics by strategy.
        
        Returns:
        DataFrame with strategy summary
        """
        if self.COL_FINANCING_STRATEGY not in df.columns or self.COL_FUNDING_STRATEGY not in df.columns:
            raise ValueError(f"DataFrame must contain both '{self.COL_FINANCING_STRATEGY}' and '{self.COL_FUNDING_STRATEGY}' columns. Run classify() first.")
        
        # Create summary for both strategies
        financing_summary = df.groupby(self.COL_FINANCING_STRATEGY).agg({
            self.COL_FINANCING_STRATEGY: 'count'
        }).rename(columns={self.COL_FINANCING_STRATEGY: 'Trade_Count'})
        
        funding_summary = df.groupby(self.COL_FUNDING_STRATEGY).agg({
            self.COL_FUNDING_STRATEGY: 'count'
        }).rename(columns={self.COL_FUNDING_STRATEGY: 'Trade_Count'})
        
        # Create summary for Financing/Funding classification
        financing_funding_summary = df.groupby(self.COL_FINANCING_FUNDING).agg({
            self.COL_FINANCING_FUNDING: 'count'
        }).rename(columns={self.COL_FINANCING_FUNDING: 'Trade_Count'})
        
        return financing_summary, funding_summary, financing_funding_summary
