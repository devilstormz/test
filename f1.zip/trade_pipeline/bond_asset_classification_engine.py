"""
Bond Asset Classification Engine for hierarchical bond classification.

This module contains the BondAssetClassificationEngine class that provides
hierarchical classification logic for bonds based on asset class, country,
currency, and other bond characteristics.
"""

import pandas as pd
import numpy as np
from typing import Dict, Tuple, Optional
import os


class BondAssetClassificationEngine:
    """
    Hierarchical bond asset classification engine based on the provided classification table.
    Uses np.select for efficient vectorized operations while maintaining condition order.
    """
    
    def __init__(self, debug_mode: bool = False):
        """
        Initialize the classification engine.
        
        Args:
            debug_mode: If True, adds intermediate debug columns to help troubleshoot failed mappings
        """
        self.debug_mode = debug_mode
    
    def _get_classification_conditions(self, df: pd.DataFrame) -> Dict[str, Dict]:
        """
        Generate classification conditions directly as boolean arrays for the given DataFrame.
        This is more efficient than storing lambda functions.
        """
        
        # Define core country groups for reuse
        egb_core_countries = ['DEU', 'FRA', 'NLD', 'AUT', 'BEL', 'FIN', 'IRL', 'LUX']
        egb_peripheral_countries = ['ITA', 'ESP', 'PRT', 'GRC', 'CYP', 'SVN', 'SVK', 'MLT']
        developed_countries = egb_core_countries + egb_peripheral_countries + ['GBR', 'USA', 'JPN']
        egb_all_countries = egb_core_countries + egb_peripheral_countries
        
        # Pre-compute common conditions for better performance and readability
        is_govt = df['BondHaircut.AssetClass'] == 'Govt'
        is_abs = df['BondHaircut.AssetClass'] == 'ABS'
        is_mbs = df['BondHaircut.AssetClass'] == 'MBS'
        is_ssa = df['BondHaircut.AssetClass'] == 'SSA'
        is_em = df['BondHaircut.AssetClass'] == 'EM'
        is_own_debt = df['BondHaircut.AssetClass'] == 'Own Issued Debt'
        is_na = df['BondHaircut.AssetClass'] == 'N/A'
        
        is_egb_core = df['Bond.Country'].isin(egb_core_countries)
        is_egb_peripheral = df['Bond.Country'].isin(egb_peripheral_countries)
        is_egb_any = df['Bond.Country'].isin(egb_all_countries)
        is_jpn = df['Bond.Country'] == 'JPN'
        is_developed = df['Bond.Country'].isin(developed_countries)
        
        is_eur = df['Bond.CRNCY'] == 'EUR'
        is_ust = df['Bond.Issuer.Name'] == 'United States Treasury'
        has_ukt = df['Bond.IssuerCode'].str.contains('UKT', na=False)
        has_jgb = df['Bond.Desc'].str.startswith('JGB', na=False)
        has_oat = df['Bond.Desc'].str.contains('OAT', na=False)
        has_bund = df['Bond.Desc'].str.contains('Bund', na=False)
        has_btp = df['Bond.Desc'].str.contains('BTP', na=False)
        has_bonos = df['Bond.Desc'].str.contains('Bonos', na=False)
        has_clo = df['Bond.Desc'].str.contains('CLO', na=False)
        has_cmbs = df['Bond.Desc'].str.contains('CMBS', na=False)
        has_rmbs = df['Bond.Desc'].str.contains('RMBS', na=False)
        
        is_muni = df['Bond.IsMuni'] == True
        is_agency = df['Bond.IsAgency'] == True
        is_covered = df['Bond.SecurityType'] == 'Covered'
        is_retained = df['Bond.ProgramType'] == 'Retained'
        is_spv = df['Bond.ProgramType'] == 'SPV'
        is_triparty = df['Bond.SourceSystem'] == 'Triparty'
        is_unknown_security = df['Bond.SecurityType'] == 'Unknown'
        has_missing_data = df.isnull().any(axis=1)
        
        # Level 4 conditions (most specific first) - return actual boolean arrays
        level4_conditions = [
            # French OATs
            is_govt & is_egb_core & is_eur & has_oat,
            
            # German Bunds
            is_govt & is_egb_core & is_eur & has_bund,
            
            # Italian BTPs
            is_govt & is_egb_peripheral & is_eur & has_btp,
            
            # Spanish Bonos
            is_govt & is_egb_peripheral & is_eur & has_bonos,
        ]
        
        level4_values = [
            'French OATs',
            'German Bunds', 
            'Italian BTPs',
            'Spanish Bonos'
        ]
        
        # Level 3 conditions
        level3_conditions = [
            # EGB Core (after Level 4 specific bonds)
            is_govt & is_egb_core & is_eur,
            
            # EGB Peripheral (after Level 4 specific bonds)
            is_govt & is_egb_peripheral & is_eur,
            
            # CLO with dynamic naming
            is_abs & has_clo,
        ]
        
        level3_values = [
            'EGB Core',
            'EGB Peripheral',
            'CLO_DYNAMIC'  # Special marker for dynamic generation
        ]
        
        # Level 2 conditions
        level2_conditions = [
            # UK Gilts
            is_govt & has_ukt,
            
            # UST
            is_govt & is_ust,
            
            # EGB (covers both Core and Peripheral)
            is_govt & is_egb_any & is_eur,
            
            # JGB
            is_govt & is_jpn & has_jgb,
            
            # EM with IG/Non-IG suffix
            is_em & (~is_developed),
            
            # CLO
            is_abs & has_clo,
            
            # CMBS
            is_mbs & has_cmbs,
            
            # RMBS
            is_mbs & has_rmbs,
            
            # Muni
            is_ssa & is_muni,
            
            # Agency
            is_ssa & is_agency,
            
            # Own Issued Debt - Covered
            is_own_debt & is_covered,
            
            # Own Issued Debt - Retained Bonds
            is_own_debt & is_retained,
            
            # Own Issued Debt - SPV issued bonds
            is_own_debt & is_spv,
            
            # Triparty
            is_na & is_triparty,
            
            # Other - Incomplete Data
            is_na & (is_unknown_security | has_missing_data),
        ]
        
        level2_values = [
            'UK Gilts',
            'UST',
            'EGB',
            'JGB',
            'EM_DYNAMIC',  # Special marker for IG/Non-IG suffix
            'CLO',
            'CMBS',
            'RMBS',
            'Muni',
            'Agency',
            'Covered',
            'Retained Bonds',
            'SPV issued bonds',
            'Triparty',
            'Other - Incomplete Data'
        ]
        
        # Level 1 is just the asset class itself
        level1_conditions = [
            df['BondHaircut.AssetClass'].notna()
        ]
        
        level1_values = [
            'ASSET_CLASS'  # Special marker to use the actual asset class value
        ]
        
        return {
            'level1': {'conditions': level1_conditions, 'values': level1_values},
            'level2': {'conditions': level2_conditions, 'values': level2_values},
            'level3': {'conditions': level3_conditions, 'values': level3_values},
            'level4': {'conditions': level4_conditions, 'values': level4_values}
        }
    
    def _apply_dynamic_naming(self, df: pd.DataFrame, level: str, base_classification: pd.Series) -> pd.Series:
        """
        Apply dynamic naming for special cases like EM_IG/NonIG and CLO classifications.
        Uses vectorized operations for better performance.
        """
        result = base_classification.copy()
        
        if level == 'level2':
            # Handle EM dynamic naming - fully vectorized
            em_mask = result == 'EM_DYNAMIC'
            if em_mask.any():
                # Vectorized IG suffix creation
                ig_suffix = np.where(df.loc[em_mask, 'Bond.IGFlag'], 'IG', 'Non-IG')
                result.loc[em_mask] = 'EM_' + ig_suffix
        
        elif level == 'level3':
            # Handle CLO dynamic naming - fully vectorized
            clo_mask = result == 'CLO_DYNAMIC'
            if clo_mask.any():
                # Vectorized CLO name creation
                clo_subset = df.loc[clo_mask]
                ig_flag = np.where(clo_subset['Bond.IGFlag'], 'IG', 'NonIG')
                result.loc[clo_mask] = (
                    'CLO_' + 
                    clo_subset['Bond.CRNCY'].astype(str) + '_' + 
                    ig_flag + '_' + 
                    clo_subset['Bond.RtgAvg'].astype(str)
                )
        
        return result
    
    def classify_bonds(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Classify bonds according to the hierarchical classification system.
        
        Args:
            df: DataFrame containing bond data with required columns
            
        Returns:
            DataFrame with additional classification columns
        """
        
        # Validate required columns
        required_columns = [
            'BondHaircut.AssetClass', 'Bond.IssuerCode', 'Bond.Issuer.Name',
            'Bond.Country', 'Bond.CRNCY', 'Bond.Desc', 'Bond.IGFlag',
            'Bond.RtgAvg', 'Bond.IsMuni', 'Bond.IsAgency', 'Bond.SecurityType',
            'Bond.ProgramType', 'Bond.SourceSystem'
        ]
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
        
        result_df = df.copy()
        
        # Add debug columns if in debug mode
        if self.debug_mode:
            self._add_debug_columns(result_df)
        
        # Get conditions for this specific DataFrame
        classification_conditions = self._get_classification_conditions(result_df)
        
        # Apply classification for each level
        for level_name in ['level1', 'level2', 'level3', 'level4']:
            level_config = classification_conditions[level_name]
            conditions = level_config['conditions']  # Already boolean arrays
            values = level_config['values']
            
            # Use np.select for efficient vectorized classification
            classification = np.select(conditions, values, default='Mapping Failed')
            
            # Handle special dynamic naming cases
            if level_name in ['level2', 'level3']:
                classification = self._apply_dynamic_naming(result_df, level_name, pd.Series(classification))
            
            # Handle Level 1 special case (use actual asset class value)
            if level_name == 'level1':
                classification = np.where(
                    classification == 'ASSET_CLASS',
                    result_df['BondHaircut.AssetClass'].fillna('Mapping Failed'),
                    classification
                )
            
            result_df[f'Classification_Level_{level_name[-1]}'] = classification
        
        return result_df
    
    def _add_debug_columns(self, df: pd.DataFrame) -> None:
        """
        Add debug columns to help troubleshoot failed mappings.
        """
        # Basic data quality checks
        df['Debug_HasCountry'] = df['Bond.Country'].notna()
        df['Debug_HasCurrency'] = df['Bond.CRNCY'].notna()
        df['Debug_HasDescription'] = df['Bond.Desc'].notna()
        df['Debug_HasIssuerCode'] = df['Bond.IssuerCode'].notna()
        df['Debug_HasIssuerName'] = df['Bond.Issuer.Name'].notna()
        df['Debug_HasAssetClass'] = df['BondHaircut.AssetClass'].notna()
        df['Debug_HasSecurityType'] = df['Bond.SecurityType'].notna()
        
        # Asset class validation
        valid_asset_classes = ['Govt', 'EM', 'ABS', 'MBS', 'Covered', 'SSA', 'Own Issued Debt', 'N/A']
        df['Debug_ValidAssetClass'] = df['BondHaircut.AssetClass'].isin(valid_asset_classes)
        
        # Country categorization
        egb_core_countries = ['DEU', 'FRA', 'NLD', 'AUT', 'BEL', 'FIN', 'IRL', 'LUX']
        egb_peripheral_countries = ['ITA', 'ESP', 'PRT', 'GRC', 'CYP', 'SVN', 'SVK', 'MLT']
        developed_countries = egb_core_countries + egb_peripheral_countries + ['GBR', 'USA', 'JPN']
        
        df['Debug_IsEGBCore'] = df['Bond.Country'].isin(egb_core_countries)
        df['Debug_IsEGBPeripheral'] = df['Bond.Country'].isin(egb_peripheral_countries)
        df['Debug_IsDeveloped'] = df['Bond.Country'].isin(developed_countries)
        df['Debug_IsEmerging'] = ~df['Bond.Country'].isin(developed_countries)
        
        # Currency validation
        df['Debug_IsEUR'] = df['Bond.CRNCY'] == 'EUR'
        df['Debug_IsUSD'] = df['Bond.CRNCY'] == 'USD'
        df['Debug_IsGBP'] = df['Bond.CRNCY'] == 'GBP'
        df['Debug_IsJPY'] = df['Bond.CRNCY'] == 'JPY'
        
        # Description pattern matching
        df['Debug_HasUKT'] = df['Bond.IssuerCode'].str.contains('UKT', na=False)
        df['Debug_IsUST'] = df['Bond.Issuer.Name'] == 'United States Treasury'
        df['Debug_HasJGB'] = df['Bond.Desc'].str.startswith('JGB', na=False)
        df['Debug_HasOAT'] = df['Bond.Desc'].str.contains('OAT', na=False)
        df['Debug_HasBund'] = df['Bond.Desc'].str.contains('Bund', na=False)
        df['Debug_HasBTP'] = df['Bond.Desc'].str.contains('BTP', na=False)
        df['Debug_HasBonos'] = df['Bond.Desc'].str.contains('Bonos', na=False)
        df['Debug_HasCLO'] = df['Bond.Desc'].str.contains('CLO', na=False)
        df['Debug_HasCMBS'] = df['Bond.Desc'].str.contains('CMBS', na=False)
        df['Debug_HasRMBS'] = df['Bond.Desc'].str.contains('RMBS', na=False)
        
        # Overall data completeness score
        debug_cols = [col for col in df.columns if col.startswith('Debug_Has')]
        df['Debug_DataCompleteness'] = df[debug_cols].sum(axis=1) / len(debug_cols)
        
        # Flag potential problem records
        df['Debug_PotentialIssue'] = (
            (df['Debug_DataCompleteness'] < 0.8) |
            (~df['Debug_ValidAssetClass']) |
            (df['Bond.Country'].isna()) |
            (df['Bond.Desc'].isna())
        )
    
    def classify_from_excel(self, file_path: str, sheet_name: str = None) -> pd.DataFrame:
        """
        Classify bonds from an Excel file.
        
        Args:
            file_path: Path to the Excel file
            sheet_name: Name of the sheet to read (if None, reads first sheet)
            
        Returns:
            Classified DataFrame
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Excel file not found: {file_path}")
        
        try:
            if sheet_name:
                df = pd.read_excel(file_path, sheet_name=sheet_name)
            else:
                df = pd.read_excel(file_path)
                
            print(f"Loaded {len(df)} bonds from Excel file: {file_path}")
            if sheet_name:
                print(f"Sheet: {sheet_name}")
            
            return self.classify_bonds(df)
            
        except Exception as e:
            raise Exception(f"Error reading Excel file: {str(e)}")
    
    def export_to_excel(self, df: pd.DataFrame, file_path: str, include_debug: bool = None) -> None:
        """
        Export classified results to Excel with multiple sheets.
        
        Args:
            df: Classified DataFrame
            file_path: Output Excel file path
            include_debug: Whether to include debug columns (defaults to self.debug_mode)
        """
        if include_debug is None:
            include_debug = self.debug_mode
            
        with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
            # Main results
            main_cols = [col for col in df.columns if not col.startswith('Debug_')]
            df[main_cols].to_excel(writer, sheet_name='Classifications', index=False)
            
            # Debug sheet if requested
            if include_debug and any(col.startswith('Debug_') for col in df.columns):
                debug_cols = ['Bond.Desc'] + [col for col in df.columns if col.startswith('Debug_')]
                df[debug_cols].to_excel(writer, sheet_name='Debug', index=False)
            
            # Summary sheet
            summary = self.get_classification_summary(df)
            row = 0
            for level, data in summary.items():
                data.to_excel(writer, sheet_name='Summary', startrow=row, index=False)
                row += len(data) + 3
            
            # Failed mappings sheet
            failed_mappings = self.get_failed_mappings(df)
            if not failed_mappings.empty:
                failed_mappings.to_excel(writer, sheet_name='Failed_Mappings', index=False)
        
        print(f"Results exported to: {file_path}")
    
    def get_failed_mappings(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Get all bonds that failed to map at any level.
        
        Args:
            df: Classified DataFrame
            
        Returns:
            DataFrame with failed mappings only
        """
        classification_cols = [col for col in df.columns if col.startswith('Classification_Level_')]
        
        if not classification_cols:
            return pd.DataFrame()
        
        # Find rows where any classification level failed
        failed_mask = df[classification_cols].eq('Mapping Failed').any(axis=1)
        
        if not failed_mask.any():
            return pd.DataFrame()
        
        # Select relevant columns for debugging
        base_cols = [
            'BondHaircut.AssetClass', 'Bond.Country', 'Bond.CRNCY', 'Bond.Desc',
            'Bond.IssuerCode', 'Bond.Issuer.Name', 'Bond.SecurityType', 'Bond.IGFlag'
        ]
        
        debug_cols = [col for col in df.columns if col.startswith('Debug_')]
        result_cols = base_cols + classification_cols + debug_cols
        
        # Only include columns that exist in the DataFrame
        available_cols = [col for col in result_cols if col in df.columns]
        
        return df[failed_mask][available_cols].copy()
    
    def get_classification_summary(self, df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
        """
        Get a summary of classifications at each level.
        
        Args:
            df: Classified DataFrame
            
        Returns:
            Dictionary with summary DataFrames for each level
        """
        summaries = {}
        
        for level in [1, 2, 3, 4]:
            col_name = f'Classification_Level_{level}'
            if col_name in df.columns:
                summary = df[col_name].value_counts().reset_index()
                summary.columns = [col_name, 'Count']
                summary['Percentage'] = (summary['Count'] / len(df) * 100).round(2)
                summaries[f'Level_{level}'] = summary
        
        return summaries
    
    def validate_classification(self, df: pd.DataFrame) -> Dict[str, any]:
        """
        Validate the classification results and identify any issues.
        
        Args:
            df: Classified DataFrame
            
        Returns:
            Dictionary with validation results
        """
        validation_results = {
            'total_bonds': len(df),
            'unclassified_bonds': {},
            'classification_coverage': {},
            'potential_issues': []
        }
        
        for level in [1, 2, 3, 4]:
            col_name = f'Classification_Level_{level}'
            if col_name in df.columns:
                unclassified_count = (df[col_name] == '').sum()
                validation_results['unclassified_bonds'][f'Level_{level}'] = unclassified_count
                validation_results['classification_coverage'][f'Level_{level}'] = {
                    'classified': len(df) - unclassified_count,
                    'percentage': ((len(df) - unclassified_count) / len(df) * 100).round(2)
                }
        
        # Check for potential data quality issues
        if 'Bond.Country' in df.columns:
            missing_country = df['Bond.Country'].isna().sum()
            if missing_country > 0:
                validation_results['potential_issues'].append(
                    f"{missing_country} bonds have missing country information"
                )
        
        if 'Bond.Desc' in df.columns:
            missing_desc = df['Bond.Desc'].isna().sum()
            if missing_desc > 0:
                validation_results['potential_issues'].append(
                    f"{missing_desc} bonds have missing description information"
                )
        
        return validation_results
