"""
Collateral Swap Engine for comprehensive swap identification and classification.
"""
import pandas as pd
import numpy as np
from collections import namedtuple
from typing import Dict, List, Optional, Tuple, Any
import os

# Import shared enums from config
from trading_analytics_framework.trade_pipeline.config import (
    MagTradeType, SwapType, TransactionType, HqlaStatus, BondAssetType, 
    PrdsCode, ColumnName
)

# Import bond rating engine
from trading_analytics_framework.trade_pipeline.bond_rating_engine import BondScoringEngine

# Configuration structures
ApproachConfig = namedtuple('ApproachConfig', [
    'enabled', 'desk_logic', 'contract_id', 'secured_flag'
])

HierarchyConfig = namedtuple('HierarchyConfig', [
    'hqla_enabled', 'rating_enabled', 'use_worst_rating_field'
])

class CollateralSwapEngine:
    """
    A comprehensive collateral swap identification and classification engine
    supporting multiple rule-based approaches with configurable hierarchy logic.
    """
    
    def __init__(self, 
                 desk_logic: bool = True,
                 contract_id: bool = True,
                 hqla_enabled: bool = True,
                 rating_enabled: bool = True,
                 use_worst_rating_field: bool = False,
                 market_value_threshold: float = 1e7,
                 excluded_counterparties: list = None,
                 excluded_books: list = None,
                 excluded_counterparty_codes: list = None,
                 accounting_treatment_threshold: str = 'ACA',
                 enable_debug_columns: bool = False):
        
        # Create config structures from parameters
        self.approach_config = ApproachConfig(
            enabled=True,
            desk_logic=desk_logic,
            contract_id=contract_id,
            secured_flag=False  # No longer used
        )
        
        self.hierarchy_config = HierarchyConfig(
            hqla_enabled=hqla_enabled,
            rating_enabled=rating_enabled,
            use_worst_rating_field=use_worst_rating_field
        )
        
        # Threshold configuration
        self.market_value_threshold = market_value_threshold
        
        # Waterfall rules
        self.excluded_counterparties = excluded_counterparties or ['CPTY_EXCLUDE_1', 'CPTY_EXCLUDE_2']
        self.excluded_books = excluded_books or ['BOOK_A', 'BOOK_B']
        self.excluded_counterparty_codes = excluded_counterparty_codes or ['CPTY_A', 'CPTY_B']
        self.accounting_treatment_threshold = accounting_treatment_threshold
        
        # Debug configuration
        self.enable_debug_columns = enable_debug_columns
        
        # Output column names as class variables
        self.COLLATERAL_SWAP_INDICATOR = 'collateral_swap_indicator'
        self.TRADE_GROUP_SYNTHETIC_KEY = 'trade_group_synthetic_key'
        self.COLLATERAL_SWAP_ID = 'collateral_swap_id'
        self.COLLATERAL_SWAP_TYPE = 'collateral_swap_type'
        self.TRANSACTION_TYPE = 'transaction_type'
        self.COLLATERAL_SWAP_CONSTRUCTION = 'collateral_swap_construction'
        
        # Intermediate calculation columns
        self.TRADE_DIRECTION = 'trade_direction'
        self.DIRECTIONAL_MARKET_VALUE = 'directional_market_value'
        self.SYNTHETIC_KEY_DESK = 'synthetic_key_desk'
        self.SYNTHETIC_KEY_CONTRACT = 'synthetic_key_contract'
        self.GROUP_SUM = 'group_sum'
        self.GROUP_SUM_CONTRACT = 'group_sum_contract'
        self.HIERARCHY_SCORE = 'hierarchy_score'
        self.COLLATERAL_DIRECTION = 'collateral_direction'
        
        # Debug columns
        self.DEBUG_APPROACH_USED = 'debug_approach_used'
        self.DEBUG_RULE_APPLIED = 'debug_rule_applied'
        self.DEBUG_MARKET_VALUE = 'debug_market_value'
        self.DEBUG_GROUP_SUM = 'debug_group_sum'
        self.DEBUG_HIERARCHY_SCORE = 'debug_hierarchy_score'
        
        # Valid trade type combinations for collateral swaps
        self.valid_swap_combinations = {
            frozenset([MagTradeType.BB.value, MagTradeType.BL.value]),
            frozenset([MagTradeType.REP.value, MagTradeType.REV.value]),
            frozenset([MagTradeType.TP.value, MagTradeType.TR.value]),
            frozenset([MagTradeType.TPR.value, MagTradeType.TRV.value]),
            frozenset([MagTradeType.TPB.value, MagTradeType.TPL.value])
        }
        
        # Initialize bond rating engine for rating calculations
        self.bond_rating_engine = BondScoringEngine()
        
        # Trade types that involve cash (repos)
        self.cash_based_trade_types = {
            MagTradeType.REP.value, MagTradeType.REV.value,
            MagTradeType.TP.value, MagTradeType.TR.value,
            MagTradeType.TPR.value, MagTradeType.TRV.value
        }
        
        # Trade types that don't involve cash (bond borrow/lend)
        self.non_cash_trade_types = {
            MagTradeType.BB.value, MagTradeType.BL.value,
            MagTradeType.TPB.value, MagTradeType.TPL.value
        }
        
        self.swap_counter = 0
    
    def load_from_excel(self, file_path: str, sheet_name: str = 'Sheet1') -> pd.DataFrame:
        """
        Load test data from Excel file for testing purposes.
        
        Parameters:
        -----------
        file_path : str
            Path to the Excel file
        sheet_name : str, default 'Sheet1'
            Name of the sheet to load
            
        Returns:
        --------
        pd.DataFrame
            Loaded dataframe
            
        Raises:
        -------
        FileNotFoundError
            If the Excel file doesn't exist
        ValueError
            If the file doesn't contain required columns
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Excel file not found: {file_path}")
        
        try:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            print(f"✓ Successfully loaded {len(df)} rows from {file_path}")
            
            # Validate required columns
            required_columns = [
                ColumnName.TRADE_ID.value,
                ColumnName.TRADE_TYPE.value,
                ColumnName.COUNTERPARTY_ID.value,
                ColumnName.MATURITY_DATE.value,
                ColumnName.NOTIONAL.value,
                ColumnName.MARKET_PRICE.value
            ]
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                print(f"⚠ Warning: Missing columns: {missing_columns}")
                print("Available columns:", list(df.columns))
            
            return df
            
        except Exception as e:
            raise ValueError(f"Error loading Excel file: {str(e)}")
    
    def create_sample_excel(self, file_path: str = "collateral_swap_test_data.xlsx") -> str:
        """
        Create a sample Excel file with test data for collateral swap engine.
        
        Parameters:
        -----------
        file_path : str, default "collateral_swap_test_data.xlsx"
            Path where to save the sample Excel file
            
        Returns:
        --------
        str
            Path to the created file
        """
        sample_data = {
            ColumnName.TRADE_ID.value: [f'TRADE_{i:03d}' for i in range(1, 21)],
            ColumnName.BOOKING_SYSTEM.value: ['B-E', 'MAG', 'B-E', 'MAG', 'B-E'] * 4,
            ColumnName.TRADE_TYPE.value: ['REP', 'REV', 'BB', 'BL', 'TP', 'TR', 'TPR', 'TRV', 'TPB', 'TPL'] * 2,
            ColumnName.COUNTERPARTY.value: [f'CPTY_{i:03d}' for i in range(1, 21)],
            ColumnName.COUNTERPARTY_ID.value: ['CPTY_A', 'CPTY_B', 'CPTY_C', 'CPTY_D', 'CPTY_E'] * 4,
            ColumnName.NOTIONAL.value: [1000000, 2000000, 1500000, 2500000, 3000000] * 4,
            ColumnName.CURRENCY.value: ['EUR', 'USD', 'GBP', 'EUR', 'USD'] * 4,
            ColumnName.MARKET_PRICE.value: [100.5, 99.8, 101.2, 100.0, 100.5] * 4,
            ColumnName.MATURITY_DATE.value: ['2024-06-15', '2024-07-20', '2024-08-10', '2024-09-05', '2024-10-01'] * 4,
            ColumnName.CONTRACT_ID.value: [f'CONTRACT_{i:03d}' for i in range(1, 21)],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [True, False, True, False, True] * 4,
            'is_secured': [True, True, False, True, True] * 4,
            ColumnName.FX_RATE.value: [1.0, 0.85, 1.15, 1.0, 0.85] * 4,
            ColumnName.LEG_START_CASH.value: [1000000, 0, 0, 2000000, 0] * 4,
            ColumnName.ACCOUNTING_TREATMENT.value: ['ACA', 'ACA', 'ACA', 'ACA', 'ACA'] * 4,
            ColumnName.HQLA_STATUS.value: ['Level 1', 'Level 2A', 'Level 2B', 'Non-HQLA', 'Level 1'] * 4,
            'worst_rating': ['AA', 'BBB', 'BB', 'B', 'AA'] * 4,
            ColumnName.BOND_RATING_SP.value: ['AA+', 'BBB+', 'BB+', 'B+', 'AA'] * 4,
            ColumnName.BOND_RATING_MOODY.value: ['Aa1', 'Baa1', 'Ba1', 'B1', 'Aa2'] * 4,
            ColumnName.BOND_RATING_FITCH.value: ['AA', 'BBB', 'BB', 'B', 'AA-'] * 4,
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT', 'CORP_SENIOR', 'CORP_JUNIOR', 'ABS_CLO', 'GOVT'] * 4,
            ColumnName.PRD.value: ['REPO', 'REPO', 'BOND_BORROW', 'BOND_LEND', 'REPO'] * 4
        }
        
        df = pd.DataFrame(sample_data)
        
        try:
            df.to_excel(file_path, index=False, sheet_name='TradeData')
            print(f"✓ Sample Excel file created: {file_path}")
            return file_path
        except Exception as e:
            raise ValueError(f"Error creating sample Excel file: {str(e)}")
    
    def process_trades(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Main processing function that applies the enabled identification approaches
        and classification logic to the trade dataset.
        """
        result_df = df.copy()
        
        # Initialize result columns
        result_df = self._initialize_result_columns(result_df)
        
        # Apply enabled approaches
        if self.approach_config.desk_logic:
            result_df = self._apply_desk_logic_approach(result_df)
        
        if self.approach_config.contract_id:
            result_df = self._apply_contract_id_approach(result_df)
        
        # Apply swap type classification for identified swaps
        result_df = self._classify_swap_types(result_df)
        
        # Apply transaction type classification
        result_df = self._classify_transaction_types(result_df)
        
        return result_df
    
    def _initialize_result_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Initialize all result columns with default values."""
        df[self.COLLATERAL_SWAP_INDICATOR] = False
        df[self.TRADE_GROUP_SYNTHETIC_KEY] = ''
        df[self.COLLATERAL_SWAP_ID] = 0
        df[self.COLLATERAL_SWAP_TYPE] = SwapType.NEUTRAL.value
        df[self.TRANSACTION_TYPE] = TransactionType.FINANCING.value
        df[self.COLLATERAL_SWAP_CONSTRUCTION] = ''
        
        if self.enable_debug_columns:
            df[self.DEBUG_APPROACH_USED] = ''
            df[self.DEBUG_RULE_APPLIED] = ''
            df[self.DEBUG_MARKET_VALUE] = 0.0
            df[self.DEBUG_GROUP_SUM] = 0.0
            df[self.DEBUG_HIERARCHY_SCORE] = 0.0
        
        return df
    
    def _set_swap_construction(self, df: pd.DataFrame, mask: pd.Series, group_key_col: str) -> pd.DataFrame:
        """
        Set the collateral swap construction based on trade type combinations within each group.
        """
        
        # Define trade type combination mappings
        construction_mapping = {
            frozenset([MagTradeType.BB.value, MagTradeType.BL.value]): 'BB+BL',
            frozenset([MagTradeType.REP.value, MagTradeType.REV.value]): 'REP+REV',
            frozenset([MagTradeType.TP.value, MagTradeType.TR.value]): 'TP+TR',
            frozenset([MagTradeType.TPR.value, MagTradeType.TRV.value]): 'TPR+TRV',
            frozenset([MagTradeType.TPB.value, MagTradeType.TPL.value]): 'TPB+TPL'
        }
        
        # Process each group to determine construction
        if mask.any():
            for group_key in df.loc[mask, group_key_col].unique():
                group_mask = (df[group_key_col] == group_key) & mask
                
                # Get unique trade types in this group
                trade_types_in_group = set(df.loc[group_mask, ColumnName.TRADE_TYPE.value].unique())
                trade_types_frozen = frozenset(trade_types_in_group)
                
                # Find matching construction pattern
                construction = 'UNKNOWN'
                for pattern, construction_name in construction_mapping.items():
                    if pattern.issubset(trade_types_frozen):
                        construction = construction_name
                        break
                
                # If no exact match, create a descriptive name
                if construction == 'UNKNOWN' and len(trade_types_in_group) > 1:
                    construction = '+'.join(sorted(trade_types_in_group))
                elif construction == 'UNKNOWN' and len(trade_types_in_group) == 1:
                    construction = list(trade_types_in_group)[0] + '_SINGLE'
                
                df.loc[group_mask, self.COLLATERAL_SWAP_CONSTRUCTION] = construction
                
        return df
    
    def _calculate_directional_market_value(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate EUR directional market value based on PRDS code and trade type."""
        df = df.copy()
        
        # Determine trade direction based on trade type
        repo_types = [MagTradeType.REP.value, MagTradeType.TP.value, 
                     MagTradeType.TPR.value, MagTradeType.TPB.value]
        reverse_repo_types = [MagTradeType.REV.value, MagTradeType.TR.value,
                             MagTradeType.TRV.value, MagTradeType.TPL.value]
        bond_borrow_types = [MagTradeType.BB.value]
        bond_lend_types = [MagTradeType.BL.value]
        
        # Trade direction: 1 for giving collateral, -1 for receiving
        df[self.TRADE_DIRECTION] = np.select([
            df[ColumnName.TRADE_TYPE.value].isin(repo_types + bond_lend_types),
            df[ColumnName.TRADE_TYPE.value].isin(reverse_repo_types + bond_borrow_types)
        ], [1, -1], default=0)
        
        # Get FX rate column (default to 1.0 if not available)
        fx_rate = df[ColumnName.FX_RATE.value] if ColumnName.FX_RATE.value in df.columns else 1.0
        
        # Calculate directional market value based on PRDS code and trade type
        is_cash_based = (
            df[ColumnName.TRADE_TYPE.value].isin(self.cash_based_trade_types) |
            (df[ColumnName.PRD.value] == PrdsCode.REPO.value) if ColumnName.PRD.value in df.columns else 
            df[ColumnName.TRADE_TYPE.value].isin(self.cash_based_trade_types)
        )
        
        # Method 1: For non-cash based (bond borrow/lend) - Notional * Price * FX * Direction
        method1 = (df[ColumnName.NOTIONAL.value] * df[ColumnName.MARKET_PRICE.value] * fx_rate * 
                  df[self.TRADE_DIRECTION])
        
        # Method 2: For cash based (repos) - StartCash * Direction * Market Price * FX
        if ColumnName.LEG_START_CASH.value in df.columns:
            method2 = (df[ColumnName.LEG_START_CASH.value] * df[self.TRADE_DIRECTION] * 
                      df[ColumnName.MARKET_PRICE.value] * fx_rate)
            
            # Use method2 for cash-based trades where start_cash is available, otherwise method1
            df[self.DIRECTIONAL_MARKET_VALUE] = np.where(
                is_cash_based & df[ColumnName.LEG_START_CASH.value].notna(), 
                method2, 
                method1
            )
        else:
            # If start_cash not available, use method1 for all
            df[self.DIRECTIONAL_MARKET_VALUE] = method1
        
        if self.enable_debug_columns:
            df[self.DEBUG_MARKET_VALUE] = df[self.DIRECTIONAL_MARKET_VALUE]
        
        return df
    
    def _apply_desk_logic_approach(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply Approach 1: Desk logic waterfall approach using np.select."""
        df = self._calculate_directional_market_value(df)
        
        # Create synthetic key for grouping
        df[self.SYNTHETIC_KEY_DESK] = (
            df[ColumnName.COUNTERPARTY_ID.value].astype(str) + '_' + 
            df[ColumnName.MATURITY_DATE.value].astype(str)
        )
        
        # Calculate group sums
        group_sums = df.groupby(self.SYNTHETIC_KEY_DESK)[self.DIRECTIONAL_MARKET_VALUE].sum()
        df[self.GROUP_SUM] = df[self.SYNTHETIC_KEY_DESK].map(group_sums)
        
        # Apply waterfall logic using numpy.select - WATERFALL APPROACH
        # NOTE: Conditions are NOT mutually exclusive - multiple conditions can be true
        # for the same trade. np.select() returns result for FIRST matching condition.
        # Each condition is checked in order, first match wins (true waterfall behavior)
        conditions = [
            # RULE 1: Excluded counterparties with bond borrow/lend -> NOT a collateral swap
            (df[ColumnName.COUNTERPARTY_ID.value].isin(self.excluded_counterparties) & 
             df[ColumnName.TRADE_TYPE.value].isin([MagTradeType.BB.value, MagTradeType.BL.value])),
            
            # RULE 2: Excluded books or counterparties -> NOT a collateral swap
            (df[ColumnName.BOOKING_SYSTEM.value].isin(self.excluded_books) | 
             df[ColumnName.COUNTERPARTY_ID.value].isin(self.excluded_counterparty_codes)),
            
            # RULE 3: Accounting treatment check -> IS a collateral swap
            (df[ColumnName.ACCOUNTING_TREATMENT.value] != self.accounting_treatment_threshold) 
            if ColumnName.ACCOUNTING_TREATMENT.value in df.columns 
            else False,
            
            # RULE 4: Market value threshold check -> IS a collateral swap
            (df[self.GROUP_SUM] < self.market_value_threshold)
        ]
        
        # Choices corresponding to conditions (True = is collateral swap, False = is not)
        choices = [False, False, True, True]
        default = False
        
        # Apply waterfall logic - first matching condition determines the result
        desk_swap_flag = np.select(conditions, choices, default=default)
        
        # Update results for desk logic approach
        mask = desk_swap_flag
        df.loc[mask, self.COLLATERAL_SWAP_INDICATOR] = True
        df.loc[mask, self.TRADE_GROUP_SYNTHETIC_KEY] = df.loc[mask, self.SYNTHETIC_KEY_DESK]
        
        # Set construction based on trade type combinations in each group
        df = self._set_swap_construction(df, mask, self.SYNTHETIC_KEY_DESK)
        
        if self.enable_debug_columns:
            df.loc[mask, self.DEBUG_APPROACH_USED] = 'DESK_LOGIC'
            df.loc[mask, self.DEBUG_GROUP_SUM] = df.loc[mask, self.GROUP_SUM]
            
            # Debug rule applied - show which rule was triggered
            rule_applied = np.select(conditions, 
                                   ['RULE1_EXCLUDED_CPTY', 'RULE2_EXCLUDED_BOOK', 
                                    'RULE3_ACCOUNTING', 'RULE4_THRESHOLD'], 
                                   default='NO_RULE')
            df.loc[mask, self.DEBUG_RULE_APPLIED] = rule_applied[mask]
        
        return df
    
    def _apply_contract_id_approach(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply Approach 2: Booking collateral swap flag + contract ID based approach."""
        df = self._calculate_directional_market_value(df)
        
        # Create synthetic key using contract_id
        df[self.SYNTHETIC_KEY_CONTRACT] = (
            df[ColumnName.COUNTERPARTY_ID.value].astype(str) + '_' + 
            df[ColumnName.MATURITY_DATE.value].astype(str) + '_' + 
            df[ColumnName.CONTRACT_ID.value].astype(str) + '_' + 
            df[ColumnName.TRADE_TYPE.value].astype(str)
        )
        
        # Calculate group sums
        group_sums = df.groupby(self.SYNTHETIC_KEY_CONTRACT)[self.DIRECTIONAL_MARKET_VALUE].sum()
        df[self.GROUP_SUM_CONTRACT] = df[self.SYNTHETIC_KEY_CONTRACT].map(group_sums)
        
        # Apply new logic: booking_collateral_swap_flag = True AND group sum market value < threshold
        contract_swap_flag = (
            (df[ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value] == True) &
            (np.abs(df[self.GROUP_SUM_CONTRACT]) < self.market_value_threshold) & 
            (df[ColumnName.CONTRACT_ID.value].notna())
        ) if ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value in df.columns else False
        
        # Update results for contract ID approach (only if not already identified by desk logic)
        mask = contract_swap_flag & ~df[self.COLLATERAL_SWAP_INDICATOR]
        df.loc[mask, self.COLLATERAL_SWAP_INDICATOR] = True
        df.loc[mask, self.TRADE_GROUP_SYNTHETIC_KEY] = df.loc[mask, self.SYNTHETIC_KEY_CONTRACT]
        
        # Set construction based on trade type combinations in each group
        df = self._set_swap_construction(df, mask, self.SYNTHETIC_KEY_CONTRACT)
        
        if self.enable_debug_columns:
            df.loc[mask, self.DEBUG_APPROACH_USED] = 'CONTRACT_ID'
            df.loc[mask, self.DEBUG_GROUP_SUM] = df.loc[mask, self.GROUP_SUM_CONTRACT]
            df.loc[mask, self.DEBUG_RULE_APPLIED] = 'BOOKING_FLAG_AND_THRESHOLD'
        
        return df
    

    
    def _classify_swap_types(self, df: pd.DataFrame) -> pd.DataFrame:
        """Classify collateral swaps as upgrade, downgrade, or neutral."""
        # Only process identified collateral swaps
        swap_mask = df[self.COLLATERAL_SWAP_INDICATOR] == True
        
        if not swap_mask.any():
            return df
        
        # Calculate hierarchy scores
        df = self._calculate_hierarchy_scores(df)
        
        # Group by trade group key and calculate swap types
        for group_key in df.loc[swap_mask, self.TRADE_GROUP_SYNTHETIC_KEY].unique():
            group_mask = (df[self.TRADE_GROUP_SYNTHETIC_KEY] == group_key) & swap_mask
            group_df = df.loc[group_mask]
            
            if len(group_df) < 2:
                continue
            
            # Determine collateral direction (given vs received)
            repo_giving_types = [MagTradeType.REP.value, MagTradeType.TP.value,
                               MagTradeType.TPR.value, MagTradeType.BL.value]
            
            df.loc[group_mask, self.COLLATERAL_DIRECTION] = np.where(
                df.loc[group_mask, ColumnName.TRADE_TYPE.value].isin(repo_giving_types), 
                'GIVING', 
                'RECEIVING'
            )
            
            # Calculate average scores for given and received collateral
            giving_mask = group_mask & (df[self.COLLATERAL_DIRECTION] == 'GIVING')
            receiving_mask = group_mask & (df[self.COLLATERAL_DIRECTION] == 'RECEIVING')
            
            if giving_mask.any() and receiving_mask.any():
                avg_given_score = df.loc[giving_mask, self.HIERARCHY_SCORE].mean()
                avg_received_score = df.loc[receiving_mask, self.HIERARCHY_SCORE].mean()
                
                # Determine swap type (lower score = higher quality)
                if avg_given_score < avg_received_score:  # Giving higher quality
                    swap_type = SwapType.DOWNGRADE.value
                elif avg_given_score > avg_received_score:  # Giving lower quality
                    swap_type = SwapType.UPGRADE.value
                else:
                    swap_type = SwapType.NEUTRAL.value
                
                df.loc[group_mask, self.COLLATERAL_SWAP_TYPE] = swap_type
                
                # Assign sequential swap IDs
                self.swap_counter += 1
                df.loc[group_mask, self.COLLATERAL_SWAP_ID] = self.swap_counter
        
        return df
    
    def _calculate_hierarchy_scores(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate combined hierarchy scores based on enabled hierarchy layers."""
        df[self.HIERARCHY_SCORE] = 0.0
        
        if self.hierarchy_config.hqla_enabled and ColumnName.HQLA_STATUS.value in df.columns:
            hqla_scores = df[ColumnName.HQLA_STATUS.value].map({
                HqlaStatus.LEVEL_1.value: 1,
                HqlaStatus.LEVEL_2A.value: 2,
                HqlaStatus.LEVEL_2B.value: 3,
                HqlaStatus.NON_HQLA.value: 4
            }).fillna(4)  # Default to worst if missing
            df[self.HIERARCHY_SCORE] += hqla_scores
        
        if self.hierarchy_config.rating_enabled:
            # Use bond rating engine's compute_scores method
            rating_scores = self._calculate_rating_scores_using_bond_engine(df)
            df[self.HIERARCHY_SCORE] += rating_scores
        
        # Asset type scoring is now handled by the bond rating engine's compute_scores method
        # No need to add asset type scores here as they're already included in the rating scores
        
        if self.enable_debug_columns:
            df[self.DEBUG_HIERARCHY_SCORE] = df[self.HIERARCHY_SCORE]
        
        return df
    
    def _calculate_rating_scores_using_bond_engine(self, df: pd.DataFrame) -> pd.Series:
        """
        Calculate rating scores using the bond rating engine's compute_scores method.
        Maps existing column names to bond rating engine format and uses the full scoring logic.
        """
        # Create a temporary dataframe with bond rating engine column names
        temp_df = df.copy()
        
        # Map existing column names to bond rating engine expected names
        column_mapping = {
            ColumnName.BOND_RATING_SP.value: 'Bond.RtySP',
            ColumnName.BOND_RATING_MOODY.value: 'Bond.RtyMDY', 
            ColumnName.BOND_RATING_FITCH.value: 'Bond.RtyFITCH'
        }
        
        # Rename columns that exist in the dataframe
        for old_col, new_col in column_mapping.items():
            if old_col in temp_df.columns:
                temp_df[new_col] = temp_df[old_col]
        
        # Add missing columns that bond rating engine expects
        if 'Bond.RtyDB' not in temp_df.columns:
            temp_df['Bond.RtyDB'] = None
        
        # Add issuer rating columns if not present
        issuer_columns = ['Bond.Issuer.RtyDB', 'Bond.Issuer.RtySP', 'Bond.Issuer.RtyMDY', 'Bond.Issuer.RtyFITCH']
        for col in issuer_columns:
            if col not in temp_df.columns:
                temp_df[col] = None
        
        # Add subordinated column if not present
        if 'subordinated' not in temp_df.columns:
            temp_df['subordinated'] = False
        
        # Add RtgAvg column if not present
        if 'RtgAvg' not in temp_df.columns:
            temp_df['RtgAvg'] = None
        
        # Add Bond.CollatType column if not present (map from BOND_ASSET_TYPE)
        if 'Bond.CollatType' not in temp_df.columns and ColumnName.BOND_ASSET_TYPE.value in temp_df.columns:
            # Map bond asset types to bond rating engine format
            asset_type_mapping = {
                BondAssetType.GOVT.value: 'GOVT',
                BondAssetType.CORP_SENIOR.value: 'CORP',
                BondAssetType.CORP_JUNIOR.value: 'CORP',
                BondAssetType.ABS_CLO.value: 'CLO/ABS'
            }
            temp_df['Bond.CollatType'] = temp_df[ColumnName.BOND_ASSET_TYPE.value].map(asset_type_mapping).fillna('Other')
        elif 'Bond.CollatType' not in temp_df.columns:
            temp_df['Bond.CollatType'] = 'Other'
        
        # Set the trade dataframe in the bond rating engine
        self.bond_rating_engine.trade_df = temp_df
        
        # Use bond rating engine's compute_scores method with worst-of approach
        result_df = self.bond_rating_engine.compute_scores(use_average=False, use_fallback_logic=True)
        
        # Return the final scores which include both rating and asset classification components
        return result_df['final_score']
    
    def _classify_transaction_types(self, df: pd.DataFrame) -> pd.DataFrame:
        """Classify transactions as financing, funding, collateral swap, or unsecured bond."""
        bond_types = [MagTradeType.BB.value, MagTradeType.BL.value]
        
        # Unsecured bond borrow/lend
        unsecured_condition = (
            df[ColumnName.TRADE_TYPE.value].isin(bond_types) &
            (df['is_secured'] != True) if 'is_secured' in df.columns
            else False
        )
        df.loc[unsecured_condition, self.TRANSACTION_TYPE] = TransactionType.UNSECURED_BOND.value
        
        # Collateral swaps (already identified)
        swap_mask = df[self.COLLATERAL_SWAP_INDICATOR] == True
        df.loc[swap_mask, self.TRANSACTION_TYPE] = TransactionType.COLLATERAL_SWAP.value
        
        # Remaining repo/reverse repo transactions
        repo_types = [MagTradeType.REP.value, MagTradeType.TP.value, 
                     MagTradeType.TPR.value]
        reverse_repo_types = [MagTradeType.REV.value, MagTradeType.TR.value,
                             MagTradeType.TRV.value]
        
        remaining_mask = ~(unsecured_condition | swap_mask)
        
        df.loc[remaining_mask & df[ColumnName.TRADE_TYPE.value].isin(repo_types), self.TRANSACTION_TYPE] = TransactionType.FINANCING.value
        df.loc[remaining_mask & df[ColumnName.TRADE_TYPE.value].isin(reverse_repo_types), self.TRANSACTION_TYPE] = TransactionType.FUNDING.value
        
        return df

# Example usage and configuration
def create_default_config():
    """Create default configuration for the collateral swap engine."""
    return {
        'desk_logic': True,
        'contract_id': True,
        'hqla_enabled': True,
        'rating_enabled': True,
        'use_worst_rating_field': False,
        'market_value_threshold': 1e7,
        'excluded_counterparties': ['CPTY_EXCLUDE_1', 'CPTY_EXCLUDE_2'],
        'excluded_books': ['BOOK_A', 'BOOK_B'],
        'excluded_counterparty_codes': ['CPTY_A', 'CPTY_B'],
        'accounting_treatment_threshold': 'ACA',
        'enable_debug_columns': True
    }


# Main execution for testing
if __name__ == "__main__":
    print("=== CollateralSwapEngine with Excel File Loading ===")
    
    try:
        # Create default configuration
        config = create_default_config()
        
        # Create engine
        engine = CollateralSwapEngine(**config)
        
        # Create sample Excel file for testing
        excel_file = engine.create_sample_excel("collateral_swap_test_data.xlsx")
        
        # Load data from Excel file
        df = engine.load_from_excel(excel_file, sheet_name='TradeData')
        
        # Process trades
        result_df = engine.process_trades(df)
        
        print(f"\n✓ Processed {len(result_df)} trades")
        print(f"✓ Found {result_df[engine.COLLATERAL_SWAP_INDICATOR].sum()} collateral swaps")
        
        # Display results
        swap_mask = result_df[engine.COLLATERAL_SWAP_INDICATOR] == True
        if swap_mask.any():
            print("\n=== Collateral Swap Results ===")
            display_cols = [
                ColumnName.TRADE_ID.value, ColumnName.TRADE_TYPE.value, ColumnName.COUNTERPARTY_ID.value, 
                engine.COLLATERAL_SWAP_TYPE,
                engine.TRANSACTION_TYPE,
                engine.COLLATERAL_SWAP_CONSTRUCTION
            ]
            available_cols = [col for col in display_cols if col in result_df.columns]
            print(result_df.loc[swap_mask, available_cols].to_string(index=False))
        
        # Show transaction type distribution
        print("\n=== Transaction Type Distribution ===")
        transaction_counts = result_df[engine.TRANSACTION_TYPE].value_counts()
        for transaction_type, count in transaction_counts.items():
            print(f"  {transaction_type}: {count}")
            
    except Exception as e:
        print(f"Error during testing: {e}")
        print("Falling back to in-memory sample data...")
        
        # Fallback to in-memory data
        sample_data = pd.DataFrame({
            ColumnName.TRADE_ID.value: ['TRADE_001', 'TRADE_002', 'TRADE_003'],
            ColumnName.TRADE_TYPE.value: ['REP', 'REV', 'BB'],
            ColumnName.COUNTERPARTY_ID.value: ['CPTY_A', 'CPTY_A', 'CPTY_B'],
            ColumnName.NOTIONAL.value: [1000000, 1000000, 1500000],
            ColumnName.MARKET_PRICE.value: [100.5, 99.8, 101.2],
            ColumnName.MATURITY_DATE.value: ['2024-06-15', '2024-06-15', '2024-07-20'],
            ColumnName.CONTRACT_ID.value: ['CONTRACT_001', 'CONTRACT_001', 'CONTRACT_002'],
            ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value: [True, False, True],
            'is_secured': [True, True, False],
            ColumnName.FX_RATE.value: [1.0, 1.0, 0.85],
            ColumnName.LEG_START_CASH.value: [1000000, 0, 0],
            ColumnName.ACCOUNTING_TREATMENT.value: ['ACA', 'ACA', 'ACA'],
            ColumnName.HQLA_STATUS.value: ['Level 1', 'Level 2A', 'Level 2B'],
            'worst_rating': ['AA', 'BBB', 'BB'],
            ColumnName.BOND_RATING_SP.value: ['AA+', 'BBB+', 'BB+'],
            ColumnName.BOND_RATING_MOODY.value: ['Aa1', 'Baa1', 'Ba1'],
            ColumnName.BOND_RATING_FITCH.value: ['AA', 'BBB', 'BB'],
            ColumnName.BOND_ASSET_TYPE.value: ['GOVT', 'CORP_SENIOR', 'CORP_JUNIOR'],
            ColumnName.PRD.value: ['REPO', 'REPO', 'BOND_BORROW']
        })
        
        config = create_default_config()
        engine = CollateralSwapEngine(**config)
        
        result_df = engine.process_trades(sample_data)
        print(f"Processed {len(result_df)} trades with {result_df[engine.COLLATERAL_SWAP_INDICATOR].sum()} swaps") 