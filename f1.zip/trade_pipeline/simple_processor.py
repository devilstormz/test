"""
Data Processing Pipeline for trading analytics framework.

This module provides a comprehensive data processing pipeline that focuses purely on processing
enrichments and filters without data loading complexity.
"""

import pandas as pd
from typing import List, Optional, Dict, Any, Union
from datetime import datetime
from trading_analytics_framework.trade_pipeline.decorators import ENRICHMENT_REGISTRY, FILTER_REGISTRY
from trading_analytics_framework.trade_pipeline.base import BaseEnrichment, BaseFilter


class EnrichmentError(Exception):
    """Exception raised when enrichment fails."""
    pass


class FilterError(Exception):
    """Exception raised when filter fails."""
    pass


class DataValidationError(Exception):
    """Exception raised when data validation fails."""
    pass


class DataProcessingPipeline:
    """
    Data processing pipeline that focuses purely on enrichments and filters.
    
    This class provides a clean interface for applying enrichments and filters
    to DataFrames using method chaining. Data loading is handled externally.
    Supports both individual operations and batch operations with lists.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        """
        Initialize the pipeline with registered components.
        
        Args:
            load_date: Optional load date for market data dependent operations
        """
        self.load_date = load_date or datetime.now()
        self.enrichments = self._load_registered_enrichments()
        self.filters = self._load_registered_filters()
        self._current_data = None
    
    def set(self, df: pd.DataFrame) -> 'DataProcessingPipeline':
        """
        Set DataFrame for processing.
        
        Args:
            df: DataFrame to process
            
        Returns:
            Self for method chaining
        """
        self._current_data = df.copy()
        return self
    
    def enrich(self, enrichment_name: Union[str, List[str]], **params) -> 'DataProcessingPipeline':
        """
        Apply enrichment(s) to the current data.
        
        Args:
            enrichment_name: Name of enrichment to apply or list of enrichment names
            **params: Optional parameters for the enrichment(s)
            
        Returns:
            Self for method chaining
        """
        if self._current_data is None:
            raise ValueError("No data set. Call set() first.")
        
        if isinstance(enrichment_name, list):
            # Apply multiple enrichments
            for name in enrichment_name:
                self._current_data = self._apply_enrichment(self._current_data, name, **params)
        else:
            # Apply single enrichment
            self._current_data = self._apply_enrichment(self._current_data, enrichment_name, **params)
        
        return self
    
    def filter(self, filter_name: Union[str, List[str]], **params) -> 'DataProcessingPipeline':
        """
        Apply filter(s) to the current data.
        
        Args:
            filter_name: Name of filter to apply or list of filter names
            **params: Optional parameters for the filter(s)
            
        Returns:
            Self for method chaining
        """
        if self._current_data is None:
            raise ValueError("No data set. Call set() first.")
        
        if isinstance(filter_name, list):
            # Apply multiple filters
            for name in filter_name:
                self._current_data = self._apply_filter(self._current_data, name, **params)
        else:
            # Apply single filter
            self._current_data = self._apply_filter(self._current_data, filter_name, **params)
        
        return self
    
    def enrich_all(self, enrichment_names: List[str], **params) -> 'DataProcessingPipeline':
        """
        Apply multiple enrichments to the current data.
        
        Args:
            enrichment_names: List of enrichment names to apply
            **params: Optional parameters for the enrichments
            
        Returns:
            Self for method chaining
        """
        return self.enrich(enrichment_names, **params)
    
    def filter_all(self, filter_names: List[str], **params) -> 'DataProcessingPipeline':
        """
        Apply multiple filters to the current data.
        
        Args:
            filter_names: List of filter names to apply
            **params: Optional parameters for the filters
            
        Returns:
            Self for method chaining
        """
        return self.filter(filter_names, **params)
    
    def process(self, enrichments: Optional[List[str]] = None, filters: Optional[List[str]] = None, **params) -> 'DataProcessingPipeline':
        """
        Process data with optional lists of enrichments and filters.
        
        Args:
            enrichments: Optional list of enrichment names to apply
            filters: Optional list of filter names to apply
            **params: Optional parameters for enrichments and filters
            
        Returns:
            Self for method chaining
        """
        if self._current_data is None:
            raise ValueError("No data set. Call set() first.")
        
        # Apply enrichments first
        if enrichments:
            self.enrich(enrichments, **params)
        
        # Apply filters second
        if filters:
            self.filter(filters, **params)
        
        return self
    
    def get(self) -> pd.DataFrame:
        """
        Get the current processed data.
        
        Returns:
            Current DataFrame
        """
        if self._current_data is None:
            raise ValueError("No data set. Call set() first.")
        return self._current_data.copy()
    
    def _apply_enrichment(self, df: pd.DataFrame, enrichment_name: str, **params) -> pd.DataFrame:
        """Apply a single enrichment."""
        if enrichment_name not in self.enrichments:
            raise EnrichmentError(f"Enrichment '{enrichment_name}' not found in registry")
        
        enrichment = self.enrichments[enrichment_name]
        
        try:
            # Apply enrichment (validation is handled by the base class)
            return enrichment.enrich(df)
            
        except Exception as e:
            raise EnrichmentError(f"Enrichment '{enrichment_name}' failed: {str(e)}") from e
    
    def _apply_filter(self, df: pd.DataFrame, filter_name: str, **params) -> pd.DataFrame:
        """Apply a single filter."""
        if filter_name not in self.filters:
            raise FilterError(f"Filter '{filter_name}' not found in registry")
        
        filter_obj = self.filters[filter_name]
        
        try:
            # Apply filter (validation is handled by the base class)
            return filter_obj.filter(df)
            
        except Exception as e:
            raise FilterError(f"Filter '{filter_name}' failed: {str(e)}") from e
    
    def _load_registered_enrichments(self) -> Dict[str, BaseEnrichment]:
        """Load enrichments from the decorator registry."""
        # Ensure decorators execute by importing module
        from trading_analytics_framework.trade_pipeline import enrichments as _enrich  # noqa: F401
        
        instances: Dict[str, BaseEnrichment] = {}
        for name, meta in ENRICHMENT_REGISTRY.items():
            # Create instance with load_date parameter
            inst = meta['cls'](load_date=self.load_date)
            
            # Set required columns from decorator metadata
            required_input = list(meta.get('required_input', []))
            
            # Update instance attributes
            inst.required_input_columns = required_input
            
            instances[name] = inst
        
        return instances
    
    def _load_registered_filters(self) -> Dict[str, BaseFilter]:
        """Load filters from the decorator registry."""
        # Ensure decorators execute by importing module
        from trading_analytics_framework.trade_pipeline import filters as _filters  # noqa: F401
        
        instances: Dict[str, BaseFilter] = {}
        for name, meta in FILTER_REGISTRY.items():
            # Create instance with load_date parameter
            inst = meta['cls'](load_date=self.load_date)
            
            # Set required columns from decorator metadata
            required_columns = list(meta.get('required_columns', []))
            inst.required_columns = required_columns
            
            instances[name] = inst
        
        return instances
    
    def _get_enrichment_required_input(self, enrichment_name: str) -> List[str]:
        """Get required input columns for an enrichment from registry."""
        if enrichment_name in ENRICHMENT_REGISTRY:
            return list(ENRICHMENT_REGISTRY[enrichment_name].get('required_input', []))
        return []
    
    def _get_filter_required_columns(self, filter_name: str) -> List[str]:
        """Get required input columns for a filter from registry."""
        if filter_name in FILTER_REGISTRY:
            return list(FILTER_REGISTRY[filter_name].get('required_columns', []))
        return []
