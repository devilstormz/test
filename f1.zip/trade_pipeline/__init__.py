"""
Trading Dataset Pipeline Framework

A simplified ETL pipeline framework for trading data with standardized datasets,
smart enrichments, and flexible filtering capabilities.

Key Components:
- SimpleProcessor: Main processor for data loading and chained operations
- SimpleDataLoader: Direct interface to database functions
- BaseEnrichment: Abstract base for enrichments with smart validation
- BaseFilter: Abstract base for filters with validation
- Decorators: Registration and validation for enrichments and filters

Usage:
    from trading_analytics_framework.trade_pipeline import SimpleProcessor
    
    # Create processor
    processor = SimpleProcessor()
    
    # Load and process data
    data = processor.load_risk_data(
        columns=['trade_id', 'amount'],
        enrichments=['counterparty_mapping'],
        filters=['remove_wash_books']
    )
    
    # Apply chained operations
    operations = [
        {'type': 'filter', 'name': 'remove_wash_books'},
        {'type': 'enrichment', 'name': 'counterparty_mapping'},
        {'type': 'filter', 'name': 'remove_maturing_trades'}
    ]
    processed_data = processor.chain_operations(data, operations)
"""

# Import the simplified components
from trading_analytics_framework.trade_pipeline.config import (
    DatabaseType, ColumnName, 
    EnrichmentType, FilterType, ProductType, BookingSystem
)
from trading_analytics_framework.trade_pipeline.simple_processor import DataProcessingPipeline
from trading_analytics_framework.trade_pipeline.data_loader import DataLoader
from trading_analytics_framework.trade_pipeline.base import BaseEnrichment, BaseFilter
from trading_analytics_framework.trade_pipeline.decorators import (
    register_enrichment, register_filter, error_handler
)

# Export the main components
__all__ = [
    # Configuration
    'DatabaseType', 'ColumnName',
    'EnrichmentType', 'FilterType', 'ProductType', 'BookingSystem',
    
    # Core components
    'DataProcessingPipeline', 'DataLoader',
    
    # Base classes
    'BaseEnrichment', 'BaseFilter',
    
    # Decorators
    'register_enrichment', 'register_filter', 'error_handler'
] 