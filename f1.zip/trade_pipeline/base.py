"""
Base classes for trading dataset pipeline.

This module provides the base classes for enrichments and filters.
"""

import pandas as pd
from abc import ABC, abstractmethod
from typing import List, Optional
from datetime import datetime


class EnrichmentError(Exception):
    """Exception raised when enrichment fails."""
    pass


class FilterError(Exception):
    """Exception raised when filter fails."""
    pass


class DataValidationError(Exception):
    """Exception raised when data validation fails."""
    pass


class BaseEnrichment(ABC):
    """
    Base class for all enrichments in the trading dataset pipeline.
    
    This class provides a common interface for enrichment operations
    that add new data or derive new features from existing data.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        """
        Initialize the enrichment.
        
        Args:
            load_date: Optional load date for market data dependent enrichments
        """
        self.required_input_columns: List[str] = []
        self.required_output_columns: List[str] = []
        self.load_date = load_date or datetime.now()
    
    def enrich(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply enrichment to the DataFrame.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame
        """
        try:
            # Validate required input columns
            if self.required_input_columns:
                missing_input = [col for col in self.required_input_columns if col not in df.columns]
                if missing_input:
                    raise DataValidationError(f"Enrichment {self.__class__.__name__} requires input columns: {missing_input}")
            
            # Check if required output columns already exist
            if self._all_required_columns_exist(df):
                print(f"Required columns already exist, skipping enrichment: {self.__class__.__name__}")
                return df
            
            # Perform enrichment
            enriched_df = self._perform_enrichment(df)
            
            # Validate output
            self._validate_enrichment_output(enriched_df)
            
            return enriched_df
            
        except Exception as e:
            raise EnrichmentError(f"Enrichment {self.__class__.__name__} failed: {str(e)}") from e
    
    def _all_required_columns_exist(self, df: pd.DataFrame) -> bool:
        """
        Check if all required output columns already exist in the dataframe.
        
        Args:
            df: DataFrame to check
            
        Returns:
            True if all required columns exist, False otherwise
        """
        return all(col in df.columns for col in self.required_output_columns)
    
    def _validate_enrichment_output(self, df: pd.DataFrame) -> None:
        """
        Validate that enrichment produced expected output columns.
        
        Args:
            df: Enriched DataFrame to validate
            
        Raises:
            DataValidationError: If required columns are missing
        """
        if self.required_output_columns:
            missing_columns = [col for col in self.required_output_columns if col not in df.columns]
            if missing_columns:
                raise DataValidationError(f"Enrichment {self.__class__.__name__} failed to produce required columns: {missing_columns}")
    
    @abstractmethod
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform the actual enrichment operation.
        
        This method should be implemented by subclasses to provide
        the specific enrichment logic.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame
        """
        pass


class BaseFilter(ABC):
    """
    Base class for all filters in the trading dataset pipeline.
    
    This class provides a common interface for filter operations
    that subset or remove data based on certain criteria.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        """
        Initialize the filter.
        
        Args:
            load_date: Optional load date for market data dependent filters
        """
        self.required_columns: List[str] = []
        self.load_date = load_date or datetime.now()
    
    def filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply filter to the DataFrame.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Filtered DataFrame
        """
        try:
            # Check if required columns exist
            if self.required_columns:
                missing_columns = [col for col in self.required_columns if col not in df.columns]
                if missing_columns:
                    raise DataValidationError(f"Filter {self.__class__.__name__} requires columns: {missing_columns}")
            
            # Apply filter
            filtered_df = self._apply_filter(df)
            
            # Validate output
            self._validate_filter_output(filtered_df)
            
            return filtered_df
            
        except Exception as e:
            raise FilterError(f"Filter {self.__class__.__name__} failed: {str(e)}") from e
    
    def _validate_filter_output(self, df: pd.DataFrame) -> None:
        """
        Validate that filter produced valid output.
        
        Args:
            df: Filtered DataFrame to validate
            
        Raises:
            DataValidationError: If filter removed all data
        """
        if len(df) == 0:
            raise DataValidationError(f"Filter {self.__class__.__name__} removed all data")
    
    @abstractmethod
    def _apply_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply the actual filter operation.
        
        This method should be implemented by subclasses to provide
        the specific filter logic.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Filtered DataFrame
        """
        pass
    
    def validate_columns(self, df: pd.DataFrame) -> None:
        """
        Public helper to validate required columns exist before filtering.
        """
        if self.required_columns:
            missing_columns = [col for col in self.required_columns if col not in df.columns]
            if missing_columns:
                raise DataValidationError(
                    f"Filter {self.__class__.__name__} requires columns: {missing_columns}"
                )