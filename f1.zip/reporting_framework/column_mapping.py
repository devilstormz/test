"""
Column Mapping Configuration for Reporting Framework.

This module provides a flexible column mapping system that allows:
1. System column names to be mapped to report-friendly names
2. Dynamic column ordering for output
3. Report-specific overrides of default mappings
"""

from typing import Dict, List, Optional, Union
import pandas as pd


class ColumnMappingConfig:
    """
    Configuration for column mapping and ordering in reports.
    
    This class provides a flexible way to map system column names to
    report-friendly names and define the order of columns in output.
    """
    
    def __init__(self, 
                 column_mappings: Dict[str, str] = None,
                 column_order: List[str] = None,
                 column_overrides: Dict[str, str] = None):
        """
        Initialize the column mapping configuration.
        
        Args:
            column_mappings: Dictionary mapping system names to friendly names
            column_order: List of friendly names in desired order
            column_overrides: Dictionary mapping friendly names to override names
        """
        self.column_mappings = column_mappings or {}
        self.column_order = column_order or []
        self.column_overrides = column_overrides or {}
        
        # Validate configuration after initialization
        self._validate_config()
    
    def _validate_config(self):
        """Validate the column mapping configuration."""
        # Check for circular references in overrides
        for friendly_name, override_name in self.column_overrides.items():
            if override_name in self.column_overrides:
                raise ValueError(f"Circular reference detected in column overrides: {friendly_name} -> {override_name}")
        
        # Check that column order contains valid friendly names
        if self.column_order:
            all_friendly_names = set(self.column_mappings.values()) | set(self.column_overrides.values())
            invalid_columns = [col for col in self.column_order if col not in all_friendly_names]
            if invalid_columns:
                raise ValueError(f"Column order contains invalid friendly names: {invalid_columns}")
    
    def get_final_mapping(self) -> Dict[str, str]:
        """
        Get the final column mapping including overrides.
        
        Returns:
            Dictionary mapping system names to final friendly names
        """
        final_mapping = self.column_mappings.copy()
        
        # Apply overrides
        for system_name, friendly_name in self.column_mappings.items():
            if friendly_name in self.column_overrides:
                final_mapping[system_name] = self.column_overrides[friendly_name]
        
        return final_mapping
    
    def get_final_column_order(self) -> List[str]:
        """
        Get the final column order with overrides applied.
        
        Returns:
            List of final friendly names in desired order
        """
        if not self.column_order:
            return list(self.get_final_mapping().values())
        
        # Apply overrides to column order
        final_order = []
        for friendly_name in self.column_order:
            if friendly_name in self.column_overrides:
                final_order.append(self.column_overrides[friendly_name])
            else:
                final_order.append(friendly_name)
        
        return final_order
    
    def add_mapping(self, system_name: str, friendly_name: str) -> None:
        """Add a column mapping."""
        self.column_mappings[system_name] = friendly_name
        self._validate_config()
    
    def add_override(self, friendly_name: str, override_name: str) -> None:
        """Add a column name override."""
        self.column_overrides[friendly_name] = override_name
        self._validate_config()
    
    def set_column_order(self, column_order: List[str]) -> None:
        """Set the column order."""
        self.column_order = column_order
        self._validate_config()
    
    def apply_to_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply column mapping and ordering to a DataFrame.
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with mapped column names and ordering
        """
        final_mapping = self.get_final_mapping()
        final_order = self.get_final_column_order()
        
        # Rename columns
        renamed_df = df.rename(columns=final_mapping)
        
        # Reorder columns
        available_columns = [col for col in final_order if col in renamed_df.columns]
        remaining_columns = [col for col in renamed_df.columns if col not in available_columns]
        
        # Combine ordered columns with remaining columns
        final_columns = available_columns + remaining_columns
        
        return renamed_df[final_columns]


class ColumnMappingRegistry:
    """
    Registry for managing column mapping configurations.
    
    This class provides a centralized way to manage different column mapping
    configurations for different types of reports or data sources.
    """
    
    def __init__(self):
        """Initialize the registry."""
        self._configs: Dict[str, ColumnMappingConfig] = {}
        self._default_config = ColumnMappingConfig()
    
    def register_config(self, name: str, config: ColumnMappingConfig) -> None:
        """
        Register a column mapping configuration.
        
        Args:
            name: Configuration name
            config: Column mapping configuration
        """
        self._configs[name] = config
    
    def get_config(self, name: str) -> ColumnMappingConfig:
        """
        Get a registered configuration.
        
        Args:
            name: Configuration name
            
        Returns:
            Column mapping configuration
        """
        if name not in self._configs:
            raise KeyError(f"Column mapping configuration '{name}' not found")
        return self._configs[name]
    
    def get_default_config(self) -> ColumnMappingConfig:
        """Get the default configuration."""
        return self._default_config
    
    def set_default_config(self, config: ColumnMappingConfig) -> None:
        """Set the default configuration."""
        self._default_config = config
    
    def list_configs(self) -> List[str]:
        """List all registered configuration names."""
        return list(self._configs.keys())


# Global registry instance
column_mapping_registry = ColumnMappingRegistry()


# Predefined configurations
def create_trade_data_mapping() -> ColumnMappingConfig:
    """Create default column mapping for trade data."""
    return ColumnMappingConfig(
        column_mappings={
            'trade_id': 'Trade ID',
            'notional': 'Notional Amount',
            'market_value': 'Market Value',
            'currency': 'Currency',
            'counterparty': 'Counterparty',
            'product': 'Product Type',
            'book': 'Trading Book',
            'trade_date': 'Trade Date',
            'settlement_date': 'Settlement Date',
            'mv_product_type': 'Product Category',
            'mv_risk_type': 'Risk Type'
        },
        column_order=[
            'Trade ID', 'Trade Date', 'Counterparty', 'Product Type',
            'Notional Amount', 'Market Value', 'Currency', 'Trading Book'
        ]
    )


def create_risk_data_mapping() -> ColumnMappingConfig:
    """Create default column mapping for risk data."""
    return ColumnMappingConfig(
        column_mappings={
            'trade_id': 'Trade ID',
            'var': 'Value at Risk',
            'expected_shortfall': 'Expected Shortfall',
            'risk_metric': 'Risk Metric',
            'confidence_level': 'Confidence Level',
            'holding_period': 'Holding Period',
            'risk_factor': 'Risk Factor',
            'risk_bucket': 'Risk Bucket'
        },
        column_order=[
            'Trade ID', 'Value at Risk', 'Expected Shortfall',
            'Risk Metric', 'Confidence Level', 'Risk Factor'
        ]
    )


def create_bond_data_mapping() -> ColumnMappingConfig:
    """Create default column mapping for bond data."""
    return ColumnMappingConfig(
        column_mappings={
            'bond_id': 'Bond ID',
            'issuer': 'Issuer',
            'rating': 'Credit Rating',
            'maturity_date': 'Maturity Date',
            'coupon_rate': 'Coupon Rate',
            'face_value': 'Face Value',
            'tenor_bucket': 'Tenor Bucket',
            'issuer_rating': 'Issuer Rating',
            'sector': 'Sector',
            'country': 'Country'
        },
        column_order=[
            'Bond ID', 'Issuer', 'Credit Rating', 'Maturity Date',
            'Coupon Rate', 'Face Value', 'Tenor Bucket', 'Sector'
        ]
    )


# Register default configurations
column_mapping_registry.register_config('trade_data', create_trade_data_mapping())
column_mapping_registry.register_config('risk_data', create_risk_data_mapping())
column_mapping_registry.register_config('bond_data', create_bond_data_mapping())
