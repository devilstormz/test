"""
Base Report Class

This module provides the base class for all reports in the reporting framework.
It includes abstract methods for different export formats and Excel formatting utilities.
"""

import pandas as pd
import numpy as np
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Union
import json
import pickle
from datetime import datetime
import xlsxwriter



class BaseReport(ABC):
    """
    Abstract base class for all reports in the reporting framework.
    
    This class provides a common interface for creating reports with different export formats.
    Every report should contain a "Raw Data" tab and another "Pivot" tab.
    
    Attributes:
        data (pd.DataFrame): The raw data for the report
        pivot_data (pd.DataFrame): The pivot/summary data for the report
        report_name (str): Name of the report
        report_date (datetime): Date for the report
    """
    
    def __init__(self, data: pd.DataFrame, report_name: str = "Report", report_date: datetime = None):
        """
        Initialize the base report.
        
        Args:
            data: The raw data DataFrame
            report_name: Name of the report
            report_date: Date for the report (defaults to current date if None)
        """
        self.data = data.copy()
        self.report_name = report_name
        self.report_date = report_date or datetime.now()
    
    def __str__(self) -> str:
        """String representation of the report."""
        return f"{self.report_name} (Date: {self.report_date.strftime('%Y-%m-%d')})"
    
    def __repr__(self) -> str:
        """Detailed string representation of the report."""
        return (f"{self.__class__.__name__}(data_shape={self.data.shape}, "
                f"name='{self.report_name}', date='{self.report_date.strftime('%Y-%m-%d')}')")
    
    @abstractmethod
    def to_excel(self, filepath: str) -> None:
        """
        Export the report to Excel format with professional formatting.
        
        Args:
            filepath: Path where the Excel file should be saved
        """
        pass
    
    def to_html(self, filepath: str) -> None:
        """
        Export the report to HTML format.
        
        Args:
            filepath: Path where the HTML file should be saved
        """
        # Create a simple HTML report with the data
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>{self.report_name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                h1 {{ color: #000080; }}
                table {{ border-collapse: collapse; width: 100%; margin-top: 20px; }}
                th {{ background-color: #000080; color: white; padding: 12px; text-align: left; }}
                td {{ padding: 8px; border-bottom: 1px solid #ddd; }}
                tr:nth-child(even) {{ background-color: #f2f2f2; }}
                .report-info {{ background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
            </style>
        </head>
        <body>
            <h1>{self.report_name}</h1>
            <div class="report-info">
                <strong>Report Date:</strong> {self.report_date.strftime('%Y-%m-%d')}<br>
                <strong>Data Shape:</strong> {self.data.shape[0]} rows × {self.data.shape[1]} columns<br>
                <strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            </div>
            <h2>Raw Data</h2>
            {self.data.to_html(index=False, classes='dataframe')}
        </body>
        </html>
        """
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
    
    def to_json(self, filepath: str) -> None:
        """
        Export the report to JSON format.
        
        Args:
            filepath: Path where the JSON file should be saved
        """
        # Create a JSON structure with report metadata and data
        report_data = {
            'report_name': self.report_name,
            'report_date': self.report_date.strftime('%Y-%m-%d'),
            'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'data_shape': {
                'rows': self.data.shape[0],
                'columns': self.data.shape[1]
            },
            'columns': list(self.data.columns),
            'data': self.data.to_dict('records')
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, indent=2, default=str)
    
    def to_serialised_blob(self, filepath: str) -> None:
        """
        Export the report as a serialized blob (pickle format).
        
        Args:
            filepath: Path where the serialized blob should be saved
        """
        # Create a serializable report object
        report_blob = {
            'report_name': self.report_name,
            'report_date': self.report_date,
            'data': self.data,
            'generated_at': datetime.now()
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(report_blob, f)
    
    def load_data(self, data_source: Union[str, pd.DataFrame], **kwargs) -> pd.DataFrame:
        """
        Load data from various sources (file path, DataFrame, etc.).
        
        Args:
            data_source: Path to data file or DataFrame object
            **kwargs: Additional arguments for data loading (e.g., sheet_name, encoding)
            
        Returns:
            Loaded DataFrame
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If data_source is invalid
        """
        if isinstance(data_source, pd.DataFrame):
            return data_source.copy()
        
        elif isinstance(data_source, str):
            # Determine file type and load accordingly
            file_extension = data_source.lower().split('.')[-1]
            
            if file_extension in ['xlsx', 'xls']:
                sheet_name = kwargs.get('sheet_name', 0)
                return pd.read_excel(data_source, sheet_name=sheet_name)
            
            elif file_extension == 'csv':
                encoding = kwargs.get('encoding', 'utf-8')
                return pd.read_csv(data_source, encoding=encoding)
            
            elif file_extension == 'json':
                return pd.read_json(data_source)
            
            elif file_extension == 'parquet':
                return pd.read_parquet(data_source)
            
            else:
                raise ValueError(f"Unsupported file format: {file_extension}")
        
        else:
            raise ValueError("data_source must be a file path (str) or DataFrame")
    
    def run_report(self, data_source: Union[str, pd.DataFrame], **kwargs) -> pd.DataFrame:
        """
        Run the complete report pipeline: load data, run enrichments/filters, and post-process.
        
        This method provides a standardized way to run the complete report workflow.
        Concrete report classes should override this method to implement specific
        pipeline processing logic.
        
        Args:
            data_source: Path to data file or DataFrame object
            **kwargs: Additional arguments for data loading and processing
            
        Returns:
            Processed DataFrame that will be stored in self.data
            
        Raises:
            Exception: If data loading or processing fails
        """
        try:
            # Load data using the base load_data method
            raw_data = self.load_data(data_source, **kwargs)
            
            # Update the report data (concrete classes will override this)
            self.data = raw_data
            
            return raw_data
            
        except Exception as e:
            raise Exception(f"Failed to run report: {str(e)}") from e
    
    def _apply_excel_formatting(self, workbook: xlsxwriter.Workbook) -> Dict[str, Any]:
        """
        Create Excel formatting styles according to the specified requirements.
        
        Args:
            workbook: The xlsxwriter workbook object
            
        Returns:
            Dictionary containing the formatting styles
        """
        # Deep navy background (#000080) + white text for headers
        header_format = workbook.add_format({
            'bg_color': '#000080',
            'font_color': 'white',
            'bold': True,
            'align': 'center',
            'valign': 'vcenter'
        })
        
        # White fill for all cells
        cell_format = workbook.add_format({
            'bg_color': 'white',
            'align': 'left',
            'valign': 'vcenter'
        })
        
        # Negative numbers in red with brackets format
        negative_format = workbook.add_format({
            'bg_color': 'white',
            'font_color': 'red',
            'num_format': '_(#,##0.00_);_(#,##0.00_);_(0_);_(@_)',
            'align': 'right',
            'valign': 'vcenter'
        })
        
        # Number format for positive numbers
        number_format = workbook.add_format({
            'bg_color': 'white',
            'num_format': '#,##0.00',
            'align': 'right',
            'valign': 'vcenter'
        })
        
        return {
            'header': header_format,
            'cell': cell_format,
            'negative': negative_format,
            'number': number_format
        }
    
    def _write_dataframe_to_excel(self, worksheet, 
                                 df: pd.DataFrame, start_row: int = 0, 
                                 start_col: int = 0, formats: Dict[str, Any] = None) -> None:
        """
        Write a DataFrame to an Excel worksheet with proper formatting.
        
        Args:
            worksheet: The xlsxwriter worksheet object
            df: DataFrame to write
            start_row: Starting row position
            start_col: Starting column position
            formats: Dictionary of formatting styles
        """
        if formats is None:
            formats = {}
        
        # Write headers
        for col_idx, col_name in enumerate(df.columns):
            worksheet.write(start_row, start_col + col_idx, col_name, formats.get('header', {}))
        
        # Write data
        for row_idx, (_, row) in enumerate(df.iterrows()):
            for col_idx, value in enumerate(row):
                cell_row = start_row + 1 + row_idx
                cell_col = start_col + col_idx
                
                # Determine format based on value type
                if pd.isna(value):
                    worksheet.write(cell_row, cell_col, '', formats.get('cell', {}))
                elif isinstance(value, (int, float)):
                    if value < 0:
                        worksheet.write(cell_row, cell_col, value, formats.get('negative', {}))
                    else:
                        worksheet.write(cell_row, cell_col, value, formats.get('number', {}))
                else:
                    worksheet.write(cell_row, cell_col, value, formats.get('cell', {}))
        
        # Auto-adjust column widths
        for col_idx, col_name in enumerate(df.columns):
            # Calculate max width based on header and data
            max_width = len(str(col_name))
            for _, row in df.iterrows():
                max_width = max(max_width, len(str(row.iloc[col_idx])))
            
            # Set column width (with some padding)
            worksheet.set_column(start_col + col_idx, start_col + col_idx, max_width + 2) 