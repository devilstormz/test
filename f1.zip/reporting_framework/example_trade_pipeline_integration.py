"""
Example: Trade Pipeline Integration with Reporting Framework

This example demonstrates how to use the trade pipeline components
with the reporting framework to create various types of reports.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import xlsxwriter

# Import trade pipeline components
from trading_analytics_framework.trade_pipeline.bond_rating_engine import BondScoringEngine
from trading_analytics_framework.trade_pipeline.collateral_swap_engine import (
    CollateralSwapEngine, create_default_config
)
from trading_analytics_framework.trade_pipeline.market_value_calculator import MarketValueCalculator

# Import reporting framework components
from trading_analytics_framework.reporting_framework.base_report import BaseReport
from trading_analytics_framework.reporting_framework.column_mapping import (
    ColumnMappingConfig, column_mapping_registry
)


class BondRatingReport(BaseReport):
    """Example report for bond rating analysis."""
    
    def __init__(self, data: pd.DataFrame = None, report_name: str = "Bond Rating Report", report_date: datetime = None):
        """Initialize bond rating report with optional data."""
        if data is None:
            data = pd.DataFrame()  # Empty DataFrame if no data provided
        super().__init__(data, report_name, report_date)
    
    def run_report(self, data_source: Union[str, pd.DataFrame], **kwargs) -> pd.DataFrame:
        """Run the bond rating report pipeline."""
        # Load data using the base load_data method
        raw_data = self.load_data(data_source, **kwargs)
        
        # Initialize pipeline and run enrichments
        from trading_analytics_framework.trade_pipeline.bond_rating_engine import BondScoringEngine
        engine = BondScoringEngine(raw_data)
        
        # Run the enrichment
        processed_data = engine.compute_scores(use_average=False)
        
        # Post-processing for the report
        # Add any report-specific calculations or filtering here
        self.data = processed_data
        
        return processed_data
    
    def to_excel(self, filepath: str) -> None:
        """Export bond rating report to Excel with professional formatting."""
        with xlsxwriter.Workbook(filepath) as workbook:
            # Get formatting styles
            formats = self._apply_excel_formatting(workbook)
            
            # Create Raw Data worksheet
            raw_worksheet = workbook.add_worksheet('Raw Data')
            self._write_dataframe_to_excel(raw_worksheet, self.data, formats=formats)
            
            # Create Summary worksheet
            summary_worksheet = workbook.add_worksheet('Summary')
            
            # Add summary statistics
            summary_data = {
                'Metric': ['Total Bonds', 'Investment Grade', 'High Yield', 'Average Rating Score', 'Average Final Score'],
                'Value': [
                    len(self.data),
                    len(self.data[self.data['asset_class'].isin(['GOVT', 'CORP']) if 'asset_class' in self.data.columns else False]),
                    len(self.data[self.data['asset_class'] == 'CLO/ABS'] if 'asset_class' in self.data.columns else 0),
                    self.data['rating_score'].mean() if 'rating_score' in self.data.columns else 0,
                    self.data['final_score'].mean() if 'final_score' in self.data.columns else 0
                ]
            }
            summary_df = pd.DataFrame(summary_data)
            self._write_dataframe_to_excel(summary_worksheet, summary_df, formats=formats)


class CollateralSwapReport(BaseReport):
    """Example report for collateral swap analysis."""
    
    def __init__(self, data: pd.DataFrame = None, report_name: str = "Collateral Swap Report", report_date: datetime = None):
        """Initialize collateral swap report with optional data."""
        if data is None:
            data = pd.DataFrame()  # Empty DataFrame if no data provided
        super().__init__(data, report_name, report_date)
    
    def run_report(self, data_source: Union[str, pd.DataFrame], **kwargs) -> pd.DataFrame:
        """Run the collateral swap report pipeline."""
        # Load data using the base load_data method
        raw_data = self.load_data(data_source, **kwargs)
        
        # Initialize pipeline and run enrichments
        from trading_analytics_framework.trade_pipeline.collateral_swap_engine import CollateralSwapEngine, create_default_config
        config = create_default_config()
        engine = CollateralSwapEngine(*config)
        
        # Run the enrichment
        processed_data = engine.process_trades(raw_data)
        
        # Post-processing for the report
        # Add any report-specific calculations or filtering here
        self.data = processed_data
        
        return processed_data
    
    def to_excel(self, filepath: str) -> None:
        """Export collateral swap report to Excel with professional formatting."""
        with xlsxwriter.Workbook(filepath) as workbook:
            # Get formatting styles
            formats = self._apply_excel_formatting(workbook)
            
            # Create Raw Data worksheet
            raw_worksheet = workbook.add_worksheet('Raw Data')
            self._write_dataframe_to_excel(raw_worksheet, self.data, formats=formats)
            
            # Create Swap Analysis worksheet
            swap_worksheet = workbook.add_worksheet('Swap Analysis')
            
            # Filter for identified swaps
            swap_data = self.data[self.data.get('collateral_swap_indicator', False)]
            if not swap_data.empty:
                # Select relevant columns for swap analysis
                swap_cols = ['trade_id', 'trade_type', 'counterparty_code', 
                           'collateral_swap_type', 'transaction_type', 'collateral_swap_construction']
                available_cols = [col for col in swap_cols if col in swap_data.columns]
                swap_analysis = swap_data[available_cols]
                self._write_dataframe_to_excel(swap_worksheet, swap_analysis, formats=formats)
            else:
                swap_worksheet.write(0, 0, "No collateral swaps identified in the data")


class MarketValueReport(BaseReport):
    """Example report for market value analysis."""
    
    def __init__(self, data: pd.DataFrame = None, report_name: str = "Market Value Report", report_date: datetime = None):
        """Initialize market value report with optional data."""
        if data is None:
            data = pd.DataFrame()  # Empty DataFrame if no data provided
        super().__init__(data, report_name, report_date)
    
    def run_report(self, data_source: Union[str, pd.DataFrame], **kwargs) -> pd.DataFrame:
        """Run the market value report pipeline."""
        # Load data using the base load_data method
        raw_data = self.load_data(data_source, **kwargs)
        
        # Initialize pipeline and run enrichments
        from trading_analytics_framework.trade_pipeline.market_value_calculator import MarketValueCalculator
        calculator = MarketValueCalculator()
        
        # Run the enrichment
        processed_data = calculator.calculate_market_values(raw_data)
        
        # Post-processing for the report
        # Add any report-specific calculations or filtering here
        self.data = processed_data
        
        return processed_data
    
    def to_excel(self, filepath: str) -> None:
        """Export market value report to Excel with professional formatting."""
        with xlsxwriter.Workbook(filepath) as workbook:
            # Get formatting styles
            formats = self._apply_excel_formatting(workbook)
            
            # Create Raw Data worksheet
            raw_worksheet = workbook.add_worksheet('Raw Data')
            self._write_dataframe_to_excel(raw_worksheet, self.data, formats=formats)
            
            # Create Summary worksheet
            summary_worksheet = workbook.add_worksheet('Summary')
            
            # Calculate summary statistics
            summary_data = {
                'Metric': ['Total Trades', 'Total EUR Cash Amount', 'Total EUR Security MV', 
                          'Total EUR Directional Cash', 'Total EUR Directional Security'],
                'Value': [
                    len(self.data),
                    self.data.get('EUR Cash Amt', pd.Series([0])).sum(),
                    self.data.get('EUR Security MV', pd.Series([0])).sum(),
                    self.data.get('EUR Directional Cash Amt', pd.Series([0])).sum(),
                    self.data.get('EUR Directional Security MV', pd.Series([0])).sum()
                ]
            }
            summary_df = pd.DataFrame(summary_data)
            self._write_dataframe_to_excel(summary_worksheet, summary_df, formats=formats)


def create_sample_bond_data() -> pd.DataFrame:
    """Create sample bond data for testing."""
    return pd.DataFrame({
        'Bond.RtyDB': ['A+', None, None, 'BB-', None, 'AAA', 'BBB+', 'B+', 'AA-', 'CCC'],
        'Bond.RtySP': ['A-', 'BBB+', 'B+', None, 'AA', 'AA+', 'BBB', 'B', 'AA', 'CCC+'],
        'Bond.RtyMDY': ['A', 'BBB', None, 'BB+', 'AAA', 'Aaa', 'Baa1', 'B1', 'Aa3', 'Caa1'],
        'Bond.RtyFITCH': [None, 'BBB', 'B', 'BB', 'AA+', 'AAA', 'BBB+', 'B+', 'AA-', 'CCC'],
        'Bond.Issuer.RtyDB': ['AA', 'A+', 'BBB', 'BB', 'AAA', 'AA+', 'A', 'BBB+', 'AA', 'BB+'],
        'Bond.Issuer.RtySP': ['AA-', 'A', 'BBB-', 'BB+', 'AA', 'AA', 'A-', 'BBB', 'AA-', 'BB'],
        'Bond.Issuer.RtyMDY': ['AA+', 'A-', 'BBB+', 'BB-', 'AAA', 'Aa1', 'A2', 'Baa1', 'Aa2', 'Ba1'],
        'Bond.Issuer.RtyFITCH': ['AA', 'A', 'BBB', 'BB', 'AA+', 'AA+', 'A-', 'BBB+', 'AA', 'BB+'],
        'RtgAvg': ['A', 'BBB+', 'B+', 'BB', 'AA', 'AAA', 'BBB+', 'B+', 'AA-', 'CCC'],
        'subordinated': [False, False, True, False, False, False, False, True, False, True],
        'Bond.CollatType': ['GOVT', 'CORP', 'CLO/ABS', 'TRIPARTY', 'BASKET', 'GOVT', 'CORP', 'CLO/ABS', 'GOVT', 'CORP'],
        'Bond.ID': [f'BOND_{i:03d}' for i in range(1, 11)],
        'Bond.Issuer': [
            'US Treasury', 'ABC Corp', 'XYZ Bank', 'DEF Corp', 'GHI Financial',
            'German Bund', 'French OAT', 'JKL Corp', 'MNO Bank', 'PQR Corp'
        ]
    })


def create_sample_trade_data() -> pd.DataFrame:
    """Create sample trade data for testing."""
    return pd.DataFrame({
        'trade_id': [f'TRADE_{i:03d}' for i in range(1, 21)],
        'booking_system': ['B-E', 'MAG', 'B-E', 'MAG', 'B-E'] * 4,
        'trade_type': ['REP', 'REV', 'BB', 'BL', 'TP', 'TR', 'TPR', 'TRV', 'TPB', 'TPL'] * 2,
        'counterparty': [f'CPTY_{i:03d}' for i in range(1, 21)],
        'counterparty_code': ['CPTY_A', 'CPTY_B', 'CPTY_C', 'CPTY_D', 'CPTY_E'] * 4,
        'notional': [1000000, 2000000, 1500000, 2500000, 3000000] * 4,
        'currency': ['EUR', 'USD', 'GBP', 'EUR', 'USD'] * 4,
        'market_price': [100.5, 99.8, 101.2, 100.0, 100.5] * 4,
        'maturity_date': ['2024-06-15', '2024-07-20', '2024-08-10', '2024-09-05', '2024-10-01'] * 4,
        'contract_id': [f'CONTRACT_{i:03d}' for i in range(1, 21)],
        'booking_collateral_swap_flag': [True, False, True, False, True] * 4,
        'is_secured': [True, True, False, True, True] * 4,
        'fx_rate': [1.0, 0.85, 1.15, 1.0, 0.85] * 4,
        'start_cash': [1000000, 0, 0, 2000000, 0] * 4,
        'book_accounting_treatment': ['ACA', 'ACA', 'ACA', 'ACA', 'ACA'] * 4,
        'hqla_status': ['Level 1', 'Level 2A', 'Level 2B', 'Non-HQLA', 'Level 1'] * 4,
        'worst_rating': ['AA', 'BBB', 'BB', 'B', 'AA'] * 4,
        'sp_rating': ['AA+', 'BBB+', 'BB+', 'B+', 'AA'] * 4,
        'moody_rating': ['Aa1', 'Baa1', 'Ba1', 'B1', 'Aa2'] * 4,
        'fitch_rating': ['AA', 'BBB', 'BB', 'B', 'AA-'] * 4,
        'bond_asset_type': ['GOVT', 'CORP_SENIOR', 'CORP_JUNIOR', 'ABS_CLO', 'GOVT'] * 4,
        'prds_code': ['REPO', 'REPO', 'BOND_BORROW', 'BOND_LEND', 'REPO'] * 4
    })


def create_sample_market_value_data() -> pd.DataFrame:
    """Create sample market value data for testing."""
    return pd.DataFrame({
        "PRD": ["CASH_DEPOSIT", "REPO", "GOVERNMENT_BOND", "INTEREST_RATE_SWAP", "CROSS_CURRENCY_SWAP",
               "CASH_LOAN", "REVERSE_REPO", "CORPORATE_BOND", "BASIS_SWAP", "FX_SWAP"],
        "CCY": ["USD", "EUR", "GBP", "JPY", "USD", "EUR", "GBP", "USD", "EUR", "GBP"],
        "Leg.PayRec": ["Receive", "Pay", "Receive", "Pay", "Receive", "Pay", "Receive", "Pay", "Receive", "Pay"],
        "Leg.Type": ["RECEIVE", "PAY", "BUY", "SELL", "RECEIVE", "PAY", "RECEIVE", "BUY", "RECEIVE", "PAY"],
        "Leg.StartCash": [1000000, 500000, 750000, 0, 2000000, 1500000, 800000, 0, 1200000, 0],
        "LegArg.Notional": [1000000, 500000, 750000, 1500000, 2000000, 1500000, 800000, 1000000, 1200000, 900000],
        "FX": [0.85, 1.0, 1.15, 0.007, 0.85, 1.0, 1.15, 0.85, 1.0, 1.15],
        "PoolFactor": [1.0, 0.98, 1.02, 1.0, 1.0, 1.0, 0.99, 1.01, 1.0, 1.0],
        "Mkt Price of security": [100.5, 99.8, 101.2, 100.0, 100.0, 100.3, 99.9, 100.8, 100.1, 99.7],
        "system": ["B-E", "MAG", "B-E", "MAG", "B-E", "MAG", "B-E", "MAG", "B-E", "MAG"],
        "Bond.Currency": ["", "EUR", "GBP", "", "", "EUR", "GBP", "USD", "EUR", "GBP"]
    })


def demonstrate_bond_rating_integration():
    """Demonstrate bond rating engine integration with reporting framework."""
    print("=== Bond Rating Engine Integration ===")
    
    # Create sample data
    bond_data = create_sample_bond_data()
    
    # Create report and run pipeline
    report_date = datetime(2024, 1, 15)
    bond_report = BondRatingReport(
        report_name="Bond Rating Analysis Report",
        report_date=report_date
    )
    
    # Run the complete pipeline (load data, run enrichments, post-process)
    result_data = bond_report.run_report(bond_data)
    
    # Export to different formats
    output_dir = "reports"
    os.makedirs(output_dir, exist_ok=True)
    
    bond_report.to_excel(f"{output_dir}/bond_rating_report.xlsx")
    bond_report.to_html(f"{output_dir}/bond_rating_report.html")
    bond_report.to_json(f"{output_dir}/bond_rating_report.json")
    
    print(f"✓ Bond rating report created with {len(result_data)} bonds")
    print(f"✓ Files saved to {output_dir}/ directory")


def demonstrate_collateral_swap_integration():
    """Demonstrate collateral swap engine integration with reporting framework."""
    print("\n=== Collateral Swap Engine Integration ===")
    
    # Create sample data
    trade_data = create_sample_trade_data()
    
    # Create report and run pipeline
    report_date = datetime(2024, 1, 15)
    swap_report = CollateralSwapReport(
        report_name="Collateral Swap Analysis Report",
        report_date=report_date
    )
    
    # Run the complete pipeline (load data, run enrichments, post-process)
    result_data = swap_report.run_report(trade_data)
    
    # Export to different formats
    output_dir = "reports"
    os.makedirs(output_dir, exist_ok=True)
    
    swap_report.to_excel(f"{output_dir}/collateral_swap_report.xlsx")
    swap_report.to_html(f"{output_dir}/collateral_swap_report.html")
    swap_report.to_json(f"{output_dir}/collateral_swap_report.json")
    
    swap_count = result_data.get('collateral_swap_indicator', pd.Series([False])).sum()
    print(f"✓ Collateral swap report created with {len(result_data)} trades ({swap_count} swaps identified)")
    print(f"✓ Files saved to {output_dir}/ directory")


def demonstrate_market_value_integration():
    """Demonstrate market value calculator integration with reporting framework."""
    print("\n=== Market Value Calculator Integration ===")
    
    # Create sample data
    market_data = create_sample_market_value_data()
    
    # Create report and run pipeline
    report_date = datetime(2024, 1, 15)
    market_report = MarketValueReport(
        report_name="Market Value Analysis Report",
        report_date=report_date
    )
    
    # Run the complete pipeline (load data, run enrichments, post-process)
    result_data = market_report.run_report(market_data)
    
    # Export to different formats
    output_dir = "reports"
    os.makedirs(output_dir, exist_ok=True)
    
    market_report.to_excel(f"{output_dir}/market_value_report.xlsx")
    market_report.to_html(f"{output_dir}/market_value_report.html")
    market_report.to_json(f"{output_dir}/market_value_report.json")
    
    print(f"✓ Market value report created with {len(result_data)} trades")
    print(f"✓ Files saved to {output_dir}/ directory")


def demonstrate_column_mapping_integration():
    """Demonstrate column mapping integration with reports."""
    print("\n=== Column Mapping Integration ===")
    
    # Create sample data
    bond_data = create_sample_bond_data()
    
    # Process with bond rating engine
    engine = BondScoringEngine(bond_data)
    result_data = engine.compute_scores(use_average=False)
    
    # Create custom column mapping
    custom_mapping = ColumnMappingConfig(
        column_mappings={
            'Bond.ID': 'Bond Identifier',
            'Bond.Issuer': 'Issuer Name',
            'Bond.CollatType': 'Collateral Type',
            'rating_score': 'Rating Score',
            'asset_class': 'Asset Classification',
            'final_score': 'Final Score'
        },
        column_order=[
            'Bond Identifier', 'Issuer Name', 'Collateral Type',
            'Rating Score', 'Asset Classification', 'Final Score'
        ]
    )
    
    # Apply column mapping to data
    mapped_data = custom_mapping.apply_to_dataframe(result_data)
    
    # Create report with mapped data
    report_date = datetime(2024, 1, 15)
    mapped_report = BondRatingReport(
        data=mapped_data,
        report_name="Bond Rating Report (Mapped Columns)",
        report_date=report_date
    )
    
    # Export
    output_dir = "reports"
    os.makedirs(output_dir, exist_ok=True)
    mapped_report.to_excel(f"{output_dir}/bond_rating_mapped_report.xlsx")
    
    print(f"✓ Column mapping applied to {len(mapped_data)} bonds")
    print(f"✓ Mapped report saved to {output_dir}/bond_rating_mapped_report.xlsx")


def demonstrate_excel_file_loading():
    """Demonstrate loading data from Excel files and creating reports."""
    print("\n=== Excel File Loading Integration ===")
    
    try:
        # Create sample Excel files
        bond_engine = BondScoringEngine()
        bond_excel_file = bond_engine.create_sample_excel("sample_bond_data.xlsx")
        
        # Create report and run pipeline with file path
        report_date = datetime(2024, 1, 15)
        excel_report = BondRatingReport(
            report_name="Bond Rating Report (Excel Loaded)",
            report_date=report_date
        )
        
        # Run the complete pipeline with file path
        result_data = excel_report.run_report(bond_excel_file, sheet_name='BondData')
        
        # Export
        output_dir = "reports"
        os.makedirs(output_dir, exist_ok=True)
        excel_report.to_excel(f"{output_dir}/excel_loaded_report.xlsx")
        
        print(f"✓ Excel file loaded and processed: {len(result_data)} bonds")
        print(f"✓ Report saved to {output_dir}/excel_loaded_report.xlsx")
        
    except Exception as e:
        print(f"⚠ Excel loading demonstration skipped: {e}")


def demonstrate_multiple_file_formats():
    """Demonstrate loading data from different file formats."""
    print("\n=== Multiple File Format Loading ===")
    
    try:
        # Create sample data
        bond_data = create_sample_bond_data()
        
        # Create different file formats
        output_dir = "reports"
        os.makedirs(output_dir, exist_ok=True)
        
        # Save as CSV
        csv_file = f"{output_dir}/sample_bond_data.csv"
        bond_data.to_csv(csv_file, index=False)
        
        # Save as JSON
        json_file = f"{output_dir}/sample_bond_data.json"
        bond_data.to_json(json_file, orient='records', indent=2)
        
        # Create report for testing
        report_date = datetime(2024, 1, 15)
        format_report = BondRatingReport(
            report_name="Multi-Format Loading Test",
            report_date=report_date
        )
        
        # Test loading from CSV
        print("Testing CSV loading:")
        csv_data = format_report.load_data(csv_file, encoding='utf-8')
        print(f"✓ CSV loaded: {csv_data.shape}")
        
        # Test loading from JSON
        print("Testing JSON loading:")
        json_data = format_report.load_data(json_file)
        print(f"✓ JSON loaded: {json_data.shape}")
        
        # Test loading from DataFrame
        print("Testing DataFrame loading:")
        df_data = format_report.load_data(bond_data)
        print(f"✓ DataFrame loaded: {df_data.shape}")
        
        # Run the report pipeline with CSV data
        result_data = format_report.run_report(csv_file, encoding='utf-8')
        
        format_report.to_excel(f"{output_dir}/multi_format_test_report.xlsx")
        print(f"✓ Multi-format test report saved to {output_dir}/multi_format_test_report.xlsx")
        
    except Exception as e:
        print(f"⚠ Multi-format demonstration skipped: {e}")


def main():
    """Main demonstration function."""
    print("Trade Pipeline Integration with Reporting Framework")
    print("=" * 60)
    
    # Create output directory
    output_dir = "reports"
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        # Demonstrate different integrations
        demonstrate_bond_rating_integration()
        demonstrate_collateral_swap_integration()
        demonstrate_market_value_integration()
        demonstrate_column_mapping_integration()
        demonstrate_excel_file_loading()
        demonstrate_multiple_file_formats()
        
        print(f"\n=== Summary ===")
        print(f"✓ All reports generated successfully")
        print(f"✓ Reports saved to '{output_dir}/' directory")
        print(f"✓ Available formats: Excel (.xlsx), HTML (.html), JSON (.json)")
        print(f"✓ Each report includes professional formatting and metadata")
        print(f"✓ Data loading supports: Excel, CSV, JSON, Parquet, and DataFrame")
        print(f"✓ Pipeline integration supports: Bond Rating, Collateral Swap, and Market Value engines")
        
    except Exception as e:
        print(f"Error during demonstration: {e}")
        print("Some demonstrations may have been skipped due to missing dependencies")


if __name__ == "__main__":
    main()
