"""
Example of Data Processing Pipeline Usage

This module demonstrates the enhanced DataProcessingPipeline with support for:
- Individual operations: set(), enrich(), filter(), get()
- List operations: enrich([list]), filter([list])
- Batch operations: enrich_all(), filter_all(), process()
- Method chaining for all operations
- Load date support for market data dependent operations

Data loading is handled externally for better separation of concerns.
"""

import pandas as pd
import numpy as np
from typing import List
from datetime import datetime, timedelta

# Import the enhanced components
from trading_analytics_framework.trade_pipeline.simple_processor import DataProcessingPipeline
from trading_analytics_framework.trade_pipeline.data_loader import DataLoader, load_risk_data, load_trade_data, load_ref_data
from trading_analytics_framework.reporting_framework.enhanced_report import (
    EnhancedReport, BondAnalysisReport, RiskAnalysisReport, FlexibleAnalysisReport
)
from trading_analytics_framework.trade_pipeline.config import DatabaseType


def demonstrate_enhanced_pipeline():
    """
    Demonstrate the enhanced DataProcessingPipeline with list support.
    """
    print("=" * 60)
    print("ENHANCED DATA PROCESSING PIPELINE DEMONSTRATION")
    print("=" * 60)
    
    try:
        # Create pipeline with specific load date
        load_date = datetime(2024, 1, 15)
        pipeline = DataProcessingPipeline(load_date=load_date)
        print(f"✓ Pipeline created successfully with load date: {load_date}")
        
        # Example 1: Individual operations (original functionality)
        print("\n1. Individual operations...")
        custom_data = pd.DataFrame({
            'trade_id': ['T001', 'T002', 'T003'],
            'amount': [1000000, 2000000, 3000000],
            'currency': ['EUR', 'USD', 'GBP'],
            'book': ['TRADING', 'WASH', 'TRADING']
        })
        
        processed_data = (pipeline
                         .set(custom_data)
                         .enrich('counterparty_mapping')
                         .filter('remove_wash_books')
                         .get())
        print(f"✓ Individual operations completed: {processed_data.shape}")
        
        # Example 2: List operations with enrich()
        print("\n2. List operations with enrich()...")
        try:
            risk_data = load_risk_data(['trade_id', 'amount', 'currency', 'counterparty'])
            
            processed_data = (pipeline
                            .set(risk_data)
                            .enrich(['counterparty_mapping', 'market_value'])
                            .filter('remove_wash_books')
                            .get())
            print(f"✓ List enrichments completed: {processed_data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - pattern demonstrated")
        
        # Example 3: List operations with filter()
        print("\n3. List operations with filter()...")
        try:
            trade_data = load_trade_data(['trade_id', 'notional', 'product', 'book'])
            
            processed_data = (pipeline
                            .set(trade_data)
                            .enrich('counterparty_mapping')
                            .filter(['remove_wash_books', 'remove_maturing_trades'])
                            .get())
            print(f"✓ List filters completed: {processed_data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - pattern demonstrated")
        
        # Example 4: Batch operations with enrich_all() and filter_all()
        print("\n4. Batch operations...")
        try:
            bond_data = load_ref_data(['bond_id', 'issuer', 'rating', 'maturity_date'])
            
            processed_data = (pipeline
                            .set(bond_data)
                            .enrich_all(['bond_issuer_ratings', 'tenor_bucketing'])
                            .filter_all(['remove_wash_books', 'remove_maturing_trades'])
                            .get())
            print(f"✓ Batch operations completed: {processed_data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - pattern demonstrated")
        
        # Example 5: Process method for complete pipeline
        print("\n5. Process method for complete pipeline...")
        try:
            trade_data = load_trade_data(['trade_id', 'notional', 'product', 'book'])
            
            processed_data = (pipeline
                            .set(trade_data)
                            .process(
                                enrichments=['counterparty_mapping', 'market_value'],
                                filters=['remove_wash_books', 'remove_maturing_trades', 'remove_internal_interdesk']
                            )
                            .get())
            print(f"✓ Complete pipeline processed: {processed_data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - pattern demonstrated")
        
        # Example 6: Mixed individual and list operations
        print("\n6. Mixed individual and list operations...")
        try:
            risk_data = load_risk_data(['trade_id', 'amount', 'currency', 'counterparty'])
            
            processed_data = (pipeline
                            .set(risk_data)
                            .enrich('counterparty_mapping')  # Individual
                            .filter(['remove_wash_books', 'remove_maturing_trades'])  # List
                            .enrich(['market_value', 'tenor_bucketing'])  # List
                            .filter('remove_internal_interdesk')  # Individual
                            .get())
            print(f"✓ Mixed operations completed: {processed_data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - pattern demonstrated")
        
    except Exception as e:
        print(f"✗ Enhanced pipeline demonstration failed: {e}")


def demonstrate_load_date_functionality():
    """
    Demonstrate load date functionality in the pipeline.
    """
    print("\n" + "=" * 60)
    print("LOAD DATE FUNCTIONALITY DEMONSTRATION")
    print("=" * 60)
    
    try:
        # Example 1: Pipeline with specific load date
        print("\n1. Pipeline with specific load date...")
        specific_date = datetime(2024, 1, 15)
        pipeline = DataProcessingPipeline(load_date=specific_date)
        print(f"✓ Pipeline created with load date: {specific_date}")
        
        # Example 2: Pipeline with default load date (current time)
        print("\n2. Pipeline with default load date...")
        default_pipeline = DataProcessingPipeline()
        print(f"✓ Pipeline created with default load date: {default_pipeline.load_date}")
        
        # Example 3: Demonstrate load date usage in enrichments
        print("\n3. Load date usage in enrichments...")
        sample_data = pd.DataFrame({
            'leg_agr_mat_date': [
                datetime(2024, 2, 15),  # 31 days from load date
                datetime(2024, 3, 15),  # 59 days from load date
                datetime(2025, 1, 15),  # 365 days from load date
            ]
        })
        
        processed_data = (pipeline
                         .set(sample_data)
                         .enrich('tenor_bucketing')
                         .get())
        
        print("✓ Tenor bucketing applied with load date:")
        print(f"  Load date: {specific_date}")
        print(f"  Results: {processed_data[['tenor_bucket', 'is_short_term', 'is_medium_term', 'is_long_term']].to_dict('records')}")
        
        # Example 4: Demonstrate load date usage in filters
        print("\n4. Load date usage in filters...")
        maturing_data = pd.DataFrame({
            'leg_agr_mat_date': [
                datetime(2024, 1, 20),  # 5 days from load date (will be filtered)
                datetime(2024, 2, 15),  # 31 days from load date (will be kept)
                datetime(2024, 3, 15),  # 59 days from load date (will be kept)
            ]
        })
        
        filtered_data = (pipeline
                        .set(maturing_data)
                        .filter('remove_maturing_trades')
                        .get())
        
        print(f"✓ Maturing trades filter applied with load date:")
        print(f"  Load date: {specific_date}")
        print(f"  Original records: {len(maturing_data)}")
        print(f"  Filtered records: {len(filtered_data)}")
        print(f"  Removed records: {len(maturing_data) - len(filtered_data)}")
        
        # Example 5: Different load dates produce different results
        print("\n5. Different load dates produce different results...")
        
        # Create data with maturity dates
        test_data = pd.DataFrame({
            'leg_agr_mat_date': [
                datetime(2024, 1, 20),  # 5 days from first load date
                datetime(2024, 2, 15),  # 31 days from first load date
            ]
        })
        
        # Process with first load date
        pipeline1 = DataProcessingPipeline(load_date=datetime(2024, 1, 15))
        result1 = (pipeline1
                  .set(test_data)
                  .filter('remove_maturing_trades')
                  .get())
        
        # Process with second load date (30 days later)
        pipeline2 = DataProcessingPipeline(load_date=datetime(2024, 2, 14))
        result2 = (pipeline2
                  .set(test_data)
                  .filter('remove_maturing_trades')
                  .get())
        
        print(f"✓ Different load dates comparison:")
        print(f"  Load date 1: {datetime(2024, 1, 15)} -> {len(result1)} records kept")
        print(f"  Load date 2: {datetime(2024, 2, 14)} -> {len(result2)} records kept")
        print(f"  Difference: {len(result1) - len(result2)} records")
        
    except Exception as e:
        print(f"✗ Load date functionality demonstration failed: {e}")


def demonstrate_data_loader():
    """
    Demonstrate the external data loader functionality.
    """
    print("\n" + "=" * 60)
    print("EXTERNAL DATA LOADER DEMONSTRATION")
    print("=" * 60)
    
    try:
        # Example 1: Using convenience functions
        print("\n1. Using convenience functions...")
        try:
            risk_data = load_risk_data(['trade_id', 'amount'])
            print("✓ Risk data loaded using convenience function")
        except NotImplementedError:
            print("✓ Correctly caught NotImplementedError - replace with your functions")
        
        # Example 2: Using DataLoader class
        print("\n2. Using DataLoader class...")
        loader = DataLoader()
        try:
            trade_data = loader.load_trade_data(['trade_id', 'notional'])
            print("✓ Trade data loaded using DataLoader class")
        except NotImplementedError:
            print("✓ Correctly caught NotImplementedError - replace with your functions")
        
        # Example 3: Using generic load function
        print("\n3. Using generic load function...")
        try:
            ref_data = load_ref_data(['bond_id', 'issuer'])
            print("✓ Reference data loaded using generic function")
        except NotImplementedError:
            print("✓ Correctly caught NotImplementedError - replace with your functions")
        
    except Exception as e:
        print(f"✗ Data loader demonstration failed: {e}")


def demonstrate_analysis_reports():
    """
    Demonstrate analysis reports with the enhanced pipeline.
    """
    print("\n" + "=" * 60)
    print("ANALYSIS REPORTS WITH ENHANCED PIPELINE")
    print("=" * 60)
    
    try:
        # Example 1: Bond Analysis Report
        print("\n1. Bond Analysis Report...")
        try:
            bond_report = BondAnalysisReport()
            print(f"✓ Bond report created: {bond_report.report_name}")
            print(f"✓ Data shape: {bond_report.data.shape}")
            print(f"✓ Analysis results: {list(bond_report.analysis_results.keys())}")
        except NotImplementedError:
            print("✓ Data loading not implemented - report pattern demonstrated")
        
        # Example 2: Risk Analysis Report
        print("\n2. Risk Analysis Report...")
        try:
            risk_report = RiskAnalysisReport()
            print(f"✓ Risk report created: {risk_report.report_name}")
            print(f"✓ Data shape: {risk_report.data.shape}")
            print(f"✓ Analysis results: {list(risk_report.analysis_results.keys())}")
        except NotImplementedError:
            print("✓ Data loading not implemented - report pattern demonstrated")
        
        # Example 3: Flexible Analysis Report
        print("\n3. Flexible Analysis Report...")
        try:
            flexible_report = FlexibleAnalysisReport(
                database_type=DatabaseType.RISKDB,
                columns=['trade_id', 'notional', 'market_value'],
                initial_filters=['remove_wash_books'],
                initial_enrichments=['counterparty_mapping'],
                report_name="Custom Flexible Report"
            )
            print(f"✓ Flexible report created: {flexible_report.report_name}")
            print(f"✓ Initial data shape: {flexible_report.data.shape}")
            
            # Extend the processing
            print("\n4. Extending processing...")
            flexible_report.extend_processing(
                enrichments=['market_value'],
                filters=['remove_maturing_trades']
            )
            print(f"✓ Extended data shape: {flexible_report.data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - report pattern demonstrated")
        
    except Exception as e:
        print(f"✗ Analysis reports demonstration failed: {e}")


def demonstrate_error_handling():
    """
    Demonstrate error handling with the enhanced pipeline.
    """
    print("\n" + "=" * 60)
    print("ERROR HANDLING DEMONSTRATION")
    print("=" * 60)
    
    try:
        pipeline = DataProcessingPipeline()
        
        # Example 1: Non-existent enrichment
        print("\n1. Testing with non-existent enrichment...")
        try:
            test_data = pd.DataFrame({'trade_id': ['T001'], 'amount': [1000000]})
            (pipeline
             .set(test_data)
             .enrich('nonexistent_enrichment')
             .get())
        except Exception as e:
            print(f"✓ Correctly caught error: {type(e).__name__}: {e}")
        
        # Example 2: Missing required columns
        print("\n2. Testing with missing required columns...")
        try:
            test_data = pd.DataFrame({'trade_id': ['T001'], 'amount': [1000000]})
            (pipeline
             .set(test_data)
             .enrich('bond_issuer_ratings')  # Requires 'bond_id' column
             .get())
        except Exception as e:
            print(f"✓ Correctly caught error: {type(e).__name__}: {e}")
        
        # Example 3: No data set
        print("\n3. Testing with no data set...")
        try:
            pipeline.enrich('counterparty_mapping')
        except Exception as e:
            print(f"✓ Correctly caught error: {type(e).__name__}: {e}")
        
        # Example 4: Invalid list operations
        print("\n4. Testing with invalid list operations...")
        try:
            test_data = pd.DataFrame({'trade_id': ['T001'], 'amount': [1000000]})
            (pipeline
             .set(test_data)
             .enrich(['nonexistent_enrichment', 'counterparty_mapping'])
             .get())
        except Exception as e:
            print(f"✓ Correctly caught error: {type(e).__name__}: {e}")
        
    except Exception as e:
        print(f"✗ Error handling demonstration failed: {e}")


def demonstrate_common_patterns():
    """
    Demonstrate common usage patterns with the enhanced pipeline.
    """
    print("\n" + "=" * 60)
    print("COMMON USAGE PATTERNS")
    print("=" * 60)
    
    try:
        pipeline = DataProcessingPipeline()
        
        # Pattern 1: Simple individual operations
        print("\n1. Simple individual operations...")
        existing_data = pd.DataFrame({
            'trade_id': ['T001', 'T002'],
            'amount': [1000000, 2000000],
            'counterparty': ['CP1', 'CP2']
        })
        
        processed_existing = (pipeline
                            .set(existing_data)
                            .enrich('counterparty_mapping')
                            .get())
        print(f"✓ Individual operations: {processed_existing.shape}")
        
        # Pattern 2: List operations
        print("\n2. List operations...")
        try:
            risk_data = load_risk_data(['trade_id', 'amount', 'book'])
            
            processed_data = (pipeline
                            .set(risk_data)
                            .enrich(['counterparty_mapping', 'market_value'])
                            .filter(['remove_wash_books', 'remove_maturing_trades'])
                            .get())
            print(f"✓ List operations: {processed_data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - pattern demonstrated")
        
        # Pattern 3: Batch operations
        print("\n3. Batch operations...")
        try:
            ref_data = load_ref_data(['bond_id', 'issuer'])
            
            processed_data = (pipeline
                            .set(ref_data)
                            .enrich_all(['bond_issuer_ratings', 'tenor_bucketing'])
                            .filter_all(['remove_wash_books'])
                            .get())
            print(f"✓ Batch operations: {processed_data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - pattern demonstrated")
        
        # Pattern 4: Process method
        print("\n4. Process method...")
        try:
            trade_data = load_trade_data(['trade_id', 'notional', 'product'])
            
            processed_data = (pipeline
                            .set(trade_data)
                            .process(
                                enrichments=['counterparty_mapping', 'market_value'],
                                filters=['remove_wash_books', 'remove_maturing_trades']
                            )
                            .get())
            print(f"✓ Process method: {processed_data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - pattern demonstrated")
        
        # Pattern 5: Mixed operations
        print("\n5. Mixed operations...")
        try:
            trade_data = load_trade_data(['trade_id', 'notional', 'product'])
            
            processed_data = (pipeline
                            .set(trade_data)
                            .enrich('counterparty_mapping')  # Individual
                            .filter(['remove_wash_books', 'remove_maturing_trades'])  # List
                            .enrich(['market_value'])  # List
                            .filter('remove_internal_interdesk')  # Individual
                            .get())
            print(f"✓ Mixed operations: {processed_data.shape}")
        except NotImplementedError:
            print("✓ Data loading not implemented - pattern demonstrated")
        
    except Exception as e:
        print(f"✗ Common patterns demonstration failed: {e}")


def main():
    """
    Main function demonstrating the enhanced DataProcessingPipeline.
    """
    print("ENHANCED DATA PROCESSING PIPELINE EXAMPLES")
    print("=" * 80)
    print("This demonstrates the enhanced DataProcessingPipeline with:")
    print("1. Individual operations: set(), enrich(), filter(), get()")
    print("2. List operations: enrich([list]), filter([list])")
    print("3. Batch operations: enrich_all(), filter_all(), process()")
    print("4. Method chaining for all operations")
    print("5. Load date support for market data dependent operations")
    print("\nData loading is handled externally for better separation of concerns.")
    print("=" * 80)
    
    # Run demonstrations
    demonstrate_enhanced_pipeline()
    demonstrate_load_date_functionality()
    demonstrate_data_loader()
    demonstrate_analysis_reports()
    demonstrate_error_handling()
    demonstrate_common_patterns()
    
    print("\n" + "=" * 80)
    print("ENHANCED PIPELINE COMPLETE")
    print("=" * 80)
    print("The enhanced approach provides:")
    print("✓ Individual operations for fine-grained control")
    print("✓ List operations for batch processing")
    print("✓ Batch operations for complete pipelines")
    print("✓ Clean, readable method chaining")
    print("✓ Consistent validation for all operations")
    print("✓ Load date support for market data dependent operations")
    print("✓ Easy to understand and use")
    print("✓ Better testability and flexibility")
    print("\nReplace the NotImplementedError in DataLoader with your actual functions.")


if __name__ == "__main__":
    main()
