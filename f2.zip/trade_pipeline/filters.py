"""
Filters module for trading dataset pipeline.
Contains all filtering operations using vectorized pandas operations.
"""
import pandas as pd
import numpy as np
from typing import Optional
from datetime import datetime
from .base import BaseFilter
from .config import (
    ColumnName, NON_RELEVANT_PRDS, WASH_BOOKS, INTERNAL_INTERDESK_TRADES,
    NON_CASH_RELEVANT_PRDS, PGI_XMTS_NOTES
)
from .decorators import register_filter
from .config import FilterType



@register_filter(FilterType.REMOVE_WASH_BOOKS.value, required_columns=[ColumnName.BOOK.value])
class WashBookFilter(BaseFilter):
    """
    Specialized filter for removing wash books.
    
    This filter specifically targets wash book trades for removal.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _apply_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """Remove wash books from the DataFrame."""
        return df[~df[ColumnName.BOOK.value].isin(WASH_BOOKS)]


@register_filter(FilterType.REMOVE_MATURING_TRADES.value, required_columns=[ColumnName.LEG_AGR_MAT_DATE.value])
class MaturingTradesFilter(BaseFilter):
    """
    Specialized filter for removing maturing trades.
    
    This filter removes trades that are maturing within a specified timeframe.
    """
    
    def __init__(self, days_threshold: int = 30, load_date: Optional[datetime] = None):
        super().__init__(load_date)
        self.days_threshold = days_threshold
    
    def _apply_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """Remove trades maturing within the threshold period."""
        maturity_date = pd.to_datetime(df[ColumnName.LEG_AGR_MAT_DATE.value])
        threshold_date = pd.Timestamp(self.load_date) + pd.Timedelta(days=self.days_threshold)
        return df[maturity_date > threshold_date]


@register_filter(FilterType.REMOVE_INTERNAL_INTERDESK.value, required_columns=[ColumnName.COUNTERPARTY.value])
class InternalInterdeskFilter(BaseFilter):
    """
    Specialized filter for removing internal interdesk trades.
    
    This filter removes trades between internal desks.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _apply_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """Remove internal interdesk trades."""
        return df[~df[ColumnName.COUNTERPARTY.value].isin(INTERNAL_INTERDESK_TRADES)]


@register_filter(FilterType.REMOVE_NON_CASH_RELEVANT.value, required_columns=[ColumnName.PRODUCT_TYPE.value])
class NonCashRelevantFilter(BaseFilter):
    """
    Specialized filter for removing non-cash relevant PRDs.
    
    This filter removes product types that are not cash relevant.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _apply_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """Remove non-cash relevant PRDs."""
        return df[~df[ColumnName.PRODUCT_TYPE.value].isin(NON_CASH_RELEVANT_PRDS)]


@register_filter(FilterType.REMOVE_PGI_XMTS_NOTES.value, required_columns=[ColumnName.PRODUCT_TYPE.value])
class PgiXmtsNotesFilter(BaseFilter):
    """
    Specialized filter for removing PGI/XMTS notes.
    
    This filter removes specific product types related to PGI/XMTS notes.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _apply_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """Remove PGI/XMTS notes from the DataFrame."""
        return df[~df[ColumnName.PRODUCT_TYPE.value].isin(PGI_XMTS_NOTES)]


@register_filter(FilterType.REMOVE_NON_RELEVANT_PRDS.value, required_columns=[ColumnName.PRODUCT_TYPE.value])
class NonRelevantPrdsFilter(BaseFilter):
    """
    Specialized filter for removing non-relevant PRDs.
    
    This filter removes product types that are not relevant for analysis.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _apply_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """Remove non-relevant PRDs from the DataFrame."""
        return df[~df[ColumnName.PRODUCT_TYPE.value].isin(NON_RELEVANT_PRDS)] 