"""
Example demonstrating the Treasury SNU and PnL Attribution classification enrichments.

This example shows how to use the classification enrichments to categorize trades
based on Treasury SNU rules and PnL Attribution strategies.
"""

import pandas as pd
import numpy as np
from datetime import datetime
from trading_analytics_framework.trade_pipeline.simple_processor import DataProcessingPipeline


def create_sample_trade_data():
    """Create sample trade data for testing classification enrichments."""
    sample_data = {
        # Trade identification
        'Trade.ID': [f'TRADE_{i:03d}' for i in range(1, 16)],
        
        # Treasury SNU Source classification fields
        'LegArg.IsSecured': [False, True, False, True, False, True, False, True, False, True, False, True, False, True, False],
        'LegArg.IsCollateralSwap': [True, False, True, False, True, False, True, False, True, False, True, False, True, False, True],
        'CollateralSwapType': ['Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade', 'Upgrade'],
        'DealAttr.ProjectName': ['PGI-001', 'Xmt-002', 'PGI-003', 'Xmt-004', 'PGI-005', 'Xmt-006', 'PGI-007', 'Xmt-008', 'PGI-009', 'Xmt-010', 'PGI-011', 'Xmt-012', 'PGI-013', 'Xmt-014', 'PGI-015'],
        'BondLqdty.Hqlalevel': [1, '2A', '2B', 1, '2A', '2B', 1, '2A', '2B', 1, '2A', '2B', 1, '2A', '2B'],
        'Book.System': ['K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E', 'K-E'],
        'Book': ['CMMM-CFSF', 'CMMM-CFSFA', 'CMMM-CFSF', 'CMMM-CFSFA', 'CMMM-CFSF', 'CMMM-CFSFA', 'CMMM-CFSF', 'CMMM-CFSFA', 'CMMM-CFSF', 'CMMM-CFSFA', 'CMMM-CFSF', 'CMMM-CFSFA', 'CMMM-CFSF', 'CMMM-CFSFA', 'CMMM-CFSF'],
        'Deal.BSCpty': ['LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464', 'LO-0751464'],
        'Deal.BBG': [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500],
        'K': [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750],
        
        # Treasury SNU Use classification fields
        'Leg.Type': ['REV', 'TRV', 'REV', 'TRV', 'REV', 'TRV', 'REV', 'TRV', 'REV', 'TRV', 'REV', 'TRV', 'REV', 'TRV', 'REV'],
        'isSFT': [True, False, True, False, True, False, True, False, True, False, True, False, True, False, True],
        'Cpty.IsInternal': [True, False, True, False, True, False, True, False, True, False, True, False, True, False, True],
        'BondLiquidityLevel': [1, '2A', '2B', 1, '2A', '2B', 1, '2A', '2B', 1, '2A', '2B', 1, '2A', '2B'],
        
        # PnL Attribution Financing classification fields
        'Funding/Financing Category': ['Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing', 'Financing'],
        'Cpty.BusinessGroup': ['HedgeFund', 'Bank', 'HedgeFund', 'Bank', 'HedgeFund', 'Bank', 'HedgeFund', 'Bank', 'HedgeFund', 'Bank', 'HedgeFund', 'Bank', 'HedgeFund', 'Bank', 'HedgeFund'],
        'LegArg.Maturity': [6, 12, 3, 15, 9, 18, 6, 12, 3, 15, 9, 18, 6, 12, 3],
        'MaturityType': ['Term', 'Term', 'Open', 'Term', 'Evergreen', 'Term', 'Open', 'Term', 'Evergreen', 'Term', 'Open', 'Term', 'Evergreen', 'Term', 'Open'],
        
        # PnL Attribution Funding classification fields
        'Leg.Underl': ['B:DE000A30VS64', 'B:DE000A351T77', 'B:IT0005496788', 'B:DE000A30VS64', 'B:DE000A351T77', 'B:IT0005496788', 'B:DE000A30VS64', 'B:DE000A351T77', 'B:IT0005496788', 'B:DE000A30VS64', 'B:DE000A351T77', 'B:IT0005496788', 'B:DE000A30VS64', 'B:DE000A351T77', 'B:IT0005496788'],
        'Ccy': ['EUR', 'USD', 'EUR', 'USD', 'EUR', 'USD', 'EUR', 'USD', 'EUR', 'USD', 'EUR', 'USD', 'EUR', 'USD', 'EUR'],
        'Bond.Issuer': ['WENDL', 'Other', 'WENDL', 'Other', 'WENDL', 'Other', 'WENDL', 'Other', 'WENDL', 'Other', 'WENDL', 'Other', 'WENDL', 'Other', 'WENDL']
    }
    
    return pd.DataFrame(sample_data)


def demonstrate_treasury_snu_classifications():
    """Demonstrate Treasury SNU classification enrichments."""
    print("=" * 60)
    print("TREASURY SNU CLASSIFICATION DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_trade_data()
    
    # Use the pipeline with Treasury SNU enrichment
    pipeline = DataProcessingPipeline(load_date=datetime(2024, 1, 15))
    
    try:
        # Treasury SNU classification (both Source and Use)
        print("=== Treasury SNU Classification ===")
        treasury_df = (pipeline
                      .set(df)
                      .enrich('treasury_snu')
                      .get())
        
        print("Treasury SNU Classification Results:")
        treasury_columns = ['Trade.ID', 'DealAttr.ProjectName', 'Book', 'TreasurySNU_Source_Classification', 'TreasurySNU_Use_Classification', 'TreasurySNU_Funding_Source_Use', 'TreasurySNU_Combined_Classification']
        print(treasury_df[treasury_columns].to_string(index=False))
        print()
        
        # Show Source classification distribution
        print("Source Classification Distribution:")
        source_counts = treasury_df['TreasurySNU_Source_Classification'].value_counts()
        for classification, count in source_counts.items():
            print(f"  {classification}: {count}")
        print()
        
        # Show Use classification distribution
        print("Use Classification Distribution:")
        use_counts = treasury_df['TreasurySNU_Use_Classification'].value_counts()
        for classification, count in use_counts.items():
            print(f"  {classification}: {count}")
        print()
        
        # Show Funding Source/Use distribution
        print("Funding Source/Use Distribution:")
        funding_source_use_counts = treasury_df['TreasurySNU_Funding_Source_Use'].value_counts()
        for classification, count in funding_source_use_counts.items():
            print(f"  {classification}: {count}")
        print()
        
        # Show Combined Classification distribution
        print("Combined Classification Distribution:")
        combined_counts = treasury_df['TreasurySNU_Combined_Classification'].value_counts()
        for classification, count in combined_counts.items():
            print(f"  {classification}: {count}")
        print()
        
    except Exception as e:
        print(f"Error during Treasury SNU classification: {e}")
        import traceback
        traceback.print_exc()


def demonstrate_pnl_attribution_classifications():
    """Demonstrate PnL Attribution classification enrichments."""
    print("=" * 60)
    print("PNL ATTRIBUTION CLASSIFICATION DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_trade_data()
    
    # Use the pipeline with PnL Attribution enrichment
    pipeline = DataProcessingPipeline(load_date=datetime(2024, 1, 15))
    
    try:
        # PnL Attribution classification (both Financing and Funding)
        print("=== PnL Attribution Classification ===")
        pnl_df = (pipeline
                 .set(df)
                 .enrich('pnl_attribution')
                 .get())
        
        print("PnL Attribution Classification Results:")
        pnl_columns = ['Trade.ID', 'Cpty.BusinessGroup', 'LegArg.Maturity', 'PnLAttribution_Financing_Strategy', 'PnLAttribution_Funding_Strategy', 'PnLAttribution_Financing_Funding', 'PnLAttribution_Combined_Strategy']
        print(pnl_df[pnl_columns].to_string(index=False))
        print()
        
        # Show Financing strategy distribution
        print("Financing Strategy Distribution:")
        financing_counts = pnl_df['PnLAttribution_Financing_Strategy'].value_counts()
        for strategy, count in financing_counts.items():
            print(f"  {strategy}: {count}")
        print()
        
        # Show Funding strategy distribution
        print("Funding Strategy Distribution:")
        funding_counts = pnl_df['PnLAttribution_Funding_Strategy'].value_counts()
        for strategy, count in funding_counts.items():
            print(f"  {strategy}: {count}")
        print()
        
        # Show Financing/Funding distribution
        print("Financing/Funding Distribution:")
        financing_funding_counts = pnl_df['PnLAttribution_Financing_Funding'].value_counts()
        for classification, count in financing_funding_counts.items():
            print(f"  {classification}: {count}")
        print()
        
        # Show Combined Strategy distribution
        print("Combined Strategy Distribution:")
        combined_strategy_counts = pnl_df['PnLAttribution_Combined_Strategy'].value_counts()
        for strategy, count in combined_strategy_counts.items():
            print(f"  {strategy}: {count}")
        print()
        
    except Exception as e:
        print(f"Error during PnL Attribution classification: {e}")
        import traceback
        traceback.print_exc()


def demonstrate_combined_classifications():
    """Demonstrate combined classification enrichments."""
    print("=" * 60)
    print("COMBINED CLASSIFICATION DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_trade_data()
    
    # Use the pipeline with multiple enrichments
    pipeline = DataProcessingPipeline(load_date=datetime(2024, 1, 15))
    
    try:
        # Apply all classification enrichments
        combined_df = (pipeline
                      .set(df)
                      .enrich(['treasury_snu', 'pnl_attribution'])
                      .get())
        
        print("Combined Classification Results:")
        combined_columns = [
            'Trade.ID', 'TreasurySNU_Funding_Source_Use', 'TreasurySNU_Combined_Classification',
            'PnLAttribution_Financing_Funding', 'PnLAttribution_Combined_Strategy'
        ]
        print(combined_df[combined_columns].to_string(index=False))
        print()
        
        # Show summary statistics
        print("Classification Summary:")
        print(f"Total trades: {len(combined_df)}")
        print(f"Unique funding source/use types: {combined_df['TreasurySNU_Funding_Source_Use'].nunique()}")
        print(f"Unique financing/funding types: {combined_df['PnLAttribution_Financing_Funding'].nunique()}")
        print()
        
        # Cross-tabulation analysis
        print("Funding Source/Use vs Financing/Funding Cross-Tabulation:")
        cross_tab = pd.crosstab(combined_df['TreasurySNU_Funding_Source_Use'], combined_df['PnLAttribution_Financing_Funding'])
        print(cross_tab)
        print()
        
        # Show detailed breakdown
        print("Detailed Classification Breakdown:")
        print("Treasury SNU Funding Source/Use:")
        print(combined_df['TreasurySNU_Funding_Source_Use'].value_counts())
        print()
        print("PnL Attribution Financing/Funding:")
        print(combined_df['PnLAttribution_Financing_Funding'].value_counts())
        print()
        
    except Exception as e:
        print(f"Error during combined classification: {e}")
        import traceback
        traceback.print_exc()


def main():
    """Run all demonstrations."""
    try:
        demonstrate_treasury_snu_classifications()
        demonstrate_pnl_attribution_classifications()
        demonstrate_combined_classifications()
        
        print("=" * 60)
        print("DEMONSTRATION COMPLETE")
        print("=" * 60)
        print("The classification enrichments now provide comprehensive trade categorization")
        print("including:")
        print("- Treasury SNU Source and Use classifications (combined)")
        print("- PnL Attribution Financing and Funding strategies (combined)")
        print("- Funding Source/Use and Financing/Funding type indicators")
        print("- Combined classification strings for easy analysis")
        print("- Prefixed column names for clear identification")
        print("- Efficient numpy-based classification using np.select")
        print("- Comprehensive error handling and validation")
        
    except Exception as e:
        print(f"Demonstration failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
