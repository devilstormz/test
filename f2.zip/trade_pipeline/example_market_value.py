"""
Example demonstrating the MarketValueEnrichment functionality.

This example shows how to use the MarketValueEnrichment with the new
MarketValueCalculator to perform comprehensive market value calculations.
"""

import pandas as pd
import numpy as np
from datetime import datetime
from trading_analytics_framework.trade_pipeline.simple_processor import DataProcessingPipeline
from trading_analytics_framework.trade_pipeline.market_value_calculator import MarketValueCalculator, MarketValueEnrichmentConfig


def create_sample_data():
    """Create sample data for testing market value calculations."""
    sample_data = {
        "PRD": ["CASH_DEPOSIT", "REPO", "GOVERNMENT_BOND", "INTEREST_RATE_SWAP", "CROSS_CURRENCY_SWAP"],
        "CCY": ["USD", "EUR", "GBP", "JPY", "USD"],
        "Leg.PayRec": ["Receive", "Pay", "Receive", "Pay", "Receive"],
        "Leg.Type": ["RECEIVE", "PAY", "BUY", "SELL", "RECEIVE"],
        "Leg.StartCash": [1000000, 500000, 750000, 0, 2000000],
        "LegArg.Notional": [1000000, 500000, 750000, 1500000, 2000000],
        "FX": [0.85, 1.0, 1.15, 0.007, 0.85],
        "PoolFactor": [1.0, 0.98, 1.02, 1.0, 1.0],
        "Mkt Price of security": [100.5, 99.8, 101.2, 100.0, 100.0],
        "system": ["B-E", "MAG", "B-E", "MAG", "B-E"],
        "Bond.Currency": ["", "EUR", "GBP", "", ""]
    }
    
    return pd.DataFrame(sample_data)


def demonstrate_market_value_calculator():
    """Demonstrate the MarketValueCalculator directly."""
    print("=" * 60)
    print("MARKET VALUE CALCULATOR DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_data()
    print("Original DataFrame:")
    print(df.to_string(index=False))
    print()
    
    # Initialize calculator and process data
    calculator = MarketValueCalculator()
    calculated_df = calculator.calculate_market_values(df)
    
    # Display results
    print("Calculated Market Values:")
    new_columns = [
        calculator.config.PRODUCT_TYPE_BUCKET_COLUMN,
        calculator.config.CASH_CCY_COLUMN,
        calculator.config.SECURITY_CCY_COLUMN,
        calculator.config.CASH_AMT_COLUMN,
        calculator.config.SECURITY_AMT_COLUMN,
        calculator.config.EUR_CASH_AMT_COLUMN,
        calculator.config.EUR_SECURITY_MV_COLUMN,
        calculator.config.TRADE_DIRECTION_COLUMN,
        calculator.config.EUR_DIRECTIONAL_CASH_AMT_COLUMN,
        calculator.config.EUR_DIRECTIONAL_SECURITY_MV_COLUMN
    ]
    
    print(calculated_df[new_columns].to_string(index=False))
    print()


def demonstrate_market_value_enrichment():
    """Demonstrate the MarketValueEnrichment through the pipeline."""
    print("=" * 60)
    print("MARKET VALUE ENRICHMENT DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    df = create_sample_data()
    
    # Use the pipeline with market value enrichment
    pipeline = DataProcessingPipeline(load_date=datetime(2024, 1, 15))
    
    try:
        processed_df = (pipeline
                       .set(df)
                       .enrich('market_value')
                       .get())
        
        print("Processed DataFrame with Market Value Enrichment:")
        print(processed_df.to_string(index=False))
        print()
        
        # Show the new columns added by the enrichment
        original_columns = set(df.columns)
        new_columns = set(processed_df.columns) - original_columns
        
        if new_columns:
            print("New columns added by Market Value Enrichment:")
            for col in sorted(new_columns):
                print(f"  - {col}")
        print()
        
    except Exception as e:
        print(f"Error during market value enrichment: {e}")
        print("This might be due to missing required columns in the sample data.")


def demonstrate_custom_config():
    """Demonstrate using a custom configuration."""
    print("=" * 60)
    print("CUSTOM CONFIGURATION DEMONSTRATION")
    print("=" * 60)
    
    # Create custom configuration
    class CustomMarketValueConfig(MarketValueEnrichmentConfig):
        # Override some column names for different data format
        PRD_COLUMN = "Product"
        CCY_COLUMN = "Currency"
        LEG_ARG_NOTIONAL_COLUMN = "Notional"
    
    # Create sample data with custom column names
    custom_data = {
        "Product": ["CASH_DEPOSIT", "REPO", "GOVERNMENT_BOND"],
        "Currency": ["USD", "EUR", "GBP"],
        "Notional": [1000000, 500000, 750000],
        "FX": [0.85, 1.0, 1.15],
        "PoolFactor": [1.0, 0.98, 1.02],
        "Mkt Price of security": [100.5, 99.8, 101.2],
        "system": ["B-E", "MAG", "B-E"],
        "Bond.Currency": ["", "EUR", "GBP"],
        "Leg.PayRec": ["Receive", "Pay", "Receive"],
        "Leg.Type": ["RECEIVE", "PAY", "BUY"],
        "Leg.StartCash": [1000000, 500000, 750000]
    }
    
    df = pd.DataFrame(custom_data)
    
    # Use custom configuration
    calculator = MarketValueCalculator(CustomMarketValueConfig())
    calculated_df = calculator.calculate_market_values(df)
    
    print("Custom Configuration Results:")
    print(calculated_df[['Product', 'Currency', 'Notional', 
                        calculator.config.PRODUCT_TYPE_BUCKET_COLUMN,
                        calculator.config.CASH_AMT_COLUMN,
                        calculator.config.SECURITY_AMT_COLUMN]].to_string(index=False))


def main():
    """Run all demonstrations."""
    try:
        demonstrate_market_value_calculator()
        demonstrate_market_value_enrichment()
        demonstrate_custom_config()
        
        print("=" * 60)
        print("DEMONSTRATION COMPLETE")
        print("=" * 60)
        print("The MarketValueEnrichment now provides comprehensive market value")
        print("calculations including product classification, cash/security amounts,")
        print("EUR conversions, and trade direction analysis.")
        
    except Exception as e:
        print(f"Demonstration failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
