"""
Enrichments module for trading dataset pipeline.
Contains all enrichment operations using vectorized pandas operations.
"""
import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, List, Tuple, Union
from datetime import datetime
from trading_analytics_framework.trade_pipeline.base import BaseEnrichment
from trading_analytics_framework.trade_pipeline.config import (
    ColumnName, DataSource, LegType, ProductType, BookingSystem, MagTradeType,
    DatabaseType, TableName
)
from trading_analytics_framework.trade_pipeline.decorators import register_enrichment
from trading_analytics_framework.trade_pipeline.config import EnrichmentType
from trading_analytics_framework.trade_pipeline.market_value_calculator import MarketValueCalculator, MarketValueEnrichmentConfig
from trading_analytics_framework.trade_pipeline.bond_rating_engine import BondScoringEngine
from trading_analytics_framework.trade_pipeline.treasury_snu_classifier import TreasurySNUClassifier
from trading_analytics_framework.trade_pipeline.pnl_attribution_classifier import PnLAttributionClassifier


## Removed SimpleEnrichments at user's request


@register_enrichment(
    EnrichmentType.BOND_RATINGS.value,
    required_input=[
        'Bond.RtyDB',
        'Bond.RtySP', 
        'Bond.RtyMDY',
        'Bond.RtyFITCH',
        'Bond.Issuer.RtyDB',
        'Bond.Issuer.RtySP',
        'Bond.Issuer.RtyMDY', 
        'Bond.Issuer.RtyFITCH',
        'Bond.CollatType',
        'subordinated',
        'RtgAvg'
    ]
)
class BondRatingEnrichment(BaseEnrichment):
    """
    Bond rating enrichment using the BondScoringEngine.
    
    This enrichment computes comprehensive credit scores for bonds using
    multiple rating agencies and asset classification rules.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
        self.engine = None  # Will be initialized with dataframe during enrichment
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform bond rating enrichment on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame with bond rating scores
        """
        # Initialize engine with the dataframe
        self.engine = BondScoringEngine(df)
        
        # Use the BondScoringEngine to compute scores with worst-of approach
        enriched_df = self.engine.compute_scores(use_average=False, use_fallback_logic=True)
        
        # Map the output columns to the expected format for consistency
        enriched_df = enriched_df.rename(columns={
            'rating_score': 'bond_rating_score',
            'asset_class': 'bond_asset_class', 
            'asset_score': 'bond_asset_score',
            'final_score': 'bond_final_score'
        })
        
        return enriched_df


@register_enrichment(
    EnrichmentType.BOND_ISSUER.value,
    required_input=[
        ColumnName.BOND_ID.value,
        ColumnName.BOND_ISSUER.value,
        ColumnName.ISSUER_COUNTRY.value
    ]
)
class BondIssuerEnrichment(BaseEnrichment):
    """
    Bond issuer enrichment.
    
    This enrichment adds issuer-related information and classifications.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform bond issuer enrichment on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame
        """
        df = df.copy()
        
        # Add issuer information
        df['issuer_name'] = df[ColumnName.BOND_ISSUER.value].fillna('Unknown')
        df['issuer_country'] = df[ColumnName.ISSUER_COUNTRY.value].fillna('Unknown')
        
        # Add issuer type classification
        df['issuer_type'] = df['issuer_name'].apply(self._classify_issuer_type)
        
        return df
    
    def _classify_issuer_type(self, issuer_name: str) -> str:
        """
        Classify issuer type based on issuer name.
        
        Args:
            issuer_name: Name of the issuer
            
        Returns:
            Issuer type classification
        """
        if pd.isna(issuer_name) or issuer_name == 'Unknown':
            return 'Unknown'
        
        issuer_upper = issuer_name.upper()
        
        # Government issuers
        govt_keywords = ['GOVERNMENT', 'TREASURY', 'FEDERAL', 'STATE', 'MUNICIPAL', 'AGENCY']
        if any(keyword in issuer_upper for keyword in govt_keywords):
            return 'Government'
        
        # Financial institutions
        financial_keywords = ['BANK', 'FINANCIAL', 'INSURANCE', 'INVESTMENT', 'CREDIT']
        if any(keyword in issuer_upper for keyword in financial_keywords):
            return 'Financial'
        
        # Corporate issuers
        corporate_keywords = ['CORP', 'CORPORATION', 'INC', 'LTD', 'LLC', 'COMPANY']
        if any(keyword in issuer_upper for keyword in corporate_keywords):
            return 'Corporate'
        
        # Supranational
        supranational_keywords = ['WORLD BANK', 'IMF', 'EUROPEAN', 'INTERNATIONAL']
        if any(keyword in issuer_upper for keyword in supranational_keywords):
            return 'Supranational'
        
        return 'Other'


@register_enrichment(
    EnrichmentType.BOND_ISSUER_RATINGS.value,
    required_input=[
        'Bond.Issuer.RtyDB',
        'Bond.Issuer.RtySP',
        'Bond.Issuer.RtyMDY', 
        'Bond.Issuer.RtyFITCH',
        'Bond.CollatType',
        'subordinated'
    ]
)
class BondIssuerRatingEnrichment(BaseEnrichment):
    """
    Bond issuer rating enrichment.
    
    This enrichment computes issuer-specific rating scores.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
        self.engine = None  # Will be initialized with dataframe during enrichment
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform bond issuer rating enrichment on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame with issuer rating scores
        """
        # Initialize engine with the dataframe
        self.engine = BondScoringEngine(df)
        
        # Use the BondScoringEngine to compute issuer scores with average approach
        enriched_df = self.engine.compute_scores(use_average=True, use_fallback_logic=False)
        
        # Rename columns to be issuer-specific
        enriched_df = enriched_df.rename(columns={
            'rating_score': 'issuer_rating_score',
            'asset_class': 'issuer_asset_class',
            'asset_score': 'issuer_asset_score',
            'final_score': 'issuer_final_score'
        })
        
        return enriched_df


@register_enrichment(
    EnrichmentType.BOND_ENRICHMENTS.value,
    required_input=[
        ColumnName.BOND_ID.value,
        ColumnName.BOND_ISSUER.value,
        ColumnName.BOND_RATING.value,
        ColumnName.COUPON_RATE.value
    ]
)
class BondDataEnrichment(BaseEnrichment):
    """
    Comprehensive bond data enrichment.
    
    This enrichment combines multiple bond-related enrichments into a single operation.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
        self.rating_engine = None  # Will be initialized with dataframe during enrichment
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform comprehensive bond data enrichment on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame with all bond-related enrichments
        """
        df = df.copy()
        
        # Add basic bond information
        df['bond_coupon_rate'] = df[ColumnName.COUPON_RATE.value].fillna(0.0)
        df['bond_issuer_name'] = df[ColumnName.BOND_ISSUER.value].fillna('Unknown')
        
        # Add bond type classification
        df['bond_type'] = df['bond_coupon_rate'].apply(self._classify_bond_type)
        
        # Add maturity classification if maturity date is available
        if ColumnName.LEG_AGR_MAT_DATE.value in df.columns:
            df['maturity_classification'] = df[ColumnName.LEG_AGR_MAT_DATE.value].apply(self._classify_maturity)
        
        return df
    
    def _classify_bond_type(self, coupon_rate: float) -> str:
        """
        Classify bond type based on coupon rate.
        
        Args:
            coupon_rate: Bond coupon rate
            
        Returns:
            Bond type classification
        """
        if pd.isna(coupon_rate) or coupon_rate == 0:
            return 'Zero Coupon'
        elif coupon_rate < 0.02:  # 2%
            return 'Low Coupon'
        elif coupon_rate < 0.05:  # 5%
            return 'Medium Coupon'
        else:
            return 'High Coupon'
    
    def _classify_maturity(self, maturity_date) -> str:
        """
        Classify maturity based on maturity date.
        
        Args:
            maturity_date: Bond maturity date
            
        Returns:
            Maturity classification
        """
        if pd.isna(maturity_date):
            return 'Unknown'
        
        try:
            maturity = pd.to_datetime(maturity_date)
            current_date = pd.Timestamp(self.load_date)
            days_to_maturity = (maturity - current_date).days
            
            if days_to_maturity <= 30:
                return 'Short Term'
            elif days_to_maturity <= 365:
                return 'Medium Term'
            else:
                return 'Long Term'
        except:
            return 'Unknown'


@register_enrichment(
    EnrichmentType.TENOR_BUCKETING.value,
    required_input=[ColumnName.LEG_AGR_MAT_DATE.value]
)
class TenorBucketing(BaseEnrichment):
    """
    Tenor bucketing enrichment for maturity classification.
    
    This enrichment adds tenor buckets based on days to maturity.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform tenor bucketing on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame
        """
        df = df.copy()
        
        # Calculate days to maturity using load_date
        maturity_date = pd.to_datetime(df[ColumnName.LEG_AGR_MAT_DATE.value])
        current_date = pd.Timestamp(self.load_date)
        days_to_maturity = (maturity_date - current_date).dt.days
        
        # Apply tenor bucketing
        df['tenor_bucket'] = days_to_maturity.apply(self._get_tenor_bucket)
        df['is_short_term'] = days_to_maturity <= 30
        df['is_medium_term'] = (days_to_maturity > 30) & (days_to_maturity <= 365)
        df['is_long_term'] = days_to_maturity > 365
        
        return df
    
    def _get_tenor_bucket(self, days: int) -> str:
        """
        Get tenor bucket based on days to maturity.
        
        Args:
            days: Days to maturity
            
        Returns:
            Tenor bucket string
        """
        if days <= 30:
            return 'Short Term'
        elif days <= 365:
            return 'Medium Term'
        else:
            return 'Long Term'


@register_enrichment(
    EnrichmentType.COUNTERPARTY_MAPPING.value,
    required_input=[ColumnName.DEAL_BSCP_ID.value]
)
@register_enrichment(
    EnrichmentType.COUNTERPARTY.value,
    required_input=[ColumnName.DEAL_BSCP_ID.value]
)
class CounterpartyMapping(BaseEnrichment):
    """
    Counterparty mapping enrichment.
    
    This enrichment adds counterparty information based on BSCP ID.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform counterparty mapping on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame
        """
        df = df.copy()
        
        # Placeholder implementation - replace with actual counterparty lookup
        df['counterparty_name'] = df[ColumnName.DEAL_BSCP_ID.value].apply(
            lambda x: f"Counterparty_{x}" if pd.notna(x) else np.nan
        )
        df['counterparty_country'] = 'Unknown'
        df['counterparty_rating'] = 'NR'
        
        return df


@register_enrichment(
    EnrichmentType.XCCY_SWAP_SPLITTING.value,
    required_input=[ColumnName.PRD.value]
)
class XCcySwapSplitter(BaseEnrichment):
    """
    Cross-currency swap splitting enrichment.
    
    This enrichment splits cross-currency swaps into separate legs.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform cross-currency swap splitting on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame
        """
        df = df.copy()
        
        # Placeholder implementation - replace with actual XCCY swap logic
        df['leg_type'] = 'XCCY_SWAP'
        df['pay_currency'] = 'EUR'
        df['receive_currency'] = 'USD'
        df['leg_notional'] = df.get(ColumnName.LEG_AGR_NOTIONAL.value, 0)
        
        return df


@register_enrichment(
    EnrichmentType.COLLATERAL_SWAP.value,
    required_input=[
        ColumnName.DEAL_EXT_ID.value,
        ColumnName.BOOKING_SYSTEM.value,
        ColumnName.TRADE_TYPE.value,
        ColumnName.CPTY.value,
        ColumnName.DEAL_BSCP_ID.value,
        ColumnName.LEG_AGR_NOTIONAL.value,
        ColumnName.CCY.value,
        ColumnName.MARKET_PRICE.value,
        ColumnName.LEG_AGR_MAT_DATE.value,
        ColumnName.MAG_CONTRACT_ID.value,
        ColumnName.BOOKING_COLLATERAL_SWAP_FLAG.value,
        ColumnName.IS_SECURED.value,
        ColumnName.LEG_FX_RATE.value,
        ColumnName.LEG_START_CASH.value,
        ColumnName.ACCOUNTING_TREATMENT.value,
        ColumnName.HQLA_STATUS.value,
        ColumnName.BOND_RATING.value,
        ColumnName.BOND_ASSET_TYPE.value,
    ]
)
class CollateralSwapEnrichment(BaseEnrichment):
    """
    Collateral swap enrichment using the CollateralSwapEngine.
    
    This enrichment identifies and classifies collateral swaps.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
        # Import here to avoid circular dependencies
        from trading_analytics_framework.trade_pipeline.collateral_swap_engine import CollateralSwapEngine
        self.engine = CollateralSwapEngine()
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform collateral swap enrichment on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame
        """
        # Use the collateral swap engine to process the data
        enriched_df = self.engine.process_dataframe(df)
        return enriched_df


@register_enrichment(
    EnrichmentType.MARKET_VALUE.value,
    required_input=[
        ColumnName.PRD.value,
        ColumnName.CCY.value,
        ColumnName.BOND_CCY.value,
        ColumnName.LEG_AGR_NOTIONAL.value,
        ColumnName.MARKET_VALUE.value,
    ]
)
class MarketValueEnrichment(BaseEnrichment):
    """
    Market value enrichment for product classification and cash/security amounts.
    
    This enrichment uses the MarketValueCalculator to add comprehensive market value
    calculations including product type classification, cash/security amounts,
    EUR conversions, and trade direction analysis.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
        self.calculator = MarketValueCalculator()
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform market value enrichment on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame with all market value calculations
        """
        # Use the MarketValueCalculator to perform all calculations
        enriched_df = self.calculator.calculate_market_values(df)
        
        # Map the calculated columns to the expected output format
        # The calculator creates comprehensive market value columns
        # We can add any additional mapping or transformation here if needed
        
        return enriched_df


@register_enrichment(
    EnrichmentType.FUNDING_SOURCES_USES_LIQUIDITY.value,
    required_input=[
        ColumnName.TRADE_TYPE.value,
        ColumnName.BOOKING_SYSTEM.value,
        ColumnName.HQLA_STATUS.value,
        ColumnName.DEAL_ATTR_PROJECT_NAME.value,
        ColumnName.IS_SECURED.value,
        ColumnName.BOOK.value,
        ColumnName.CPTY.value,
        'collateral_swap_indicator',
        'collateral_swap_type',
    ]
)
class FundingSourcesUsesLiquidity(BaseEnrichment):
    """
    Funding sources and uses liquidity enrichment.
    
    This enrichment classifies trades as funding sources or uses.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform funding sources and uses classification on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame
        """
        df = df.copy()
        
        # Placeholder implementation - replace with actual funding classification logic
        df['funding_source_use'] = 'UNKNOWN'
        df['funding_source_use_type'] = 'UNKNOWN'
        
        return df





# Treasury SNU Enrichment
@register_enrichment(
    'treasury_snu',
    required_input=[
        'LegArg.IsSecured',
        'LegArg.IsCollateralSwap',
        'CollateralSwapType',
        'DealAttr.ProjectName',
        'BondLqdty.Hqlalevel',
        'Book.System',
        'Book',
        'Deal.BSCpty',
        'Deal.BBG',
        'K',
        'Leg.Type',
        'isSFT',
        'Cpty.IsInternal',
        'BondLiquidityLevel'
    ]
)
class TreasurySNUEnrichment(BaseEnrichment):
    """
    Treasury SNU classification enrichment.
    
    This enrichment classifies trades based on Treasury SNU Source and Use rules.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
        self.classifier = TreasurySNUClassifier()
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform Treasury SNU classification on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame with Source and Use classifications
        """
        enriched_df = self.classifier.classify(df)
        return enriched_df


# PnL Attribution Enrichment
@register_enrichment(
    'pnl_attribution',
    required_input=[
        'Funding/Financing Category',
        'Cpty.BusinessGroup',
        'LegArg.Maturity',
        'Book.System',
        'Leg.Type',
        'MaturityType',
        'Leg.Underl',
        'LegArg.IsCollateralSwap',
        'CollateralSwapType',
        'DealAttr.ProjectName',
        'Book',
        'Deal.BSCpty',
        'Ccy',
        'Bond.Issuer'
    ]
)
class PnLAttributionEnrichment(BaseEnrichment):
    """
    PnL Attribution classification enrichment.
    
    This enrichment classifies trades based on PnL Attribution Financing and Funding rules.
    """
    
    def __init__(self, load_date: Optional[datetime] = None):
        super().__init__(load_date)
        self.classifier = PnLAttributionClassifier()
    
    def _perform_enrichment(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Perform PnL Attribution classification on the dataframe.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Enriched DataFrame with Financing and Funding strategy classifications
        """
        enriched_df = self.classifier.classify(df)
        return enriched_df