"""
Configuration module for trading dataset pipeline.
Contains enums and constants to avoid hardcoded strings.
"""
from enum import Enum
from typing import List, Dict, Any, Optional

# Database type enumeration
class DatabaseType(Enum):
    """Database type enumeration."""
    REFDB = 'refdb'
    RISKDB = 'riskdb'
    TRADEDB = 'tradedb'

# Table name constants
class TableName(Enum):
    """Table name constants."""
    BOND_REFERENCE = 'bond_reference'
    COUNTERPARTY_REFERENCE = 'counterparty_reference'
    TRADE_DATA = 'trade_data'
    RISK_DATA = 'risk_data'
    REFERENCE_DATA = 'reference_data'
    PV_TRADE_DATA = 'pv_trade_data'
    MAGALLAN_TRADE_DATA = 'magallan_trade_data'

# Column name constants
class ColumnName(Enum):
    """Column name constants to avoid hardcoded strings. Canonical members match new values, old names kept as aliases."""
    # Canonical (new) members
    DEAL_EXT_ID = 'Deal.ExtID'
    PRD = 'PRD'
    BOOK = 'Book'
    LEG_TRADE_DATE = 'Leg.TradeDate'
    LEG_AGR_MAT_DATE = 'Leg.Agr.MatDate'
    CPTY = 'Cpty'
    DEAL_BSCP_ID = 'Deal.BSCPID'
    CCY = 'Ccy'
    LEG_AGR_NOTIONAL = 'Leg.Agr.Notional'
    MARKET_VALUE = 'Market_Value'

    BOND_ID = 'Bond.ID'
    BOND_ISSUER = 'Bond.Issuer'
    BOND_RATING = 'Bond.Rating'
    BOND_RATING_SP = 'Bond.Rating.SP'
    BOND_RATING_MOODY = 'Bond.Rating.Moody'
    BOND_RATING_FITCH = 'Bond.Rating.Fitch'
    BOND_RATING_DBRS = 'Bond.Rating.DBRS'
    BOND_ASSET_TYPE = 'Bond.AssetType'
    BOND_COLLATERAL_TYPE = 'Bond.CollateralType'
    COUPON_RATE = 'coupon_rate'
    
    # Issuer rating columns
    ISSUER_RATING = 'Issuer.Rating'
    ISSUER_RATING_SP = 'Issuer.Rating.SP'
    ISSUER_RATING_MOODY = 'Issuer.Rating.Moody'
    ISSUER_RATING_FITCH = 'Issuer.Rating.Fitch'
    ISSUER_RATING_DBRS = 'Issuer.Rating.DBRS'
    ISSUER_COUNTRY = 'Issuer.Country'
    IS_SUBORDINATED = 'is_subordinated'

    COUNTRY = 'country'

    LEG_PAY_CCY = 'Leg.PayCcy'
    LEG_REC_CCY = 'Leg.RecCcy'
    LEG_TYPE = 'Leg.Type'

    COLLATERAL_TYPE = 'collateral_type'
    IS_SECURED = 'is_secured'
    HQLA_STATUS = 'hqla_status'

    BOOK_SYSTEM = 'Book.System'

    DATA_SOURCE = 'data_source'
    PRICE_SOURCE_ID = 'price_source_id'

    MARKET_PRICE = 'market_price'
    LEG_FX_RATE = 'Leg.FXRate'

    LEG_PAY_REC = 'Leg.PayRec'
    LEG_START_CASH = 'Leg.StartCash'
    BOND_CCY = 'Bond.Ccy'
    POOL_FACTOR = 'PoolFactor'
    MKT_PRICE = 'Market.Price'
    DEAL_ATTR_PROJECT_NAME = 'Deal.Attr.ProjectName'
    MAG_CONTRACT_ID = 'MagContractID'
    ACCOUNTING_TREATMENT = 'accounting_treatment'
    BOOKING_COLLATERAL_SWAP_FLAG = 'booking_collateral_swap_flag'

    # Aliases (old names preserved)
    TRADE_ID = DEAL_EXT_ID
    PRODUCT_TYPE = PRD
    TRADE_DATE = LEG_TRADE_DATE
    MATURITY_DATE = LEG_AGR_MAT_DATE
    COUNTERPARTY = CPTY
    COUNTERPARTY_ID = DEAL_BSCP_ID
    CURRENCY = CCY
    NOTIONAL = LEG_AGR_NOTIONAL

    ISSUER = BOND_ISSUER
    RATING = BOND_RATING
    COUNTERPARTY_NAME = CPTY
    PAY_CURRENCY = LEG_PAY_CCY
    RECEIVE_CURRENCY = LEG_REC_CCY
    SYSTEM = BOOK_SYSTEM
    BOOKING_SYSTEM = BOOK_SYSTEM
    TRADE_TYPE = LEG_TYPE
    FX_RATE = LEG_FX_RATE
    BOND_CURRENCY = BOND_CCY
    DEAL_PROJECT_NAME = DEAL_ATTR_PROJECT_NAME
    CONTRACT_ID = MAG_CONTRACT_ID

# Dataset type enumeration
class DatasetType(Enum):
    """Dataset type enumeration."""
    BOND_ISSUER_RATINGS = 'bond_issuer_ratings'
    COUNTERPARTY_DATA = 'counterparty_data'
    TRADE_DATA = 'trade_data'
    RISK_DATA = 'risk_data'
    REFERENCE_DATA = 'reference_data'
    PV_TRADE_DATA = 'pv_trade_data'
    MAGALLAN_TRADE_DATA = 'magallan_trade_data'

# Filter type enumeration
class FilterType(Enum):
    """Filter type enumeration."""
    REMOVE_WASH_BOOKS = 'remove_wash_books'
    REMOVE_MATURING_TRADES = 'remove_maturing_trades'
    REMOVE_INTERNAL_INTERDESK = 'remove_internal_interdesk'
    REMOVE_NON_CASH_RELEVANT = 'remove_non_cash_relevant'
    REMOVE_PGI_XMTS_NOTES = 'remove_pgi_xmts_notes'

# Enrichment type enumeration
class EnrichmentType(Enum):
    """Enrichment type enumeration."""
    BOND_ENRICHMENTS = 'bond_enrichments'
    TENOR_BUCKETING = 'tenor_bucketing'
    COUNTERPARTY_MAPPING = 'counterparty_mapping'
    XCCY_SWAP_SPLITTING = 'xccy_swap_splitting'
    BOND_RATINGS = 'bond_ratings'
    BOND_ISSUER = 'bond_issuer'
    COLLATERAL_SWAP = 'collateral_swap'
    MARKET_VALUE = 'market_value'
    FUNDING_SOURCES_USES_LIQUIDITY = 'funding_sources_uses_liquidity'
    BOND_ISSUER_RATINGS = 'bond_issuer_ratings'
    COUNTERPARTY = 'counterparty'

# Data source enumeration
class DataSource(Enum):
    """Data source enumeration."""
    RISK_DB = 'risk_db'
    MAGALLAN = 'magallan'

# Product type enumeration
class ProductType(Enum):
    """Product type enumeration."""
    BOND = 'BOND'
    SWAP = 'SWAP'
    XCCY_SWAP = 'XCCY_SWAP'
    CASH_DEPOSIT = 'CASH_DEPOSIT'
    REPO = 'REPO'
    IRS = 'IRS'
    CDS = 'CDS'
    OIS = 'OIS'
    COLLATERAL_SWAP = 'COLLATERAL_SWAP'
    CASH_LOAN = 'CASH_LOAN'
    REVERSE_REPO = 'REVERSE_REPO'
    INTEREST_RATE_SWAP = 'INTEREST_RATE_SWAP'
    CREDIT_DEFAULT_SWAP = 'CREDIT_DEFAULT_SWAP'
    OVERNIGHT_INDEX_SWAP = 'OVERNIGHT_INDEX_SWAP'

# Leg type enumeration
class LegType(Enum):
    """Leg type enumeration for XCcy swaps."""
    PAY = 'pay'
    RECEIVE = 'receive'
    BUY = 'buy'
    SELL = 'sell'

# Booking system enumeration
class BookingSystem(Enum):
    """Booking system enumeration."""
    MAG = 'MAG'      # Magallan system
    K_E = 'K-E'      # K-E system
    B_E = 'B-E'      # B-E system
    K_F = 'K.F'      # K.F system

# Trade type enumeration
class MagTradeType(Enum):
    """Magallan trade type enumeration - merged with CollateralSwapEngine TradeType."""
    BB = 'BB'        # Bond Borrow
    BL = 'BL'        # Bond Lend
    REP = 'REP'      # Repo
    REV = 'REV'      # Reverse Repo
    TP = 'TP'        # Tri-party repo
    TR = 'TR'        # Tri-party reverse repo
    TPR = 'TPR'      # Tri-party repo
    TRV = 'TRV'      # Tri-party reverse repo
    TPB = 'TPB'      # Tri-party repo
    TPL = 'TPL'      # Tri-party repo

# Collateral Swap Engine Enums (merged from collateral_swap_engine.py)
class SwapType(Enum):
    """Collateral swap type classification."""
    UPGRADE = 'UPGRADE'
    DOWNGRADE = 'DOWNGRADE'
    NEUTRAL = 'NEUTRAL'

class TransactionType(Enum):
    """Transaction type classification."""
    FINANCING = 'FINANCING'
    FUNDING = 'FUNDING'
    COLLATERAL_SWAP = 'COLLATERAL_SWAP'
    UNSECURED_BOND = 'UNSECURED_BOND'

class HqlaStatus(Enum):
    """HQLA status enumeration."""
    LEVEL_1 = 1
    LEVEL_2A = 2
    LEVEL_2B = 3
    NON_HQLA = 4

class BondAssetType(Enum):
    """Bond asset type enumeration."""
    GOVT = 1
    CORP_SENIOR = 2
    CORP_JUNIOR = 3
    ABS_CLO = 4

class PrdsCode(Enum):
    """PRDS code enumeration."""
    REPO = 'REPO'
    BOND = 'BOND'
    SECURITIES_LENDING = 'SL'

# Collateral Swap Engine Output Columns
class CollateralSwapOutputColumns(Enum):
    """Output column names for collateral swap engine."""
    COLLATERAL_SWAP_INDICATOR = 'collateral_swap_indicator'
    TRADE_GROUP_SYNTHETIC_KEY = 'trade_group_synthetic_key'
    COLLATERAL_SWAP_ID = 'collateral_swap_id'
    COLLATERAL_SWAP_TYPE = 'collateral_swap_type'
    TRANSACTION_TYPE = 'transaction_type'
    COLLATERAL_SWAP_CONSTRUCTION = 'collateral_swap_construction'
    
    # Intermediate calculation columns
    TRADE_DIRECTION = 'trade_direction'
    DIRECTIONAL_MARKET_VALUE = 'directional_market_value'
    SYNTHETIC_KEY_DESK = 'synthetic_key_desk'
    SYNTHETIC_KEY_CONTRACT = 'synthetic_key_contract'
    SYNTHETIC_KEY_SECURED = 'synthetic_key_secured'
    GROUP_SUM = 'group_sum'
    GROUP_SUM_CONTRACT = 'group_sum_contract'
    HIERARCHY_SCORE = 'hierarchy_score'
    COLLATERAL_DIRECTION = 'collateral_direction'
    
    # Debug columns
    DEBUG_APPROACH_USED = 'debug_approach_used'
    DEBUG_RULE_APPLIED = 'debug_rule_applied'
    DEBUG_MARKET_VALUE = 'debug_market_value'
    DEBUG_GROUP_SUM = 'debug_group_sum'
    DEBUG_HIERARCHY_SCORE = 'debug_hierarchy_score' 

# Filter constants
NON_RELEVANT_PRDS = ['NON_RELEVANT_1', 'NON_RELEVANT_2', 'NON_RELEVANT_3']
WASH_BOOKS = ['WASH_BOOK_1', 'WASH_BOOK_2', 'WASH_BOOK_3']
INTERNAL_INTERDESK_TRADES = ['INTERNAL_1', 'INTERNAL_2', 'INTERNAL_3']
NON_CASH_RELEVANT_PRDS = ['NON_CASH_1', 'NON_CASH_2', 'NON_CASH_3']
PGI_XMTS_NOTES = ['PGI_NOTE_1', 'PGI_NOTE_2', 'XMTS_NOTE_1'] 