import pandas as pd
import numpy as np
from typing import Dict, Optional


class BondScoringEngine:
    """
    A simplified vectorized bond credit scoring engine with fixed column names
    and configurable worst-of vs average rating approaches.
    """
    
    # Default rating to score mapping based on the provided table structure
    # This will be replaced with API call data
    DEFAULT_RATING_MAPPING = {
        # Investment Grade - High Quality
        'AAA': 1, 'Aaa': 1,
        'AA+': 2, 'Aa1': 2, 'AA (high)': 2,
        'AA': 3, 'Aa2': 3,
        'AA-': 4, 'Aa3': 4, 'AA (low)': 4,
        'A+': 5, 'A1': 5, 'A (high)': 5,
        'A': 6, 'A2': 6,
        'A-': 7, 'A3': 7, 'A (low)': 7,
        
        # Investment Grade - Medium Quality
        'BBB+': 8, 'Baa1': 8, 'BBB (high)': 8,
        'BBB': 9, 'Baa2': 9,
        'BBB-': 10, 'Baa3': 10, 'BBB (low)': 10,
        
        # Speculative/Junk Grade
        'BB+': 11, 'Ba1': 11, 'BB (high)': 11,
        'BB': 12, 'Ba2': 12,
        'BB-': 13, 'Ba3': 13, 'BB (low)': 13,
        'B+': 14, 'B1': 14, 'B (high)': 14,
        'B': 15, 'B2': 15,
        'B-': 16, 'B3': 16, 'B (low)': 16,
        
        # Highly Speculative/Default Imminent
        'CCC+': 17, 'Caa1': 17, 'CCC (high)': 17,
        'CCC': 18, 'Caa2': 18,
        'CCC-': 19, 'Caa3': 19, 'CCC (low)': 19,
        'CC': 20, 'Ca': 20,
        
        # Default
        'C': 21, 'D': 21, 'C / NR / D': 21
    }
    
    # Asset classification mapping based on Bond.CollatType hierarchy (1-6 scale)
    DEFAULT_CLASSIFICATION_MAPPING = {
        'GOVT': 1,         # Government bonds - lowest risk
        'CORP': 2,         # Corporate bonds
        'CLO/ABS': 3,      # CLO/ABS - higher risk
        'TRIPARTY': 4,     # Triparty
        'BASKET': 5,       # Basket - highest risk
        'Other': 6         # Fallback for unrecognized types
    }
    
    # Fixed column names
    BOND_RATING_COLUMNS = ['Bond.RtyDB', 'Bond.RtySP', 'Bond.RtyMDY', 'Bond.RtyFITCH']
    ISSUER_RATING_COLUMNS = ['Bond.Issuer.RtyDB', 'Bond.Issuer.RtySP', 'Bond.Issuer.RtyMDY', 'Bond.Issuer.RtyFITCH']
    
    def __init__(self, trade_df: pd.DataFrame):
        """
        Initialize the BondScoringEngine with trade dataframe.
        
        Parameters:
        -----------
        trade_df : pd.DataFrame
            DataFrame containing bond information including ratings.
            The rating mappings will be automatically loaded from API.
        """
        # Load rating mappings from API
        self.rating_to_score = self._load_rating_mappings_from_api()
        
        # Use built-in classification mapping
        self.classification_to_score = self.DEFAULT_CLASSIFICATION_MAPPING.copy()
        
        # Find max rating score for fallback
        self.max_rating_score = max(self.rating_to_score.values())
        
        # Store the trade dataframe for reference
        self.trade_df = trade_df
    
    def _load_rating_mappings_from_api(self) -> Dict[str, float]:
        """
        Load rating mappings from API call.
        
        This method will be replaced with your actual API call.
        Currently returns dummy data based on the provided table structure.
        
        Returns:
        --------
        Dict[str, float]
            Rating to score mapping dictionary
        """
        # TODO: Replace this with your actual API call
        # Example API response structure based on the provided table:
        api_response = {
            "rating_mappings": [
                {
                    "RtySP": "AAA", "RtyFITCH": "AAA", "RtyMDY": "Aaa", "RtyDB": "AAA",
                    "Score": 1, "RtyAvg": "AAA"
                },
                {
                    "RtySP": "AA+", "RtyFITCH": "AA+", "RtyMDY": "Aa1", "RtyDB": "AA (high)",
                    "Score": 2, "RtyAvg": "AA+"
                },
                {
                    "RtySP": "AA", "RtyFITCH": "AA", "RtyMDY": "Aa2", "RtyDB": "AA",
                    "Score": 3, "RtyAvg": "AA"
                },
                {
                    "RtySP": "AA-", "RtyFITCH": "AA-", "RtyMDY": "Aa3", "RtyDB": "AA (low)",
                    "Score": 4, "RtyAvg": "AA-"
                },
                {
                    "RtySP": "A+", "RtyFITCH": "A+", "RtyMDY": "A1", "RtyDB": "A (high)",
                    "Score": 5, "RtyAvg": "A+"
                },
                {
                    "RtySP": "A", "RtyFITCH": "A", "RtyMDY": "A2", "RtyDB": "A",
                    "Score": 6, "RtyAvg": "A"
                },
                {
                    "RtySP": "A-", "RtyFITCH": "A-", "RtyMDY": "A3", "RtyDB": "A (low)",
                    "Score": 7, "RtyAvg": "A-"
                },
                {
                    "RtySP": "BBB+", "RtyFITCH": "BBB+", "RtyMDY": "Baa1", "RtyDB": "BBB (high)",
                    "Score": 8, "RtyAvg": "BBB+"
                },
                {
                    "RtySP": "BBB", "RtyFITCH": "BBB", "RtyMDY": "Baa2", "RtyDB": "BBB",
                    "Score": 9, "RtyAvg": "BBB"
                },
                {
                    "RtySP": "BBB-", "RtyFITCH": "BBB-", "RtyMDY": "Baa3", "RtyDB": "BBB (low)",
                    "Score": 10, "RtyAvg": "BBB-"
                },
                {
                    "RtySP": "BB+", "RtyFITCH": "BB+", "RtyMDY": "Ba1", "RtyDB": "BB (high)",
                    "Score": 11, "RtyAvg": "BB+"
                },
                {
                    "RtySP": "BB", "RtyFITCH": "BB", "RtyMDY": "Ba2", "RtyDB": "BB",
                    "Score": 12, "RtyAvg": "BB"
                },
                {
                    "RtySP": "BB-", "RtyFITCH": "BB-", "RtyMDY": "Ba3", "RtyDB": "BB (low)",
                    "Score": 13, "RtyAvg": "BB-"
                },
                {
                    "RtySP": "B+", "RtyFITCH": "B+", "RtyMDY": "B1", "RtyDB": "B (high)",
                    "Score": 14, "RtyAvg": "B+"
                },
                {
                    "RtySP": "B", "RtyFITCH": "B", "RtyMDY": "B2", "RtyDB": "B",
                    "Score": 15, "RtyAvg": "B"
                },
                {
                    "RtySP": "B-", "RtyFITCH": "B-", "RtyMDY": "B3", "RtyDB": "B (low)",
                    "Score": 16, "RtyAvg": "B-"
                },
                {
                    "RtySP": "CCC+", "RtyFITCH": "CCC+", "RtyMDY": "Caa1", "RtyDB": "CCC (high)",
                    "Score": 17, "RtyAvg": "CCC+"
                },
                {
                    "RtySP": "CCC", "RtyFITCH": "CCC", "RtyMDY": "Caa2", "RtyDB": "CCC",
                    "Score": 18, "RtyAvg": "CCC"
                },
                {
                    "RtySP": "CCC-", "RtyFITCH": "CCC-", "RtyMDY": "Caa3", "RtyDB": "CCC (low)",
                    "Score": 19, "RtyAvg": "CCC-"
                },
                {
                    "RtySP": "CC", "RtyFITCH": "CC", "RtyMDY": "Ca", "RtyDB": "CC",
                    "Score": 20, "RtyAvg": "CC"
                },
                {
                    "RtySP": "C/D", "RtyFITCH": "C/D", "RtyMDY": "C / NR / D", "RtyDB": "C/D",
                    "Score": 21, "RtyAvg": "C/D"
                }
            ]
        }
        
        # Convert API response to rating mapping dictionary
        rating_mapping = {}
        for mapping in api_response["rating_mappings"]:
            # Map all agency ratings to the same score
            rating_mapping[mapping["RtySP"]] = mapping["Score"]
            rating_mapping[mapping["RtyFITCH"]] = mapping["Score"]
            rating_mapping[mapping["RtyMDY"]] = mapping["Score"]
            rating_mapping[mapping["RtyDB"]] = mapping["Score"]
            rating_mapping[mapping["RtyAvg"]] = mapping["Score"]
        
        return rating_mapping
    
    def _map_ratings_to_scores(self, df: pd.DataFrame, columns: list) -> pd.DataFrame:
        """Convert ratings to numeric scores."""
        scores_df = pd.DataFrame(index=df.index)
        
        for col in columns:
            if col in df.columns:
                scores_df[f'{col}_score'] = df[col].map(self.rating_to_score)
        
        return scores_df
    
    def _compute_worst_rating(self, scores_df: pd.DataFrame) -> pd.Series:
        """
        Compute worst-of rating using Excel LARGE logic with fallback to max rating.
        If no ratings available, return max rating score.
        """
        score_columns = [col for col in scores_df.columns if col.endswith('_score')]
        
        if not score_columns:
            return pd.Series(self.max_rating_score, index=scores_df.index)
        
        # Create scores matrix and sort in descending order (largest first)
        scores_matrix = scores_df[score_columns].values
        sorted_scores = np.sort(scores_matrix, axis=1)[:, ::-1]
        
        # Initialize with max rating score
        rating_scores = np.full(len(scores_df), self.max_rating_score)
        
        # Apply Excel LARGE logic
        for i in range(min(4, sorted_scores.shape[1])):
            mask = np.isnan(rating_scores) == False  # All rows initially
            valid_score_mask = ~np.isnan(sorted_scores[:, i])
            
            if i < 3:  # For positions 0, 1, 2: check if <= 10 (investment grade threshold)
                threshold_mask = valid_score_mask & (sorted_scores[:, i] <= 10.0)
                # Only update if we haven't found a valid score yet
                no_score_yet = rating_scores == self.max_rating_score
                update_mask = threshold_mask & no_score_yet
                rating_scores[update_mask] = sorted_scores[update_mask, i]
            else:  # For position 3: use regardless of threshold
                no_score_yet = rating_scores == self.max_rating_score
                update_mask = valid_score_mask & no_score_yet
                rating_scores[update_mask] = sorted_scores[update_mask, i]
        
        return pd.Series(rating_scores, index=scores_df.index)
    
    def _compute_second_worst_issuer_rating(self, issuer_scores_df: pd.DataFrame) -> pd.Series:
        """Compute second worst issuer rating."""
        score_columns = [col for col in issuer_scores_df.columns if col.endswith('_score')]
        
        if not score_columns:
            return pd.Series(self.max_rating_score, index=issuer_scores_df.index)
        
        # Get all valid scores per row
        scores_matrix = issuer_scores_df[score_columns].values
        
        # Sort in descending order and get second largest (index 1)
        sorted_scores = np.sort(scores_matrix, axis=1)[:, ::-1]
        
        # Initialize with max rating
        second_worst_scores = np.full(len(issuer_scores_df), self.max_rating_score)
        
        # Get second worst where available
        for i in range(len(sorted_scores)):
            valid_scores = sorted_scores[i][~np.isnan(sorted_scores[i])]
            if len(valid_scores) >= 2:
                second_worst_scores[i] = valid_scores[1]  # Second largest
            elif len(valid_scores) == 1:
                second_worst_scores[i] = valid_scores[0]  # Only one rating available
        
        return pd.Series(second_worst_scores, index=issuer_scores_df.index)
    
    def _compute_average_rating(self, scores_df: pd.DataFrame) -> pd.Series:
        """Compute average of available ratings, fallback to max if none available."""
        score_columns = [col for col in scores_df.columns if col.endswith('_score')]
        
        if not score_columns:
            return pd.Series(self.max_rating_score, index=scores_df.index)
        
        # Calculate mean of non-null values
        avg_scores = scores_df[score_columns].mean(axis=1, skipna=True)
        
        # Fill NaN (no ratings) with max rating score
        avg_scores = avg_scores.fillna(self.max_rating_score)
        
        return avg_scores
    
    def _classify_assets(self, df: pd.DataFrame) -> pd.Series:
        """
        Classify assets based on Bond.CollatType field.
        Hierarchy: GOVT > CORP > CLO/ABS > TRIPARTY > BASKET
        """
        classifications = pd.Series('Other', index=df.index)
        
        if 'Bond.CollatType' in df.columns:
            # Convert to uppercase for consistent matching
            collat_type = df['Bond.CollatType'].astype(str).str.upper()
            
            # Map based on hierarchy (GOVT > CORP > CLO/ABS > TRIPARTY > BASKET)
            classifications.loc[collat_type == 'GOVT'] = 'GOVT'
            classifications.loc[collat_type == 'CORP'] = 'CORP'
            
            # Handle CLO/ABS variations
            clo_abs_mask = (collat_type.str.contains('CLO', na=False) | 
                           collat_type.str.contains('ABS', na=False) |
                           collat_type == 'CLO/ABS')
            classifications.loc[clo_abs_mask] = 'CLO/ABS'
            
            classifications.loc[collat_type == 'TRIPARTY'] = 'TRIPARTY'
            classifications.loc[collat_type == 'BASKET'] = 'BASKET'
        
        return classifications
    
    def compute_scores(self, 
                      use_average: bool = False,
                      use_fallback_logic: bool = True) -> pd.DataFrame:
        """
        Compute bond scores using the trade dataframe provided during initialization.
        
        Parameters:
        -----------
        use_average : bool
            If True, use RtgAvg approach. If False, use worst-of approach.
        use_fallback_logic : bool
            If True, apply issuer fallback logic for missing bond ratings.
            
        Returns:
        --------
        pd.DataFrame
            DataFrame with computed scores
        """
        df = self.trade_df.copy()
        result_df = df.copy()
        
        # Step 1: Map bond ratings to scores
        bond_scores = self._map_ratings_to_scores(df, self.BOND_RATING_COLUMNS)
        
        # Step 2: Compute bond rating score (worst-of or average)
        if use_average:
            # Use RtgAvg if available, otherwise compute average
            if 'RtgAvg' in df.columns:
                bond_rating_score = df['RtgAvg'].map(self.rating_to_score).fillna(self.max_rating_score)
            else:
                bond_rating_score = self._compute_average_rating(bond_scores)
        else:
            bond_rating_score = self._compute_worst_rating(bond_scores)
        
        # Step 3: Apply fallback logic if enabled
        final_rating_score = bond_rating_score.copy()
        
        if use_fallback_logic:
            # Check for missing bond ratings
            missing_bond_ratings = bond_rating_score == self.max_rating_score
            
            if missing_bond_ratings.any():
                # Map issuer ratings to scores
                issuer_scores = self._map_ratings_to_scores(df, self.ISSUER_RATING_COLUMNS)
                
                # Compute second worst issuer rating
                second_worst_issuer = self._compute_second_worst_issuer_rating(issuer_scores)
                
                # Apply fallback logic
                if 'subordinated' in df.columns:
                    # If subordinated, keep max rating; if not subordinated, use issuer second worst
                    fallback_mask = missing_bond_ratings & ~df['subordinated']
                    final_rating_score.loc[fallback_mask] = second_worst_issuer.loc[fallback_mask]
                else:
                    # No subordination info, use issuer rating for all missing
                    final_rating_score.loc[missing_bond_ratings] = second_worst_issuer.loc[missing_bond_ratings]
        
        # Step 4: Asset classification
        asset_classifications = self._classify_assets(df)
        asset_scores = asset_classifications.map(self.classification_to_score)
        
        # Step 5: Final score calculation
        final_scores = final_rating_score + 100 * asset_scores
        
        # Add results
        result_df['rating_score'] = final_rating_score
        result_df['asset_class'] = asset_classifications
        result_df['asset_score'] = asset_scores
        result_df['final_score'] = final_scores
        
        return result_df
    

# Example usage
if __name__ == "__main__":
    # Sample data with your column names
    sample_data = pd.DataFrame({
        'Bond.RtyDB': ['A+', None, None, 'BB-', None],
        'Bond.RtySP': ['A-', 'BBB+', 'B+', None, 'AA'],
        'Bond.RtyMDY': ['A', 'BBB', None, 'BB+', 'AAA'],
        'Bond.RtyFITCH': [None, 'BBB', 'B', 'BB', 'AA+'],
        'Bond.Issuer.RtyDB': ['AA', 'A+', 'BBB', 'BB', 'AAA'],
        'Bond.Issuer.RtySP': ['AA-', 'A', 'BBB-', 'BB+', 'AA'],
        'Bond.Issuer.RtyMDY': ['AA+', 'A-', 'BBB+', 'BB-', 'AAA'],
        'Bond.Issuer.RtyFITCH': ['AA', 'A', 'BBB', 'BB', 'AA+'],
        'RtgAvg': ['A', 'BBB+', 'B+', 'BB', 'AA'],  # Pre-calculated average ratings
        'subordinated': [False, False, True, False, False],
        'Bond.CollatType': ['GOVT', 'CORP', 'CLO', 'TRIPARTY', 'BASKET']
    })
    
    print("=== BondScoringEngine with API Rating Mapping ===")
    engine = BondScoringEngine(sample_data)
    
    print("Engine Information:")
    print(f"Max rating score: {engine.max_rating_score}")
    print(f"Rating mapping size: {len(engine.rating_to_score)}")
    print(f"Trade dataframe shape: {engine.trade_df.shape}")
    print()
    
    print("Worst-of Approach:")
    result_worst = engine.compute_scores(use_average=False)
    print(result_worst[['Bond.RtyMDY', 'Bond.RtySP', 'Bond.CollatType', 'asset_class', 'rating_score', 'final_score']].round(2))
    
    print("\nAverage Approach (using RtgAvg):")
    result_avg = engine.compute_scores(use_average=True)
    print(result_avg[['RtgAvg', 'Bond.CollatType', 'asset_class', 'rating_score', 'final_score']].round(2))
    
    print("\n=== Sample Rating Mappings ===")
    sample_ratings = ['AAA', 'AA+', 'A', 'BBB', 'BB', 'B', 'CCC', 'CC', 'C/D']
    for rating in sample_ratings:
        if rating in engine.rating_to_score:
            print(f"{rating}: {engine.rating_to_score[rating]}")
