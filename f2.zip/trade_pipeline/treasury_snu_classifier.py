"""
Treasury SNU Classifier for trade classification.

This module contains the TreasurySNUClassifier class that provides
classification logic for Treasury SNU Source and Use categories.
"""

import pandas as pd
import numpy as np
from typing import List, Tuple


class TreasurySNUClassifier:
    """
    Treasury SNU Asset Classification based on funding source and usage rules.
    Uses numpy.select for efficient classification.
    """
    
    # Column name definitions - easy to change if schema changes
    COL_LEG_ARG_IS_SECURED = 'LegArg.IsSecured'
    COL_LEG_ARG_IS_COLLATERAL_SWAP = 'LegArg.IsCollateralSwap'
    COL_COLLATERAL_SWAP_TYPE = 'CollateralSwapType'
    COL_DEAL_ATTR_PROJECT_NAME = 'DealAttr.ProjectName'
    COL_BOND_LQDTY_HQLA_LEVEL = 'BondLqdty.Hqlalevel'
    COL_BOOK_SYSTEM = 'Book.System'
    COL_BOOK = 'Book'
    COL_DEAL_BS_CPTY = 'Deal.BSCpty'
    COL_LEG_TYPE = 'Leg.Type'
    COL_IS_SFT = 'isSFT'
    COL_CPTY_IS_INTERNAL = 'Cpty.IsInternal'
    COL_BOND_LIQUIDITY_LEVEL = 'BondLiquidityLevel'
    COL_DEAL_BBG = 'Deal.BBG'
    COL_K = 'K'
    
    # Classification output columns with prefixed names
    COL_SOURCE_CLASSIFICATION = 'TreasurySNU_Source_Classification'
    COL_USE_CLASSIFICATION = 'TreasurySNU_Use_Classification'
    COL_FUNDING_SOURCE_USE = 'TreasurySNU_Funding_Source_Use'
    COL_COMBINED_CLASSIFICATION = 'TreasurySNU_Combined_Classification'
    
    # Constant values
    BOOK_SYSTEM_KE = 'K-E'
    BOOK_CMMM_CFSF = 'CMMM-CFSF'
    BOOK_CMMM_CFSFA = 'CMMM-CFSFA'
    DEAL_BS_CPTY_LO = 'LO-0751464'
    LEG_TYPES_REVERSE = ['REV', 'TRV']
    COLLATERAL_SWAP_UPGRADE = 'Upgrade'
    BOND_HQLA_LEVELS = [1, '2A', '2B']
    PROJECT_PREFIX_PGI = 'PGI'
    PROJECT_PREFIX_XMT = 'Xmt'
    
    def __init__(self):
        pass
    
    def _get_source_conditions_and_choices(self, df: pd.DataFrame) -> Tuple[List, List]:
        """Get conditions and choices for Source classification using numpy arrays."""
        conditions = [
            df[self.COL_LEG_ARG_IS_SECURED] == False,
            
            (df[self.COL_LEG_ARG_IS_COLLATERAL_SWAP] == True) & 
            (df[self.COL_COLLATERAL_SWAP_TYPE] == self.COLLATERAL_SWAP_UPGRADE),
            
            (df[self.COL_LEG_ARG_IS_COLLATERAL_SWAP] == True) & 
            (df[self.COL_COLLATERAL_SWAP_TYPE] == self.COLLATERAL_SWAP_UPGRADE) &
            (df[self.COL_DEAL_ATTR_PROJECT_NAME].str.startswith(self.PROJECT_PREFIX_PGI, na=False) |
             df[self.COL_DEAL_ATTR_PROJECT_NAME].str.startswith(self.PROJECT_PREFIX_XMT, na=False)),
            
            (df[self.COL_LEG_ARG_IS_COLLATERAL_SWAP] == True) & 
            (df[self.COL_COLLATERAL_SWAP_TYPE] == self.COLLATERAL_SWAP_UPGRADE) &
            ~(df[self.COL_DEAL_ATTR_PROJECT_NAME].str.startswith(self.PROJECT_PREFIX_PGI, na=False) |
              df[self.COL_DEAL_ATTR_PROJECT_NAME].str.startswith(self.PROJECT_PREFIX_XMT, na=False)) &
            ~df[self.COL_BOND_LQDTY_HQLA_LEVEL].isin([1, 2, 'A', '2B']),
            
            (df[self.COL_LEG_ARG_IS_COLLATERAL_SWAP] == False) &
            (df[self.COL_DEAL_ATTR_PROJECT_NAME].str.startswith(self.PROJECT_PREFIX_XMT, na=False)) &
            ((df[self.COL_DEAL_BBG] + df[self.COL_K]) != 0),
            
            (df[self.COL_BOOK_SYSTEM] == self.BOOK_SYSTEM_KE) &
            (df[self.COL_BOOK] == self.BOOK_CMMM_CFSF) &
            (df[self.COL_DEAL_BS_CPTY] == self.DEAL_BS_CPTY_LO),
            
            (df[self.COL_BOOK_SYSTEM] == self.BOOK_SYSTEM_KE) &
            (df[self.COL_BOOK] == self.BOOK_CMMM_CFSFA) &
            (df[self.COL_DEAL_BS_CPTY] == self.DEAL_BS_CPTY_LO),
            
            (df[self.COL_BOOK] == self.BOOK_CMMM_CFSF) &
            (df[self.COL_DEAL_BS_CPTY] == self.DEAL_BS_CPTY_LO)
        ]
        
        choices = [
            'Unsecured Bond Borrows',
            'Coll. Swap, upgrades (PGI & other non-HQLA)',
            'Using PGI/X-Mkts',
            'Using other non-HQLA',
            'Secured X-Mkt Notes',
            'ABCP (using PGI pledge)',
            'ABCP (using Rev Repo asset pledge)',
            'Secured deposit (using securities pledge)'
        ]
        
        return conditions, choices
    
    def _get_use_conditions_and_choices(self, df: pd.DataFrame) -> Tuple[List, List]:
        """Get conditions and choices for Use classification using numpy arrays."""
        conditions = [
            df[self.COL_LEG_TYPE].isin(self.LEG_TYPES_REVERSE),
            
            df[self.COL_LEG_TYPE].isin(self.LEG_TYPES_REVERSE) &
            (df[self.COL_IS_SFT] == True) &
            (df[self.COL_CPTY_IS_INTERNAL] == True) &
            df[self.COL_BOND_LIQUIDITY_LEVEL].isin(self.BOND_HQLA_LEVELS) &
            (df[self.COL_LEG_ARG_IS_COLLATERAL_SWAP] == False),
            
            df[self.COL_LEG_TYPE].isin(self.LEG_TYPES_REVERSE) &
            (df[self.COL_IS_SFT] == True) &
            (df[self.COL_CPTY_IS_INTERNAL] == True) &
            ~df[self.COL_BOND_LIQUIDITY_LEVEL].isin(self.BOND_HQLA_LEVELS) &
            (df[self.COL_LEG_ARG_IS_COLLATERAL_SWAP] == False)
        ]
        
        choices = [
            'Reverse Repo financing',
            'HQLA',
            'Non-HQLA'
        ]
        
        return conditions, choices
    
    def classify(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Classify trades based on Treasury SNU rules for both Source and Use.
        
        Parameters:
        df: DataFrame with trade data
        
        Returns:
        DataFrame with additional columns:
        - 'TreasurySNU_Source_Classification': Source classification
        - 'TreasurySNU_Use_Classification': Use classification
        - 'TreasurySNU_Funding_Source_Use': Whether it's Source or Use
        - 'TreasurySNU_Combined_Classification': Combined classification string
        """
        df_copy = df.copy()
        
        try:
            # Source classification
            source_conditions, source_choices = self._get_source_conditions_and_choices(df_copy)
            df_copy[self.COL_SOURCE_CLASSIFICATION] = np.select(source_conditions, source_choices, default='Other')
            
            # Use classification
            use_conditions, use_choices = self._get_use_conditions_and_choices(df_copy)
            df_copy[self.COL_USE_CLASSIFICATION] = np.select(use_conditions, use_choices, default='Other')
            
            # Determine if each row is Source or Use based on conditions
            # Source conditions: when any source condition is True
            source_condition = np.any(source_conditions, axis=0)
            # Use conditions: when any use condition is True
            use_condition = np.any(use_conditions, axis=0)
            
            # Create Funding Source/Use column
            df_copy[self.COL_FUNDING_SOURCE_USE] = np.where(
                source_condition, 'Source',
                np.where(use_condition, 'Use', 'Other')
            )
            
            # Create combined classification column - show the actual classification for the row
            df_copy[self.COL_COMBINED_CLASSIFICATION] = np.where(
                source_condition, df_copy[self.COL_SOURCE_CLASSIFICATION],
                np.where(use_condition, df_copy[self.COL_USE_CLASSIFICATION], 'Other')
            )
            
        except KeyError as e:
            print(f"Missing required column: {e}")
            df_copy[self.COL_SOURCE_CLASSIFICATION] = 'Error - Missing Column'
            df_copy[self.COL_USE_CLASSIFICATION] = 'Error - Missing Column'
            df_copy[self.COL_FUNDING_SOURCE_USE] = 'Error - Missing Column'
            df_copy[self.COL_COMBINED_CLASSIFICATION] = 'Error - Missing Column'
        except Exception as e:
            print(f"Classification error: {e}")
            df_copy[self.COL_SOURCE_CLASSIFICATION] = 'Error'
            df_copy[self.COL_USE_CLASSIFICATION] = 'Error'
            df_copy[self.COL_FUNDING_SOURCE_USE] = 'Error'
            df_copy[self.COL_COMBINED_CLASSIFICATION] = 'Error'
            
        return df_copy
