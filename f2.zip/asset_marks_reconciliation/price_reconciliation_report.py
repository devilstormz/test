"""
Price Reconciliation Report

This module provides the PriceReconciliationReport class which creates comprehensive
price reconciliation reports from multiple price sources for bond instruments.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple
import json
import pickle
from datetime import datetime
import xlsxwriter

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from reporting_framework.base_report import BaseReport


class PriceReconciliationReport(BaseReport):
    """
    Report class for Price Reconciliation across multiple price sources.
    
    This report provides comprehensive price comparison and reconciliation across:
    1. MAG system CSV file (aggregates prices from other systems)
    2. Desk submitted prices for margining purposes to MAG  
    3. Risk system's market (K Mkt)
    
    The report includes:
    - Normalized combined dataframe with all price sources
    - Price differences and percentage differences within sources
    - Cross-source price comparisons
    - Missing price flags and indicators
    - Break analysis for significant price differences
    """
    
    # Column name constants
    ISIN = 'ISIN'
    MARKET_PRICE = 'MARKET_PRICE'
    CLEAN_ASK = 'CLEAN_ASK'
    CLEAN_BID = 'CLEAN_BID'
    DIRTY_BID = 'DIRTY_BID'
    DIRTY_ASK = 'DIRTY_ASK'
    PRICE_SOURCE_ID = 'PRICE_SOURCE_ID'
    RISK_PX = 'RiskPX'
    K_MKT_CLEAN_BID = 'K_MKT_CLEAN_BID'
    K_MKT_CLEAN_ASK = 'K_MKT_CLEAN_ASK'
    
    # Source identifier columns
    SOURCE_MAG = 'MAG'
    SOURCE_DESK = 'DESK'
    SOURCE_KMKT = 'K_MKT'
    SOURCE_MAG_COL = 'SOURCE_MAG'
    SOURCE_DESK_COL = 'SOURCE_DESK'
    SOURCE_KMKT_COL = 'SOURCE_KMKT'
    
    # Missing price flag columns
    MAG_MARKET_PRICE_MISSING = 'MAG_MARKET_PRICE_MISSING'
    MAG_CLEAN_BID_MISSING = 'MAG_CLEAN_BID_MISSING'
    MAG_CLEAN_ASK_MISSING = 'MAG_CLEAN_ASK_MISSING'
    MAG_DIRTY_BID_MISSING = 'MAG_DIRTY_BID_MISSING'
    MAG_DIRTY_ASK_MISSING = 'MAG_DIRTY_ASK_MISSING'
    DESK_RISK_PX_MISSING = 'DESK_RISK_PX_MISSING'
    KMKT_CLEAN_BID_MISSING = 'KMKT_CLEAN_BID_MISSING'
    KMKT_CLEAN_ASK_MISSING = 'KMKT_CLEAN_ASK_MISSING'
    MAG_SOURCE_MISSING = 'MAG_SOURCE_MISSING'
    DESK_SOURCE_MISSING = 'DESK_SOURCE_MISSING'
    KMKT_SOURCE_MISSING = 'KMKT_SOURCE_MISSING'
    
    # Price difference columns
    MAG_MARKET_VS_CLEAN_BID_DIFF = 'MAG_MARKET_VS_CLEAN_BID_DIFF'
    MAG_MARKET_VS_CLEAN_ASK_DIFF = 'MAG_MARKET_VS_CLEAN_ASK_DIFF'
    MAG_MARKET_VS_CLEAN_BID_PCT = 'MAG_MARKET_VS_CLEAN_BID_PCT'
    MAG_MARKET_VS_CLEAN_ASK_PCT = 'MAG_MARKET_VS_CLEAN_ASK_PCT'
    MAG_MARKET_VS_DIRTY_BID_DIFF = 'MAG_MARKET_VS_DIRTY_BID_DIFF'
    MAG_MARKET_VS_DIRTY_ASK_DIFF = 'MAG_MARKET_VS_DIRTY_ASK_DIFF'
    MAG_MARKET_VS_DIRTY_BID_PCT = 'MAG_MARKET_VS_DIRTY_BID_PCT'
    MAG_MARKET_VS_DIRTY_ASK_PCT = 'MAG_MARKET_VS_DIRTY_ASK_PCT'
    
    # Cross-source difference columns
    MAG_VS_DESK_CLEAN_BID_DIFF = 'MAG_VS_DESK_CLEAN_BID_DIFF'
    MAG_VS_DESK_CLEAN_BID_PCT = 'MAG_VS_DESK_CLEAN_BID_PCT'
    MAG_VS_KMKT_CLEAN_BID_DIFF = 'MAG_VS_KMKT_CLEAN_BID_DIFF'
    MAG_VS_KMKT_CLEAN_ASK_DIFF = 'MAG_VS_KMKT_CLEAN_ASK_DIFF'
    MAG_VS_KMKT_CLEAN_BID_PCT = 'MAG_VS_KMKT_CLEAN_BID_PCT'
    MAG_VS_KMKT_CLEAN_ASK_PCT = 'MAG_VS_KMKT_CLEAN_ASK_PCT'
    KANNON_VS_KMKT_CLEAN_BID_DIFF = 'KANNON_VS_KMKT_CLEAN_BID_DIFF'
    KANNON_VS_KMKT_CLEAN_ASK_DIFF = 'KANNON_VS_KMKT_CLEAN_ASK_DIFF'
    KANNON_VS_KMKT_CLEAN_BID_PCT = 'KANNON_VS_KMKT_CLEAN_BID_PCT'
    KANNON_VS_KMKT_CLEAN_ASK_PCT = 'KANNON_VS_KMKT_CLEAN_ASK_PCT'
    
    # Price source IDs from MAG
    PRICE_SOURCES = ['EMAIL', 'KANNON', 'MERCURY', 'GRIP', 'SPIDERSSNG', 'BLOOMBERG']
    
    # Long format columns
    PRICE_SOURCE = 'PRICE_SOURCE'
    PRICE_TYPE = 'PRICE_TYPE'
    PRICE = 'PRICE'
    
    # Bond static information columns
    SECTOR = 'SECTOR'
    BBG_COLLAT_TYPE = 'BBG_COLLAT_TYPE'
    BOND_TYPE = 'BOND_TYPE'
    
    def __init__(self, 
                 mag_df: pd.DataFrame,
                 desk_df: pd.DataFrame, 
                 kmkt_df: pd.DataFrame,
                 report_name: str = "Price Reconciliation Report"):
        """
        Initialize the price reconciliation report.
        
        Args:
            mag_df: MAG system DataFrame with MARKET_PRICE, CLEAN_ASK, CLEAN_BID, 
                   DIRTY_BID, DIRTY_ASK, PRICE_SOURCE_ID columns
            desk_df: Desk submitted prices DataFrame with ISIN, RiskPX columns
            kmkt_df: K Market DataFrame with ISIN, K_MKT_CLEAN_BID, K_MKT_CLEAN_ASK columns
            report_name: Name of the report
        """
        self.mag_df = mag_df.copy()
        self.desk_df = desk_df.copy()
        self.kmkt_df = kmkt_df.copy()
        
        # Create normalized combined dataframe
        self.normalized_data = self._create_normalized_dataframe()
        
        # Initialize base report with normalized data
        super().__init__(self.normalized_data, report_name)
        
        # Enrich with bond static information
        self.normalized_data = self._enrich_with_bond_static_info()
        
        # Override pivot_data to use the new dictionary structure
        self.pivot_data = self._create_pivot_data()
    
    def _create_normalized_dataframe(self) -> pd.DataFrame:
        """
        Create a normalized dataframe combining all three price sources.
        
        Returns:
            Normalized DataFrame with all price sources and comparison columns
        """
        # Ensure ISIN is the key column for all dataframes
        mag_df = self.mag_df.copy()
        desk_df = self.desk_df.copy()
        kmkt_df = self.kmkt_df.copy()
        
        # Standardize column names and add source identifiers
        mag_df[self.SOURCE_MAG_COL] = self.SOURCE_MAG
        desk_df[self.SOURCE_DESK_COL] = self.SOURCE_DESK
        kmkt_df[self.SOURCE_KMKT_COL] = self.SOURCE_KMKT
        
        # Merge all dataframes on ISIN
        combined_df = mag_df.merge(desk_df, on=self.ISIN, how='outer', suffixes=('_MAG', '_DESK'))
        combined_df = combined_df.merge(kmkt_df, on=self.ISIN, how='outer')
        
        # Fill missing values with np.nan
        combined_df = combined_df.fillna(np.nan)
        
        # Add missing price flags
        combined_df = self._add_missing_price_flags(combined_df)
        
        # Add price differences within MAG source
        combined_df = self._add_mag_price_differences(combined_df)
        
        # Add cross-source price differences
        combined_df = self._add_cross_source_differences(combined_df)
        
        return combined_df
    
    def _add_missing_price_flags(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Add flags to indicate missing prices and price types.
        
        Args:
            df: Combined dataframe
            
        Returns:
            DataFrame with missing price flags added
        """
        # Missing price flags for MAG source
        df[self.MAG_MARKET_PRICE_MISSING] = df[self.MARKET_PRICE].isna()
        df[self.MAG_CLEAN_BID_MISSING] = df[self.CLEAN_BID].isna()
        df[self.MAG_CLEAN_ASK_MISSING] = df[self.CLEAN_ASK].isna()
        df[self.MAG_DIRTY_BID_MISSING] = df[self.DIRTY_BID].isna()
        df[self.MAG_DIRTY_ASK_MISSING] = df[self.DIRTY_ASK].isna()
        
        # Missing price flags for Desk source
        df[self.DESK_RISK_PX_MISSING] = df[self.RISK_PX].isna()
        
        # Missing price flags for K Market source
        df[self.KMKT_CLEAN_BID_MISSING] = df[self.K_MKT_CLEAN_BID].isna()
        df[self.KMKT_CLEAN_ASK_MISSING] = df[self.K_MKT_CLEAN_ASK].isna()
        
        # Overall missing source flags
        df[self.MAG_SOURCE_MISSING] = df[self.SOURCE_MAG_COL].isna()
        df[self.DESK_SOURCE_MISSING] = df[self.SOURCE_DESK_COL].isna()
        df[self.KMKT_SOURCE_MISSING] = df[self.SOURCE_KMKT_COL].isna()
        
        return df
    
    def _add_mag_price_differences(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Add price differences within MAG source.
        
        Args:
            df: Combined dataframe
            
        Returns:
            DataFrame with MAG price differences added
        """
        # MARKET_PRICE vs CLEAN_BID/ASK differences
        df[self.MAG_MARKET_VS_CLEAN_BID_DIFF] = df[self.MARKET_PRICE] - df[self.CLEAN_BID]
        df[self.MAG_MARKET_VS_CLEAN_ASK_DIFF] = df[self.MARKET_PRICE] - df[self.CLEAN_ASK]
        df[self.MAG_MARKET_VS_CLEAN_BID_PCT] = ((df[self.MARKET_PRICE] - df[self.CLEAN_BID]) / df[self.CLEAN_BID] * 100).fillna(np.nan)
        df[self.MAG_MARKET_VS_CLEAN_ASK_PCT] = ((df[self.MARKET_PRICE] - df[self.CLEAN_ASK]) / df[self.CLEAN_ASK] * 100).fillna(np.nan)
        
        # MARKET_PRICE vs DIRTY_BID/ASK differences
        df[self.MAG_MARKET_VS_DIRTY_BID_DIFF] = df[self.MARKET_PRICE] - df[self.DIRTY_BID]
        df[self.MAG_MARKET_VS_DIRTY_ASK_DIFF] = df[self.MARKET_PRICE] - df[self.DIRTY_ASK]
        df[self.MAG_MARKET_VS_DIRTY_BID_PCT] = ((df[self.MARKET_PRICE] - df[self.DIRTY_BID]) / df[self.DIRTY_BID] * 100).fillna(np.nan)
        df[self.MAG_MARKET_VS_DIRTY_ASK_PCT] = ((df[self.MARKET_PRICE] - df[self.DIRTY_ASK]) / df[self.DIRTY_ASK] * 100).fillna(np.nan)
        
        return df
    
    def _add_cross_source_differences(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Add cross-source price differences.
        
        Args:
            df: Combined dataframe
            
        Returns:
            DataFrame with cross-source differences added
        """
        # MAG vs Desk differences (CLEAN_BID comparison)
        df[self.MAG_VS_DESK_CLEAN_BID_DIFF] = df[self.CLEAN_BID] - df[self.RISK_PX]
        df[self.MAG_VS_DESK_CLEAN_BID_PCT] = ((df[self.CLEAN_BID] - df[self.RISK_PX]) / df[self.RISK_PX] * 100).fillna(np.nan)
        
        # MAG vs K Market differences
        df[self.MAG_VS_KMKT_CLEAN_BID_DIFF] = df[self.CLEAN_BID] - df[self.K_MKT_CLEAN_BID]
        df[self.MAG_VS_KMKT_CLEAN_ASK_DIFF] = df[self.CLEAN_ASK] - df[self.K_MKT_CLEAN_ASK]
        df[self.MAG_VS_KMKT_CLEAN_BID_PCT] = ((df[self.CLEAN_BID] - df[self.K_MKT_CLEAN_BID]) / df[self.K_MKT_CLEAN_BID] * 100).fillna(np.nan)
        df[self.MAG_VS_KMKT_CLEAN_ASK_PCT] = ((df[self.CLEAN_ASK] - df[self.K_MKT_CLEAN_ASK]) / df[self.K_MKT_CLEAN_ASK] * 100).fillna(np.nan)
        
        # KANNON specific comparisons (as requested)
        kannon_mask = df[self.PRICE_SOURCE_ID] == 'KANNON'
        df[self.KANNON_VS_KMKT_CLEAN_BID_DIFF] = np.where(kannon_mask, 
                                                        df[self.CLEAN_BID] - df[self.K_MKT_CLEAN_BID], np.nan)
        df[self.KANNON_VS_KMKT_CLEAN_ASK_DIFF] = np.where(kannon_mask, 
                                                        df[self.CLEAN_ASK] - df[self.K_MKT_CLEAN_ASK], np.nan)
        df[self.KANNON_VS_KMKT_CLEAN_BID_PCT] = np.where(kannon_mask,
                                                       ((df[self.CLEAN_BID] - df[self.K_MKT_CLEAN_BID]) / df[self.K_MKT_CLEAN_BID] * 100), np.nan)
        df[self.KANNON_VS_KMKT_CLEAN_ASK_PCT] = np.where(kannon_mask,
                                                       ((df[self.CLEAN_ASK] - df[self.K_MKT_CLEAN_ASK]) / df[self.K_MKT_CLEAN_ASK] * 100), np.nan)
        
        return df
    
    def _create_pivot_data(self) -> Dict[str, pd.DataFrame]:
        """
        Create pivot/summary data from the price reconciliation data.
        
        Creates multiple pivot tables and summary statistics including:
        - Price source availability summary
        - Price difference statistics
        - Break analysis
        - Missing price analysis
        - Cross-source comparison summaries
        
        Returns:
            Dictionary containing the pivot/summary dataframes
        """
        pivot_dataframes = {}
        
        # 1. Price Source Availability Summary
        availability_summary = self._create_availability_summary()
        pivot_dataframes['Price Source Availability'] = availability_summary
        
        # 2. Price Difference Statistics
        diff_stats = self._create_difference_statistics()
        pivot_dataframes['Price Difference Statistics'] = diff_stats
        
        # 3. Break Analysis
        break_analysis = self._create_break_analysis()
        pivot_dataframes['Break Analysis'] = break_analysis
        
        # 4. Missing Price Analysis
        missing_analysis = self._create_missing_price_analysis()
        pivot_dataframes['Missing Price Analysis'] = missing_analysis
        
        # 5. Cross-Source Comparison Summary
        cross_source_summary = self._create_cross_source_summary()
        pivot_dataframes['Cross-Source Comparison'] = cross_source_summary
        
        # 6. KANNON vs K Market Analysis
        kannon_analysis = self._create_kannon_analysis()
        pivot_dataframes['KANNON vs K Market Analysis'] = kannon_analysis
        
        # 7. Bond Type Break Analysis
        bond_type_analysis = self._create_bond_type_break_analysis()
        pivot_dataframes['Bond Type Break Analysis'] = bond_type_analysis
        
        return pivot_dataframes
    
    def _create_availability_summary(self) -> pd.DataFrame:
        """Create summary of price source availability."""
        total_isins = len(self.normalized_data)
        
        availability_data = []
        
        # MAG source availability
        mag_available = (~self.normalized_data[self.MAG_SOURCE_MISSING]).sum()
        availability_data.append({
            'Source': 'MAG System',
            'Available': mag_available,
            'Missing': total_isins - mag_available,
            'Availability %': round((mag_available / total_isins * 100), 2)
        })
        
        # Desk source availability
        desk_available = (~self.normalized_data[self.DESK_SOURCE_MISSING]).sum()
        availability_data.append({
            'Source': 'Desk Submitted',
            'Available': desk_available,
            'Missing': total_isins - desk_available,
            'Availability %': round((desk_available / total_isins * 100), 2)
        })
        
        # K Market source availability
        kmkt_available = (~self.normalized_data[self.KMKT_SOURCE_MISSING]).sum()
        availability_data.append({
            'Source': 'K Market',
            'Available': kmkt_available,
            'Missing': total_isins - kmkt_available,
            'Availability %': round((kmkt_available / total_isins * 100), 2)
        })
        
        return pd.DataFrame(availability_data)
    
    def _create_difference_statistics(self) -> pd.DataFrame:
        """Create statistics for price differences."""
        diff_columns = [col for col in self.normalized_data.columns if 'DIFF' in col or 'PCT' in col]
        
        if not diff_columns:
            return pd.DataFrame()
        
        diff_stats = []
        for col in diff_columns:
            if col in self.normalized_data.columns:
                series = self.normalized_data[col].dropna()
                if len(series) > 0:
                    diff_stats.append({
                        'Difference Type': col,
                        'Count': len(series),
                        'Mean': series.mean(),
                        'Std': series.std(),
                        'Min': series.min(),
                        'Max': series.max(),
                        'Median': series.median()
                    })
        
        return pd.DataFrame(diff_stats)
    
    def _create_break_analysis(self) -> pd.DataFrame:
        """Create analysis of significant price breaks."""
        # Define break thresholds (configurable)
        price_diff_threshold = 0.01  # 1 basis point
        pct_diff_threshold = 0.1     # 0.1%
        
        breaks_data = []
        
        # MAG vs Desk breaks
        mag_desk_breaks = self.normalized_data[
            (abs(self.normalized_data[self.MAG_VS_DESK_CLEAN_BID_DIFF]) > price_diff_threshold) |
            (abs(self.normalized_data[self.MAG_VS_DESK_CLEAN_BID_PCT]) > pct_diff_threshold)
        ]
        
        if len(mag_desk_breaks) > 0:
            breaks_data.append({
                'Break Type': 'MAG vs Desk',
                'Break Count': len(mag_desk_breaks),
                'Avg Price Diff': mag_desk_breaks[self.MAG_VS_DESK_CLEAN_BID_DIFF].mean(),
                'Avg Pct Diff': mag_desk_breaks[self.MAG_VS_DESK_CLEAN_BID_PCT].mean(),
                'Max Price Diff': mag_desk_breaks[self.MAG_VS_DESK_CLEAN_BID_DIFF].max(),
                'Max Pct Diff': mag_desk_breaks[self.MAG_VS_DESK_CLEAN_BID_PCT].max()
            })
        
        # MAG vs K Market breaks
        mag_kmkt_breaks = self.normalized_data[
            (abs(self.normalized_data[self.MAG_VS_KMKT_CLEAN_BID_DIFF]) > price_diff_threshold) |
            (abs(self.normalized_data[self.MAG_VS_KMKT_CLEAN_BID_PCT]) > pct_diff_threshold) |
            (abs(self.normalized_data[self.MAG_VS_KMKT_CLEAN_ASK_DIFF]) > price_diff_threshold) |
            (abs(self.normalized_data[self.MAG_VS_KMKT_CLEAN_ASK_PCT]) > pct_diff_threshold)
        ]
        
        if len(mag_kmkt_breaks) > 0:
            breaks_data.append({
                'Break Type': 'MAG vs K Market',
                'Break Count': len(mag_kmkt_breaks),
                'Avg Price Diff': mag_kmkt_breaks[[self.MAG_VS_KMKT_CLEAN_BID_DIFF, self.MAG_VS_KMKT_CLEAN_ASK_DIFF]].mean().mean(),
                'Avg Pct Diff': mag_kmkt_breaks[[self.MAG_VS_KMKT_CLEAN_BID_PCT, self.MAG_VS_KMKT_CLEAN_ASK_PCT]].mean().mean(),
                'Max Price Diff': mag_kmkt_breaks[[self.MAG_VS_KMKT_CLEAN_BID_DIFF, self.MAG_VS_KMKT_CLEAN_ASK_DIFF]].max().max(),
                'Max Pct Diff': mag_kmkt_breaks[[self.MAG_VS_KMKT_CLEAN_BID_PCT, self.MAG_VS_KMKT_CLEAN_ASK_PCT]].max().max()
            })
        
        return pd.DataFrame(breaks_data)
    
    def _create_missing_price_analysis(self) -> pd.DataFrame:
        """Create analysis of missing prices."""
        missing_data = []
        
        # Count missing prices by type
        missing_columns = [col for col in self.normalized_data.columns if 'MISSING' in col]
        
        for col in missing_columns:
            missing_count = self.normalized_data[col].sum()
            total_count = len(self.normalized_data)
            missing_data.append({
                'Price Type': col.replace('_MISSING', ''),
                'Missing Count': missing_count,
                'Total Count': total_count,
                'Missing %': round((missing_count / total_count * 100), 2)
            })
        
        return pd.DataFrame(missing_data)
    
    def _create_cross_source_summary(self) -> pd.DataFrame:
        """Create summary of cross-source comparisons."""
        summary_data = []
        
        # MAG vs Desk summary
        mag_desk_comparison = self.normalized_data[[self.MAG_VS_DESK_CLEAN_BID_DIFF, self.MAG_VS_DESK_CLEAN_BID_PCT]].describe()
        summary_data.append({
            'Comparison': 'MAG vs Desk',
            'Price Type': 'Clean Bid',
            'Count': mag_desk_comparison.loc['count', self.MAG_VS_DESK_CLEAN_BID_DIFF],
            'Mean Diff': mag_desk_comparison.loc['mean', self.MAG_VS_DESK_CLEAN_BID_DIFF],
            'Mean Pct': mag_desk_comparison.loc['mean', self.MAG_VS_DESK_CLEAN_BID_PCT],
            'Std Diff': mag_desk_comparison.loc['std', self.MAG_VS_DESK_CLEAN_BID_DIFF],
            'Std Pct': mag_desk_comparison.loc['std', self.MAG_VS_DESK_CLEAN_BID_PCT]
        })
        
        # MAG vs K Market summary
        mag_kmkt_bid_comparison = self.normalized_data[[self.MAG_VS_KMKT_CLEAN_BID_DIFF, self.MAG_VS_KMKT_CLEAN_BID_PCT]].describe()
        summary_data.append({
            'Comparison': 'MAG vs K Market',
            'Price Type': 'Clean Bid',
            'Count': mag_kmkt_bid_comparison.loc['count', self.MAG_VS_KMKT_CLEAN_BID_DIFF],
            'Mean Diff': mag_kmkt_bid_comparison.loc['mean', self.MAG_VS_KMKT_CLEAN_BID_DIFF],
            'Mean Pct': mag_kmkt_bid_comparison.loc['mean', self.MAG_VS_KMKT_CLEAN_BID_PCT],
            'Std Diff': mag_kmkt_bid_comparison.loc['std', self.MAG_VS_KMKT_CLEAN_BID_DIFF],
            'Std Pct': mag_kmkt_bid_comparison.loc['std', self.MAG_VS_KMKT_CLEAN_BID_PCT]
        })
        
        mag_kmkt_ask_comparison = self.normalized_data[[self.MAG_VS_KMKT_CLEAN_ASK_DIFF, self.MAG_VS_KMKT_CLEAN_ASK_PCT]].describe()
        summary_data.append({
            'Comparison': 'MAG vs K Market',
            'Price Type': 'Clean Ask',
            'Count': mag_kmkt_ask_comparison.loc['count', self.MAG_VS_KMKT_CLEAN_ASK_DIFF],
            'Mean Diff': mag_kmkt_ask_comparison.loc['mean', self.MAG_VS_KMKT_CLEAN_ASK_DIFF],
            'Mean Pct': mag_kmkt_ask_comparison.loc['mean', self.MAG_VS_KMKT_CLEAN_ASK_PCT],
            'Std Diff': mag_kmkt_ask_comparison.loc['std', self.MAG_VS_KMKT_CLEAN_ASK_DIFF],
            'Std Pct': mag_kmkt_ask_comparison.loc['std', self.MAG_VS_KMKT_CLEAN_ASK_PCT]
        })
        
        return pd.DataFrame(summary_data)
    
    def _create_kannon_analysis(self) -> pd.DataFrame:
        """Create specific analysis for KANNON vs K Market comparisons."""
        kannon_data = self.normalized_data[self.normalized_data[self.PRICE_SOURCE_ID] == 'KANNON']
        
        if len(kannon_data) == 0:
            return pd.DataFrame({'Message': ['No KANNON data found']})
        
        kannon_analysis = kannon_data[[self.KANNON_VS_KMKT_CLEAN_BID_DIFF, self.KANNON_VS_KMKT_CLEAN_ASK_DIFF,
                                      self.KANNON_VS_KMKT_CLEAN_BID_PCT, self.KANNON_VS_KMKT_CLEAN_ASK_PCT]].describe()
        
        return kannon_analysis
    
    def get_mag_desk_breaks(self) -> pd.DataFrame:
        """
        Get ISINs where Clean Bid/Ask differ between MAG and Desk sources.
        
        Returns:
            DataFrame with ISINs and their price differences
        """
        breaks = self.normalized_data[
            (abs(self.normalized_data[self.MAG_VS_DESK_CLEAN_BID_DIFF]) > 0.001) |  # 0.1 basis point threshold
            (abs(self.normalized_data[self.MAG_VS_DESK_CLEAN_BID_PCT]) > 0.05)      # 0.05% threshold
        ]
        
        return breaks[[self.ISIN, self.CLEAN_BID, self.RISK_PX, 
                      self.MAG_VS_DESK_CLEAN_BID_DIFF, self.MAG_VS_DESK_CLEAN_BID_PCT]].copy()
    
    def get_mag_kmkt_breaks(self) -> pd.DataFrame:
        """
        Get ISINs where Clean Bid/Ask differ between MAG and K Market sources.
        
        Returns:
            DataFrame with ISINs and their price differences
        """
        breaks = self.normalized_data[
            (abs(self.normalized_data[self.MAG_VS_KMKT_CLEAN_BID_DIFF]) > 0.001) |
            (abs(self.normalized_data[self.MAG_VS_KMKT_CLEAN_ASK_DIFF]) > 0.001) |
            (abs(self.normalized_data[self.MAG_VS_KMKT_CLEAN_BID_PCT]) > 0.05) |
            (abs(self.normalized_data[self.MAG_VS_KMKT_CLEAN_ASK_PCT]) > 0.05)
        ]
        
        return breaks[[self.ISIN, self.CLEAN_BID, self.CLEAN_ASK, 
                      self.K_MKT_CLEAN_BID, self.K_MKT_CLEAN_ASK,
                      self.MAG_VS_KMKT_CLEAN_BID_DIFF, self.MAG_VS_KMKT_CLEAN_ASK_DIFF,
                      self.MAG_VS_KMKT_CLEAN_BID_PCT, self.MAG_VS_KMKT_CLEAN_ASK_PCT]].copy()
    
    def get_kannon_kmkt_breaks(self) -> pd.DataFrame:
        """
        Get ISINs where Clean Bid/Ask differ between KANNON (MAG) and K Market sources.
        
        Returns:
            DataFrame with ISINs and their price differences
        """
        kannon_data = self.normalized_data[self.normalized_data[self.PRICE_SOURCE_ID] == 'KANNON']
        
        breaks = kannon_data[
            (abs(kannon_data[self.KANNON_VS_KMKT_CLEAN_BID_DIFF]) > 0.001) |
            (abs(kannon_data[self.KANNON_VS_KMKT_CLEAN_ASK_DIFF]) > 0.001) |
            (abs(kannon_data[self.KANNON_VS_KMKT_CLEAN_BID_PCT]) > 0.05) |
            (abs(kannon_data[self.KANNON_VS_KMKT_CLEAN_ASK_PCT]) > 0.05)
        ]
        
        return breaks[[self.ISIN, self.CLEAN_BID, self.CLEAN_ASK,
                      self.K_MKT_CLEAN_BID, self.K_MKT_CLEAN_ASK,
                      self.KANNON_VS_KMKT_CLEAN_BID_DIFF, self.KANNON_VS_KMKT_CLEAN_ASK_DIFF,
                      self.KANNON_VS_KMKT_CLEAN_BID_PCT, self.KANNON_VS_KMKT_CLEAN_ASK_PCT]].copy()
    
    def _create_prefixed_raw_data(self) -> pd.DataFrame:
        """
        Create a raw data view with prefixed price source columns and without generic source columns.
        
        Returns:
            DataFrame with prefixed price source columns
        """
        # Start with the normalized data
        prefixed_data = self.normalized_data.copy()
        
        # Remove generic source columns
        columns_to_drop = [self.SOURCE_MAG_COL, self.SOURCE_DESK_COL, self.SOURCE_KMKT_COL]
        prefixed_data = prefixed_data.drop(columns=[col for col in columns_to_drop if col in prefixed_data.columns])
        
        # Rename columns to include price source prefix
        column_mapping = {
            self.MARKET_PRICE: 'MAG_MARKET_PRICE',
            self.CLEAN_BID: 'MAG_CLEAN_BID',
            self.CLEAN_ASK: 'MAG_CLEAN_ASK',
            self.DIRTY_BID: 'MAG_DIRTY_BID',
            self.DIRTY_ASK: 'MAG_DIRTY_ASK',
            self.RISK_PX: 'DESK_RISK_PX',
            self.K_MKT_CLEAN_BID: 'KMKT_CLEAN_BID',
            self.K_MKT_CLEAN_ASK: 'KMKT_CLEAN_ASK'
        }
        
        prefixed_data = prefixed_data.rename(columns=column_mapping)
        
        return prefixed_data
    
    def _create_long_format_data(self) -> pd.DataFrame:
        """
        Create a long format view of the raw data with ISIN, PRICE_SOURCE, PRICE_TYPE, and PRICE.
        
        Returns:
            DataFrame in long format
        """
        long_data = []
        
        for _, row in self.normalized_data.iterrows():
            isin = row[self.ISIN]
            
            # MAG source data
            if not pd.isna(row[self.MARKET_PRICE]):
                long_data.append({
                    self.ISIN: isin,
                    self.PRICE_SOURCE: 'MAG',
                    self.PRICE_TYPE: f"MARKET_PRICE_{row.get(self.PRICE_SOURCE_ID, 'UNKNOWN')}",
                    self.PRICE: row[self.MARKET_PRICE]
                })
            
            if not pd.isna(row[self.CLEAN_BID]):
                long_data.append({
                    self.ISIN: isin,
                    self.PRICE_SOURCE: 'MAG',
                    self.PRICE_TYPE: f"CLEAN_BID_{row.get(self.PRICE_SOURCE_ID, 'UNKNOWN')}",
                    self.PRICE: row[self.CLEAN_BID]
                })
            
            if not pd.isna(row[self.CLEAN_ASK]):
                long_data.append({
                    self.ISIN: isin,
                    self.PRICE_SOURCE: 'MAG',
                    self.PRICE_TYPE: f"CLEAN_ASK_{row.get(self.PRICE_SOURCE_ID, 'UNKNOWN')}",
                    self.PRICE: row[self.CLEAN_ASK]
                })
            
            if not pd.isna(row[self.DIRTY_BID]):
                long_data.append({
                    self.ISIN: isin,
                    self.PRICE_SOURCE: 'MAG',
                    self.PRICE_TYPE: f"DIRTY_BID_{row.get(self.PRICE_SOURCE_ID, 'UNKNOWN')}",
                    self.PRICE: row[self.DIRTY_BID]
                })
            
            if not pd.isna(row[self.DIRTY_ASK]):
                long_data.append({
                    self.ISIN: isin,
                    self.PRICE_SOURCE: 'MAG',
                    self.PRICE_TYPE: f"DIRTY_ASK_{row.get(self.PRICE_SOURCE_ID, 'UNKNOWN')}",
                    self.PRICE: row[self.DIRTY_ASK]
                })
            
            # Desk source data
            if not pd.isna(row[self.RISK_PX]):
                long_data.append({
                    self.ISIN: isin,
                    self.PRICE_SOURCE: 'DESK',
                    self.PRICE_TYPE: 'RISK_PX',
                    self.PRICE: row[self.RISK_PX]
                })
            
            # K Market source data
            if not pd.isna(row[self.K_MKT_CLEAN_BID]):
                long_data.append({
                    self.ISIN: isin,
                    self.PRICE_SOURCE: 'KMKT',
                    self.PRICE_TYPE: 'CLEAN_BID',
                    self.PRICE: row[self.K_MKT_CLEAN_BID]
                })
            
            if not pd.isna(row[self.K_MKT_CLEAN_ASK]):
                long_data.append({
                    self.ISIN: isin,
                    self.PRICE_SOURCE: 'KMKT',
                    self.PRICE_TYPE: 'CLEAN_ASK',
                    self.PRICE: row[self.K_MKT_CLEAN_ASK]
                })
        
        return pd.DataFrame(long_data)
    
    def compare_with_previous_date(self, 
                                 previous_report: 'PriceReconciliationReport',
                                 comparison_type: str = 'DoD') -> pd.DataFrame:
        """
        Compare current report with a previous date report.
        
        Args:
            previous_report: PriceReconciliationReport from previous date
            comparison_type: Type of comparison ('DoD', 'WoW', 'MoM')
            
        Returns:
            DataFrame with comparison results
        """
        # Merge current and previous data on ISIN
        current_data = self.normalized_data.copy()
        previous_data = previous_report.normalized_data.copy()
        
        # Add date suffix to previous data columns to avoid conflicts
        previous_data = previous_data.add_suffix('_PREV')
        previous_data[self.ISIN] = previous_data[self.ISIN + '_PREV']
        
        # Merge data
        comparison_data = current_data.merge(
            previous_data, 
            on=self.ISIN, 
            how='outer',
            suffixes=('', '_PREV')
        )
        
        # Calculate absolute and percentage changes for key price columns
        price_columns = [
            self.MARKET_PRICE, self.CLEAN_BID, self.CLEAN_ASK,
            self.DIRTY_BID, self.DIRTY_ASK, self.RISK_PX,
            self.K_MKT_CLEAN_BID, self.K_MKT_CLEAN_ASK
        ]
        
        comparison_results = []
        
        for col in price_columns:
            if col in comparison_data.columns and col + '_PREV' in comparison_data.columns:
                # Calculate absolute change
                abs_change = comparison_data[col] - comparison_data[col + '_PREV']
                
                # Calculate percentage change
                pct_change = ((comparison_data[col] - comparison_data[col + '_PREV']) / 
                             comparison_data[col + '_PREV'] * 100).fillna(np.nan)
                
                # Add to results
                comparison_results.append({
                    'ISIN': comparison_data[self.ISIN],
                    'Price_Type': col,
                    'Current_Price': comparison_data[col],
                    'Previous_Price': comparison_data[col + '_PREV'],
                    'Absolute_Change': abs_change,
                    'Percentage_Change': pct_change,
                    'Comparison_Type': comparison_type
                })
        
        return pd.concat([pd.DataFrame(result) for result in comparison_results], ignore_index=True)
    
    def get_time_series_summary(self, 
                               previous_report: 'PriceReconciliationReport',
                               comparison_type: str = 'DoD') -> pd.DataFrame:
        """
        Get summary statistics for time series comparison.
        
        Args:
            previous_report: PriceReconciliationReport from previous date
            comparison_type: Type of comparison ('DoD', 'WoW', 'MoM')
            
        Returns:
            DataFrame with summary statistics
        """
        comparison_data = self.compare_with_previous_date(previous_report, comparison_type)
        
        if len(comparison_data) == 0:
            return pd.DataFrame()
        
        # Group by price type and calculate statistics
        summary_stats = comparison_data.groupby('Price_Type').agg({
            'Absolute_Change': ['count', 'mean', 'std', 'min', 'max'],
            'Percentage_Change': ['mean', 'std', 'min', 'max']
        })
        
        # Flatten column names
        summary_stats.columns = ['_'.join(col).strip() for col in summary_stats.columns.values]
        
        # Add comparison type
        summary_stats['Comparison_Type'] = comparison_type
        
        return summary_stats.reset_index()
    
    def _mock_bond_static_api_call(self, isins: List[str]) -> pd.DataFrame:
        """
        Mock API call to get bond static information.
        
        Args:
            isins: List of ISINs to get static info for
            
        Returns:
            DataFrame with bond static information
        """
        # Mock bond static data
        sectors = ['Government', 'Corporate', 'Municipal', 'Agency', 'Sovereign']
        collat_types = ['Government', 'Corporate', 'Asset-Backed', 'Mortgage-Backed', 'Collateralized']
        
        static_data = []
        for isin in isins:
            # Simple logic to assign sectors and collateral types based on ISIN
            if 'US' in isin:
                sector = 'Government' if '912' in isin else 'Corporate'
                collat_type = 'Government' if '912' in isin else 'Corporate'
            elif 'DE' in isin:
                sector = 'Sovereign'
                collat_type = 'Government'
            elif 'GB' in isin:
                sector = 'Government'
                collat_type = 'Government'
            else:
                sector = np.random.choice(sectors)
                collat_type = np.random.choice(collat_types)
            
            # Determine bond type based on sector and collateral type
            if sector == 'Government' and collat_type == 'Government':
                bond_type = 'Treasury'
            elif sector == 'Corporate' and collat_type == 'Corporate':
                bond_type = 'Corporate'
            elif sector == 'Municipal':
                bond_type = 'Municipal'
            elif collat_type in ['Asset-Backed', 'Mortgage-Backed']:
                bond_type = 'Securitized'
            else:
                bond_type = 'Other'
            
            static_data.append({
                self.ISIN: isin,
                self.SECTOR: sector,
                self.BBG_COLLAT_TYPE: collat_type,
                self.BOND_TYPE: bond_type
            })
        
        return pd.DataFrame(static_data)
    
    def _enrich_with_bond_static_info(self) -> pd.DataFrame:
        """
        Enrich the normalized data with bond static information.
        
        Returns:
            Enriched DataFrame with bond static information
        """
        # Get unique ISINs
        unique_isins = self.normalized_data[self.ISIN].unique().tolist()
        
        # Mock API call to get bond static information
        static_info = self._mock_bond_static_api_call(unique_isins)
        
        # Merge static information with normalized data
        enriched_data = self.normalized_data.merge(
            static_info, 
            on=self.ISIN, 
            how='left'
        )
        
        return enriched_data
    
    def _create_bond_type_break_analysis(self) -> pd.DataFrame:
        """
        Create break analysis by bond type.
        
        Returns:
            DataFrame with break analysis grouped by bond type
        """
        if self.BOND_TYPE not in self.normalized_data.columns:
            return pd.DataFrame({'Message': ['Bond type information not available']})
        
        break_analysis = []
        
        # Get breaks by bond type
        for bond_type in self.normalized_data[self.BOND_TYPE].unique():
            if pd.isna(bond_type):
                continue
                
            bond_type_data = self.normalized_data[self.normalized_data[self.BOND_TYPE] == bond_type]
            
            # MAG vs Desk breaks for this bond type
            mag_desk_breaks = bond_type_data[
                (abs(bond_type_data[self.MAG_VS_DESK_CLEAN_BID_DIFF]) > 0.001) |
                (abs(bond_type_data[self.MAG_VS_DESK_CLEAN_BID_PCT]) > 0.05)
            ]
            
            # MAG vs K Market breaks for this bond type
            mag_kmkt_breaks = bond_type_data[
                (abs(bond_type_data[self.MAG_VS_KMKT_CLEAN_BID_DIFF]) > 0.001) |
                (abs(bond_type_data[self.MAG_VS_KMKT_CLEAN_ASK_DIFF]) > 0.001) |
                (abs(bond_type_data[self.MAG_VS_KMKT_CLEAN_BID_PCT]) > 0.05) |
                (abs(bond_type_data[self.MAG_VS_KMKT_CLEAN_ASK_PCT]) > 0.05)
            ]
            
            break_analysis.append({
                'Bond_Type': bond_type,
                'Total_ISINs': len(bond_type_data),
                'MAG_Desk_Breaks': len(mag_desk_breaks),
                'MAG_KMKT_Breaks': len(mag_kmkt_breaks),
                'Total_Breaks': len(mag_desk_breaks) + len(mag_kmkt_breaks),
                'Break_Rate_%': round(((len(mag_desk_breaks) + len(mag_kmkt_breaks)) / len(bond_type_data) * 100), 2)
            })
        
        return pd.DataFrame(break_analysis)
    
    def create_summary_plots(self, output_dir: str = None) -> Dict[str, str]:
        """
        Create useful summary plots for the price reconciliation data.
        
        Args:
            output_dir: Directory to save plot files (optional)
            
        Returns:
            Dictionary mapping plot names to file paths
        """
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
        except ImportError:
            print("Warning: matplotlib and seaborn required for plotting. Install with: pip install matplotlib seaborn")
            return {}
        
        # Set style
        plt.style.use('default')
        sns.set_palette("husl")
        
        plot_files = {}
        
        if output_dir:
            import os
            os.makedirs(output_dir, exist_ok=True)
        
        # 1. Price Difference Distribution
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle('Price Difference Distributions', fontsize=16)
        
        # MAG vs Desk differences
        if self.MAG_VS_DESK_CLEAN_BID_DIFF in self.normalized_data.columns:
            axes[0, 0].hist(self.normalized_data[self.MAG_VS_DESK_CLEAN_BID_DIFF].dropna(), 
                           bins=20, alpha=0.7, color='blue')
            axes[0, 0].set_title('MAG vs Desk Clean Bid Differences')
            axes[0, 0].set_xlabel('Price Difference')
            axes[0, 0].set_ylabel('Frequency')
        
        # MAG vs K Market differences
        if self.MAG_VS_KMKT_CLEAN_BID_DIFF in self.normalized_data.columns:
            axes[0, 1].hist(self.normalized_data[self.MAG_VS_KMKT_CLEAN_BID_DIFF].dropna(), 
                           bins=20, alpha=0.7, color='green')
            axes[0, 1].set_title('MAG vs K Market Clean Bid Differences')
            axes[0, 1].set_xlabel('Price Difference')
            axes[0, 1].set_ylabel('Frequency')
        
        # Percentage differences
        if self.MAG_VS_DESK_CLEAN_BID_PCT in self.normalized_data.columns:
            axes[1, 0].hist(self.normalized_data[self.MAG_VS_DESK_CLEAN_BID_PCT].dropna(), 
                           bins=20, alpha=0.7, color='red')
            axes[1, 0].set_title('MAG vs Desk Clean Bid % Differences')
            axes[1, 0].set_xlabel('Percentage Difference (%)')
            axes[1, 0].set_ylabel('Frequency')
        
        if self.MAG_VS_KMKT_CLEAN_BID_PCT in self.normalized_data.columns:
            axes[1, 1].hist(self.normalized_data[self.MAG_VS_KMKT_CLEAN_BID_PCT].dropna(), 
                           bins=20, alpha=0.7, color='orange')
            axes[1, 1].set_title('MAG vs K Market Clean Bid % Differences')
            axes[1, 1].set_xlabel('Percentage Difference (%)')
            axes[1, 1].set_ylabel('Frequency')
        
        plt.tight_layout()
        
        if output_dir:
            plot_file = os.path.join(output_dir, 'price_difference_distributions.png')
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            plot_files['price_difference_distributions'] = plot_file
        
        plt.show()
        
        # 2. Break Analysis by Bond Type (if available)
        if self.BOND_TYPE in self.normalized_data.columns:
            fig, axes = plt.subplots(1, 2, figsize=(15, 6))
            fig.suptitle('Break Analysis by Bond Type', fontsize=16)
            
            bond_type_analysis = self._create_bond_type_break_analysis()
            
            if len(bond_type_analysis) > 0 and 'Message' not in bond_type_analysis.columns:
                # Break counts by bond type
                axes[0].bar(bond_type_analysis['Bond_Type'], bond_type_analysis['Total_Breaks'])
                axes[0].set_title('Total Breaks by Bond Type')
                axes[0].set_xlabel('Bond Type')
                axes[0].set_ylabel('Number of Breaks')
                axes[0].tick_params(axis='x', rotation=45)
                
                # Break rates by bond type
                axes[1].bar(bond_type_analysis['Bond_Type'], bond_type_analysis['Break_Rate_%'])
                axes[1].set_title('Break Rate by Bond Type')
                axes[1].set_xlabel('Bond Type')
                axes[1].set_ylabel('Break Rate (%)')
                axes[1].tick_params(axis='x', rotation=45)
            
            plt.tight_layout()
            
            if output_dir:
                plot_file = os.path.join(output_dir, 'break_analysis_by_bond_type.png')
                plt.savefig(plot_file, dpi=300, bbox_inches='tight')
                plot_files['break_analysis_by_bond_type'] = plot_file
            
            plt.show()
        
        # 3. Price Source Availability
        fig, ax = plt.subplots(figsize=(10, 6))
        
        availability_summary = self._create_availability_summary()
        sources = availability_summary['Source']
        availability_pct = availability_summary['Availability %']
        
        bars = ax.bar(sources, availability_pct, color=['blue', 'green', 'orange'])
        ax.set_title('Price Source Availability')
        ax.set_xlabel('Price Source')
        ax.set_ylabel('Availability (%)')
        ax.set_ylim(0, 100)
        
        # Add value labels on bars
        for bar, pct in zip(bars, availability_pct):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 1,
                   f'{pct:.1f}%', ha='center', va='bottom')
        
        plt.tight_layout()
        
        if output_dir:
            plot_file = os.path.join(output_dir, 'price_source_availability.png')
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            plot_files['price_source_availability'] = plot_file
        
        plt.show()
        
        return plot_files
    
    def to_excel(self, filepath: str) -> None:
        """
        Export the price reconciliation report to Excel format with multiple sheets.
        
        Args:
            filepath: Path where the Excel file should be saved
        """
        with xlsxwriter.Workbook(filepath) as workbook:
            formats = self._apply_excel_formatting(workbook)
            
            # Raw Data sheet (with prefixed columns)
            raw_sheet = workbook.add_worksheet('Raw Data')
            prefixed_raw_data = self._create_prefixed_raw_data()
            self._write_dataframe_to_excel(raw_sheet, prefixed_raw_data, formats=formats)
            
            # Long Format Raw Data sheet
            long_sheet = workbook.add_worksheet('Raw Data Long Format')
            long_format_data = self._create_long_format_data()
            self._write_dataframe_to_excel(long_sheet, long_format_data, formats=formats)
            
            # Pivot sheets
            for sheet_name, pivot_df in self.pivot_data.items():
                sheet = workbook.add_worksheet(sheet_name)
                self._write_dataframe_to_excel(sheet, pivot_df, formats=formats)
            
            # Break Analysis sheets
            mag_desk_breaks = self.get_mag_desk_breaks()
            if len(mag_desk_breaks) > 0:
                breaks_sheet = workbook.add_worksheet('MAG vs Desk Breaks')
                self._write_dataframe_to_excel(breaks_sheet, mag_desk_breaks, formats=formats)
            
            mag_kmkt_breaks = self.get_mag_kmkt_breaks()
            if len(mag_kmkt_breaks) > 0:
                breaks_sheet = workbook.add_worksheet('MAG vs K Market Breaks')
                self._write_dataframe_to_excel(breaks_sheet, mag_kmkt_breaks, formats=formats)
            
            kannon_kmkt_breaks = self.get_kannon_kmkt_breaks()
            if len(kannon_kmkt_breaks) > 0:
                breaks_sheet = workbook.add_worksheet('KANNON vs K Market Breaks')
                self._write_dataframe_to_excel(breaks_sheet, kannon_kmkt_breaks, formats=formats)
    
    def to_html(self, filepath: str) -> None:
        """
        Export the price reconciliation report to HTML format.
        
        Args:
            filepath: Path where the HTML file should be saved
        """
        html_content = f"""
        <html>
        <head>
            <title>{self.report_name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                h1, h2, h3 {{ color: #000080; }}
                table {{ border-collapse: collapse; width: 100%; margin: 10px 0; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #000080; color: white; }}
                tr:nth-child(even) {{ background-color: #f2f2f2; }}
                .summary {{ background-color: #f9f9f9; padding: 15px; margin: 10px 0; }}
            </style>
        </head>
        <body>
            <h1>{self.report_name}</h1>
            <div class="summary">
                <p><strong>Created:</strong> {self.created_at.strftime('%Y-%m-%d %H:%M:%S')}</p>
                <p><strong>Total ISINs:</strong> {len(self.normalized_data)}</p>
                <p><strong>Data Sources:</strong> MAG System, Desk Submitted, K Market</p>
            </div>
        """
        
        # Add pivot tables
        for sheet_name, pivot_df in self.pivot_data.items():
            html_content += f"<h2>{sheet_name}</h2>"
            html_content += pivot_df.to_html(index=False)
        
        # Add break analysis
        mag_desk_breaks = self.get_mag_desk_breaks()
        if len(mag_desk_breaks) > 0:
            html_content += f"<h2>MAG vs Desk Breaks ({len(mag_desk_breaks)} records)</h2>"
            html_content += mag_desk_breaks.to_html(index=False)
        
        mag_kmkt_breaks = self.get_mag_kmkt_breaks()
        if len(mag_kmkt_breaks) > 0:
            html_content += f"<h2>MAG vs K Market Breaks ({len(mag_kmkt_breaks)} records)</h2>"
            html_content += mag_kmkt_breaks.to_html(index=False)
        
        kannon_kmkt_breaks = self.get_kannon_kmkt_breaks()
        if len(kannon_kmkt_breaks) > 0:
            html_content += f"<h2>KANNON vs K Market Breaks ({len(kannon_kmkt_breaks)} records)</h2>"
            html_content += kannon_kmkt_breaks.to_html(index=False)
        
        html_content += "</body></html>"
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
    
    def to_json(self, filepath: str) -> None:
        """
        Export the price reconciliation report to JSON format.
        
        Args:
            filepath: Path where the JSON file should be saved
        """
        report_data = {
            'report_name': self.report_name,
            'created_at': self.created_at.isoformat(),
            'summary': {
                'total_isins': len(self.normalized_data),
                'mag_records': len(self.mag_df),
                'desk_records': len(self.desk_df),
                'kmkt_records': len(self.kmkt_df)
            },
            'pivot_data': {
                name: df.to_dict('records') for name, df in self.pivot_data.items()
            },
            'breaks': {
                'mag_desk_breaks': self.get_mag_desk_breaks().to_dict('records'),
                'mag_kmkt_breaks': self.get_mag_kmkt_breaks().to_dict('records'),
                'kannon_kmkt_breaks': self.get_kannon_kmkt_breaks().to_dict('records')
            }
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, indent=2, default=str)
    
    def to_serialised_blob(self, filepath: str) -> None:
        """
        Export the price reconciliation report as a serialized blob (pickle format).
        
        Args:
            filepath: Path where the serialized blob should be saved
        """
        with open(filepath, 'wb') as f:
            pickle.dump(self, f) 