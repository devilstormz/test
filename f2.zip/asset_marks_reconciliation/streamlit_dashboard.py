"""
Streamlit Dashboard for Asset Marks Reconciliation Breaks

This dashboard provides interactive visualization of price reconciliation breaks
across multiple price sources (MAG, Desk, K Market) with comprehensive statistics
and filtering capabilities.
"""

import sys
import os
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import streamlit as st
from datetime import datetime
import json

# Add the parent directory to the path to import the framework
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the price reconciliation report
from asset_marks_reconciliation.price_reconciliation_report import PriceReconciliationReport
from asset_marks_reconciliation.example_usage import create_sample_data, create_previous_date_data


def create_mock_reconciliation_data():
    """Create mock reconciliation data for demonstration."""
    # Use the existing sample data creation function
    mag_df, desk_df, kmkt_df = create_sample_data()
    
    # Create the reconciliation report
    report = PriceReconciliationReport(
        mag_df=mag_df,
        desk_df=desk_df,
        kmkt_df=kmkt_df,
        report_name="Mock Asset Marks Reconciliation Report"
    )
    
    return report


def create_break_summary_stats(report):
    """Create summary statistics for breaks."""
    mag_desk_breaks = report.get_mag_desk_breaks()
    mag_kmkt_breaks = report.get_mag_kmkt_breaks()
    kannon_kmkt_breaks = report.get_kannon_kmkt_breaks()
    
    total_breaks = len(mag_desk_breaks) + len(mag_kmkt_breaks) + len(kannon_kmkt_breaks)
    
    # Calculate break statistics
    break_stats = {
        'Total Breaks': total_breaks,
        'MAG vs Desk Breaks': len(mag_desk_breaks),
        'MAG vs K Market Breaks': len(mag_kmkt_breaks),
        'KANNON vs K Market Breaks': len(kannon_kmkt_breaks),
        'Total ISINs': len(report.normalized_data),
        'Break Rate (%)': round((total_breaks / len(report.normalized_data)) * 100, 2) if len(report.normalized_data) > 0 else 0
    }
    
    return break_stats, mag_desk_breaks, mag_kmkt_breaks, kannon_kmkt_breaks


def create_break_visualizations(report, mag_desk_breaks, mag_kmkt_breaks, kannon_kmkt_breaks):
    """Create interactive visualizations for breaks."""
    visualizations = {}
    
    # 1. Break Type Distribution Pie Chart
    break_types = {
        'MAG vs Desk': len(mag_desk_breaks),
        'MAG vs K Market': len(mag_kmkt_breaks),
        'KANNON vs K Market': len(kannon_kmkt_breaks)
    }
    
    fig_pie = px.pie(
        values=list(break_types.values()),
        names=list(break_types.keys()),
        title="Break Distribution by Type",
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    fig_pie.update_traces(textposition='inside', textinfo='percent+label')
    visualizations['break_distribution'] = fig_pie
    
    # 2. Price Difference Distribution (if breaks exist)
    all_breaks = []
    if len(mag_desk_breaks) > 0:
        mag_desk_breaks['break_type'] = 'MAG vs Desk'
        all_breaks.append(mag_desk_breaks)
    if len(mag_kmkt_breaks) > 0:
        mag_kmkt_breaks['break_type'] = 'MAG vs K Market'
        all_breaks.append(mag_kmkt_breaks)
    if len(kannon_kmkt_breaks) > 0:
        kannon_kmkt_breaks['break_type'] = 'KANNON vs K Market'
        all_breaks.append(kannon_kmkt_breaks)
    
    if all_breaks:
        combined_breaks = pd.concat(all_breaks, ignore_index=True)
        
        # Price difference histogram
        price_diff_cols = [col for col in combined_breaks.columns if 'DIFF' in col and 'PCT' not in col]
        if price_diff_cols:
            # Use the first available difference column
            diff_col = price_diff_cols[0]
            fig_hist = px.histogram(
                combined_breaks,
                x=diff_col,
                color='break_type',
                title=f"Price Difference Distribution ({diff_col})",
                nbins=20,
                opacity=0.7
            )
            fig_hist.update_layout(
                xaxis_title="Price Difference",
                yaxis_title="Frequency",
                showlegend=True
            )
            visualizations['price_difference_dist'] = fig_hist
    
    # 3. Break Severity Analysis
    if all_breaks:
        # Calculate severity based on percentage differences
        pct_cols = [col for col in combined_breaks.columns if 'PCT' in col]
        if pct_cols:
            pct_col = pct_cols[0]
            combined_breaks['severity'] = pd.cut(
                combined_breaks[pct_col].abs(),
                bins=[0, 0.1, 0.5, 1.0, 5.0, float('inf')],
                labels=['Minor (<0.1%)', 'Low (0.1-0.5%)', 'Medium (0.5-1%)', 'High (1-5%)', 'Critical (>5%)']
            )
            
            severity_counts = combined_breaks['severity'].value_counts()
            fig_severity = px.bar(
                x=severity_counts.index,
                y=severity_counts.values,
                title="Break Severity Distribution",
                color=severity_counts.values,
                color_continuous_scale='RdYlBu_r'
            )
            fig_severity.update_layout(
                xaxis_title="Severity Level",
                yaxis_title="Number of Breaks",
                showlegend=False
            )
            visualizations['break_severity'] = fig_severity
    
    # 4. Missing Price Analysis
    missing_cols = [col for col in report.normalized_data.columns if 'MISSING' in col]
    if missing_cols:
        missing_data = []
        for col in missing_cols:
            missing_count = report.normalized_data[col].sum()
            missing_data.append({
                'Price Source': col.replace('_MISSING', ''),
                'Missing Count': missing_count,
                'Missing Rate (%)': round((missing_count / len(report.normalized_data)) * 100, 2)
            })
        
        missing_df = pd.DataFrame(missing_data)
        fig_missing = px.bar(
            missing_df,
            x='Price Source',
            y='Missing Count',
            title="Missing Price Analysis",
            color='Missing Rate (%)',
            color_continuous_scale='Reds'
        )
        fig_missing.update_layout(
            xaxis_title="Price Source",
            yaxis_title="Missing Count",
            showlegend=True
        )
        visualizations['missing_prices'] = fig_missing
    
    return visualizations


def create_interactive_table(report, mag_desk_breaks, mag_kmkt_breaks, kannon_kmkt_breaks):
    """Create an interactive table with all breaks."""
    all_breaks = []
    
    if len(mag_desk_breaks) > 0:
        mag_desk_breaks['break_type'] = 'MAG vs Desk'
        all_breaks.append(mag_desk_breaks)
    if len(mag_kmkt_breaks) > 0:
        mag_kmkt_breaks['break_type'] = 'MAG vs K Market'
        all_breaks.append(mag_kmkt_breaks)
    if len(kannon_kmkt_breaks) > 0:
        kannon_kmkt_breaks['break_type'] = 'KANNON vs K Market'
        all_breaks.append(kannon_kmkt_breaks)
    
    if all_breaks:
        combined_breaks = pd.concat(all_breaks, ignore_index=True)
        
        # Select relevant columns for display
        display_cols = ['ISIN', 'break_type']
        diff_cols = [col for col in combined_breaks.columns if 'DIFF' in col and 'PCT' not in col]
        pct_cols = [col for col in combined_breaks.columns if 'PCT' in col]
        
        display_cols.extend(diff_cols[:2])  # Show first 2 difference columns
        display_cols.extend(pct_cols[:2])   # Show first 2 percentage columns
        
        # Filter columns that exist
        display_cols = [col for col in display_cols if col in combined_breaks.columns]
        
        return combined_breaks[display_cols]
    
    return pd.DataFrame()


def main():
    """Main Streamlit application."""
    st.set_page_config(
        page_title="Asset Marks Reconciliation Dashboard",
        page_icon="📊",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    st.title("📊 Asset Marks Reconciliation Dashboard")
    st.markdown("---")
    
    # Sidebar controls
    st.sidebar.header("🎛️ Dashboard Controls")
    
    # Data source selection
    data_source = st.sidebar.selectbox(
        "Data Source:",
        ["Mock Data", "Upload Files", "Previous Report"]
    )
    
    # Load data based on selection
    if data_source == "Mock Data":
        with st.spinner("Loading mock reconciliation data..."):
            report = create_mock_reconciliation_data()
        st.success("✅ Loaded mock reconciliation data")
    
    elif data_source == "Upload Files":
        st.sidebar.subheader("📁 Upload Data Files")
        
        uploaded_mag = st.sidebar.file_uploader("Upload MAG CSV", type=['csv'])
        uploaded_desk = st.sidebar.file_uploader("Upload Desk CSV", type=['csv'])
        uploaded_kmkt = st.sidebar.file_uploader("Upload K Market CSV", type=['csv'])
        
        if uploaded_mag and uploaded_desk and uploaded_kmkt:
            try:
                mag_df = pd.read_csv(uploaded_mag)
                desk_df = pd.read_csv(uploaded_desk)
                kmkt_df = pd.read_csv(uploaded_kmkt)
                
                report = PriceReconciliationReport(
                    mag_df=mag_df,
                    desk_df=desk_df,
                    kmkt_df=kmkt_df,
                    report_name="Uploaded Data Reconciliation Report"
                )
                st.success("✅ Loaded uploaded data")
            except Exception as e:
                st.error(f"❌ Error loading data: {e}")
                return
        else:
            st.info("📁 Please upload all three CSV files to proceed")
            return
    
    else:  # Previous Report
        st.sidebar.subheader("📄 Load Previous Report")
        uploaded_report = st.sidebar.file_uploader("Upload Report File", type=['pkl', 'json'])
        
        if uploaded_report:
            try:
                if uploaded_report.name.endswith('.pkl'):
                    import pickle
                    report = pickle.load(uploaded_report)
                else:
                    report_data = json.load(uploaded_report)
                    # Reconstruct report from JSON (simplified)
                    report = create_mock_reconciliation_data()
                st.success("✅ Loaded previous report")
            except Exception as e:
                st.error(f"❌ Error loading report: {e}")
                return
        else:
            st.info("📄 Please upload a report file to proceed")
            return
    
    # Get break data
    break_stats, mag_desk_breaks, mag_kmkt_breaks, kannon_kmkt_breaks = create_break_summary_stats(report)
    
    # Main dashboard layout
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Total Breaks",
            break_stats['Total Breaks'],
            delta=f"{break_stats['Break Rate (%)']}% rate"
        )
    
    with col2:
        st.metric(
            "MAG vs Desk",
            break_stats['MAG vs Desk Breaks']
        )
    
    with col3:
        st.metric(
            "MAG vs K Market",
            break_stats['MAG vs K Market Breaks']
        )
    
    with col4:
        st.metric(
            "KANNON vs K Market",
            break_stats['KANNON vs K Market Breaks']
        )
    
    # Create visualizations
    visualizations = create_break_visualizations(report, mag_desk_breaks, mag_kmkt_breaks, kannon_kmkt_breaks)
    
    # Tabs for different views
    tab1, tab2, tab3, tab4 = st.tabs(["📊 Overview", "🔍 Break Analysis", "📋 Data Tables", "📈 Detailed Charts"])
    
    with tab1:
        st.subheader("📊 Reconciliation Overview")
        
        # Summary statistics
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📈 Key Metrics")
            for key, value in break_stats.items():
                if key != 'Total Breaks':  # Already shown above
                    st.metric(key, value)
        
        with col2:
            st.subheader("📊 Data Coverage")
            coverage_data = {
                'Metric': ['Total ISINs', 'MAG Coverage', 'Desk Coverage', 'K Market Coverage'],
                'Count': [
                    len(report.normalized_data),
                    len(report.normalized_data) - report.normalized_data.get('MAG_SOURCE_MISSING', pd.Series([0])).sum(),
                    len(report.normalized_data) - report.normalized_data.get('DESK_SOURCE_MISSING', pd.Series([0])).sum(),
                    len(report.normalized_data) - report.normalized_data.get('KMKT_SOURCE_MISSING', pd.Series([0])).sum()
                ]
            }
            coverage_df = pd.DataFrame(coverage_data)
            coverage_df['Coverage %'] = (coverage_df['Count'] / coverage_df['Count'].iloc[0] * 100).round(1)
            st.dataframe(coverage_df, use_container_width=True)
        
        # Break distribution chart
        if 'break_distribution' in visualizations:
            st.plotly_chart(visualizations['break_distribution'], use_container_width=True)
    
    with tab2:
        st.subheader("🔍 Break Analysis")
        
        # Break severity analysis
        if 'break_severity' in visualizations:
            st.plotly_chart(visualizations['break_severity'], use_container_width=True)
        
        # Price difference distribution
        if 'price_difference_dist' in visualizations:
            st.plotly_chart(visualizations['price_difference_dist'], use_container_width=True)
        
        # Missing price analysis
        if 'missing_prices' in visualizations:
            st.plotly_chart(visualizations['missing_prices'], use_container_width=True)
    
    with tab3:
        st.subheader("📋 Data Tables")
        
        # Interactive break table
        break_table = create_interactive_table(report, mag_desk_breaks, mag_kmkt_breaks, kannon_kmkt_breaks)
        
        if not break_table.empty:
            st.subheader("🔍 All Breaks")
            
            # Filtering options
            col1, col2 = st.columns(2)
            with col1:
                break_type_filter = st.multiselect(
                    "Filter by Break Type:",
                    options=break_table['break_type'].unique(),
                    default=break_table['break_type'].unique()
                )
            
            with col2:
                search_isin = st.text_input("Search by ISIN:", "")
            
            # Apply filters
            filtered_table = break_table.copy()
            if break_type_filter:
                filtered_table = filtered_table[filtered_table['break_type'].isin(break_type_filter)]
            if search_isin:
                filtered_table = filtered_table[filtered_table['ISIN'].str.contains(search_isin, case=False)]
            
            st.dataframe(filtered_table, use_container_width=True)
            
            # Download button
            csv = filtered_table.to_csv(index=False)
            st.download_button(
                label="📥 Download Breaks CSV",
                data=csv,
                file_name=f"reconciliation_breaks_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
        else:
            st.info("✅ No breaks found in the data")
        
        # Raw data table
        st.subheader("📊 Raw Reconciliation Data")
        st.dataframe(report.normalized_data.head(100), use_container_width=True)
    
    with tab4:
        st.subheader("📈 Detailed Charts")
        
        # Time series analysis (if available)
        if hasattr(report, 'normalized_data') and 'trade_date' in report.normalized_data.columns:
            st.subheader("📅 Time Series Analysis")
            # Add time series visualization here
        
        # Price source analysis
        if hasattr(report, 'normalized_data') and 'PRICE_SOURCE_ID' in report.normalized_data.columns:
            st.subheader("🏷️ Price Source Analysis")
            source_counts = report.normalized_data['PRICE_SOURCE_ID'].value_counts()
            fig_source = px.bar(
                x=source_counts.index,
                y=source_counts.values,
                title="Price Sources Distribution",
                color=source_counts.values,
                color_continuous_scale='viridis'
            )
            fig_source.update_layout(
                xaxis_title="Price Source",
                yaxis_title="Count",
                showlegend=False
            )
            st.plotly_chart(fig_source, use_container_width=True)
    
    # Export functionality
    st.markdown("---")
    st.subheader("💾 Export Options")
    
    col_export1, col_export2, col_export3 = st.columns(3)
    
    with col_export1:
        if st.button("📊 Export Excel Report"):
            try:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"reconciliation_report_{timestamp}.xlsx"
                report.to_excel(filename)
                st.success(f"✅ Report exported: {filename}")
            except Exception as e:
                st.error(f"❌ Export failed: {e}")
    
    with col_export2:
        if st.button("🌐 Export HTML Report"):
            try:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"reconciliation_report_{timestamp}.html"
                report.to_html(filename)
                st.success(f"✅ Report exported: {filename}")
            except Exception as e:
                st.error(f"❌ Export failed: {e}")
    
    with col_export3:
        if st.button("📄 Export JSON Report"):
            try:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"reconciliation_report_{timestamp}.json"
                report.to_json(filename)
                st.success(f"✅ Report exported: {filename}")
            except Exception as e:
                st.error(f"❌ Export failed: {e}")


if __name__ == "__main__":
    main() 