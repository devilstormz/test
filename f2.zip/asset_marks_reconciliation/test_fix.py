"""
Test script to verify the price reconciliation report fix
"""

import sys
import os

# Add the parent directory to the path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_report_creation():
    """Test that the reconciliation report can be created without errors."""
    try:
        from asset_marks_reconciliation.price_reconciliation_report import PriceReconciliationReport
        from asset_marks_reconciliation.example_usage import create_sample_data
        
        print("Creating sample data...")
        mag_df, desk_df, kmkt_df = create_sample_data()
        
        print("Creating price reconciliation report...")
        report = PriceReconciliationReport(
            mag_df=mag_df,
            desk_df=desk_df,
            kmkt_df=kmkt_df,
            report_name="Test Price Reconciliation Report"
        )
        
        print(f"✅ Report created successfully!")
        print(f"   - Normalized data: {len(report.normalized_data)} records")
        print(f"   - Pivot sheets: {len(report.pivot_data)}")
        
        # Test break analysis
        mag_desk_breaks = report.get_mag_desk_breaks()
        mag_kmkt_breaks = report.get_mag_kmkt_breaks()
        kannon_kmkt_breaks = report.get_kannon_kmkt_breaks()
        
        total_breaks = len(mag_desk_breaks) + len(mag_kmkt_breaks) + len(kannon_kmkt_breaks)
        print(f"   - Total breaks: {total_breaks}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("🧪 Testing Price Reconciliation Report Fix")
    print("=" * 50)
    
    if test_report_creation():
        print("\n🎉 Test passed! The report creation is now working correctly.")
        print("\n📋 You can now run:")
        print("   streamlit run streamlit_dashboard.py")
    else:
        print("\n❌ Test failed. Please check the error above.") 