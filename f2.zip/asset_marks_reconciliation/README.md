# Asset Marks Reconciliation

This module provides comprehensive price reconciliation functionality for bond instruments across multiple price sources. It integrates with the existing reporting framework to generate detailed Excel reports with multiple analysis sheets.

## Overview

The price reconciliation system handles three main price sources:

1. **MAG System CSV File** - Aggregates prices from various systems (EMAIL, KANNON, MERCURY, GRIP, SPIDERSSNG, BLOOMBERG)
2. **Desk Submitted Prices** - Prices submitted by the desk for margining purposes to MAG
3. **Risk System Market (K Mkt)** - Risk system's market prices

## Features

### Core Functionality

- **Multi-source Price Comparison**: Combines and normalizes data from all three price sources
- **Comprehensive Difference Analysis**: 
  - Within-source price differences (MARKET_PRICE vs CLEAN/DIRTY BID/ASK)
  - Cross-source price comparisons
  - Percentage difference calculations
- **Missing Price Detection**: Flags and tracks missing prices from each source
- **Break Analysis**: Identifies significant price differences between sources
- **KANNON-specific Analysis**: Special handling for KANNON source vs K Market comparisons

### Report Outputs

The system generates comprehensive reports with multiple Excel sheets:

1. **Raw Data** - Complete normalized dataset with all price sources and calculations
2. **Price Source Availability** - Summary of data availability by source
3. **Price Difference Statistics** - Statistical analysis of price differences
4. **Break Analysis** - Summary of significant price breaks
5. **Missing Price Analysis** - Analysis of missing prices by type
6. **Cross-Source Comparison** - Detailed cross-source comparison statistics
7. **KANNON vs K Market Analysis** - Specific analysis for KANNON source
8. **Break Detail Sheets** - Detailed break analysis for each comparison type

## Usage

### Basic Usage

```python
from trading_analytics_framework.asset_marks_reconciliation import PriceReconciliationReport
import pandas as pd

# Load your data (assume data loading is handled by existing APIs)
mag_df = pd.DataFrame({
    'ISIN': ['US912810TM64', 'DE0001102309'],
    'MARKET_PRICE': [100.5, 101.2],
    'CLEAN_BID': [100.4, 101.1],
    'CLEAN_ASK': [100.6, 101.3],
    'DIRTY_BID': [100.9, 101.6],
    'DIRTY_ASK': [101.1, 101.8],
    'PRICE_SOURCE_ID': ['KANNON', 'EMAIL']
})

desk_df = pd.DataFrame({
    'ISIN': ['US912810TM64'],
    'RiskPX': [100.3]
})

kmkt_df = pd.DataFrame({
    'ISIN': ['US912810TM64'],
    'K_MKT_CLEAN_BID': [100.2],
    'K_MKT_CLEAN_ASK': [100.7]
})

# Create the reconciliation report
report = PriceReconciliationReport(
    mag_df=mag_df,
    desk_df=desk_df,
    kmkt_df=kmkt_df,
    report_name="Daily Price Reconciliation"
)

# Export to Excel with multiple sheets
report.to_excel("price_reconciliation_report.xlsx")
```

### Advanced Usage

```python
# Get specific break analysis
mag_desk_breaks = report.get_mag_desk_breaks()
mag_kmkt_breaks = report.get_mag_kmkt_breaks()
kannon_kmkt_breaks = report.get_kannon_kmkt_breaks()

# Export to different formats
report.to_html("price_reconciliation_report.html")
report.to_json("price_reconciliation_report.json")
report.to_serialised_blob("price_reconciliation_report.pkl")

# Get summary statistics
summary = report.get_summary_stats()
print(f"Total ISINs: {summary['raw_data_shape'][0]}")
print(f"Pivot sheets: {len(report.pivot_data)}")
```

## Data Requirements

### MAG System Data (DataFrame 1)
Required columns:
- `ISIN` - International Securities Identification Number
- `MARKET_PRICE` - Market price
- `CLEAN_BID` - Clean bid price
- `CLEAN_ASK` - Clean ask price
- `DIRTY_BID` - Dirty bid price
- `DIRTY_ASK` - Dirty ask price
- `PRICE_SOURCE_ID` - Source identifier (EMAIL, KANNON, MERCURY, GRIP, SPIDERSSNG, BLOOMBERG, or null)

### Desk Submitted Data (DataFrame 2)
Required columns:
- `ISIN` - International Securities Identification Number
- `RiskPX` - Risk price (Clean bid equivalent)

### K Market Data (Dataframe 3)
Required columns:
- `ISIN` - International Securities Identification Number
- `K_MKT_CLEAN_BID` - K Market clean bid price
- `K_MKT_CLEAN_ASK` - K Market clean ask price

## Analysis Features

### Price Difference Calculations

The system calculates various price differences:

1. **Within MAG Source**:
   - MARKET_PRICE vs CLEAN_BID/ASK differences
   - MARKET_PRICE vs DIRTY_BID/ASK differences
   - Percentage differences for all comparisons

2. **Cross-Source Comparisons**:
   - MAG vs Desk (CLEAN_BID vs RiskPX)
   - MAG vs K Market (CLEAN_BID/ASK vs K_MKT_CLEAN_BID/ASK)
   - KANNON vs K Market (special analysis for KANNON source)

### Break Detection

The system identifies significant price breaks using configurable thresholds:
- Price difference threshold: 0.001 (0.1 basis points)
- Percentage difference threshold: 0.05% (0.05%)

### Missing Price Analysis

Comprehensive tracking of missing prices:
- Missing price flags for each price type
- Source availability analysis
- Missing price percentage calculations

## Integration with Reporting Framework

The `PriceReconciliationReport` class inherits from `BaseReport` and integrates seamlessly with the existing reporting framework:

- Professional Excel formatting with navy headers and white cells
- Multiple export formats (Excel, HTML, JSON, Pickle)
- Consistent interface with other reports in the framework
- Standardized pivot data structure

## Example Output

The Excel report includes the following sheets:

1. **Raw Data** - Complete dataset with all calculations
2. **Price Source Availability** - Data availability summary
3. **Price Difference Statistics** - Statistical analysis
4. **Break Analysis** - Summary of significant breaks
5. **Missing Price Analysis** - Missing data analysis
6. **Cross-Source Comparison** - Detailed comparisons
7. **KANNON vs K Market Analysis** - KANNON-specific analysis
8. **MAG vs Desk Breaks** - Detailed break analysis
9. **MAG vs K Market Breaks** - Detailed break analysis
10. **KANNON vs K Market Breaks** - Detailed break analysis

## Configuration

The system uses configurable thresholds for break detection:

```python
# Default thresholds (can be modified in the code)
price_diff_threshold = 0.001  # 0.1 basis points
pct_diff_threshold = 0.05     # 0.05%
```

## Dependencies

- Python 3.6+
- pandas
- numpy
- xlsxwriter
- datetime
- json
- pickle

## Example Usage

See `example_usage.py` for a complete working example with sample data generation and report creation.

## Notes

- The system assumes data loading is handled by existing APIs in the codebase
- Missing prices are filled with `np.nan` and flagged appropriately
- All calculations handle missing data gracefully
- The system is designed to work with large datasets efficiently
- Excel output uses professional formatting with proper column widths and number formatting 