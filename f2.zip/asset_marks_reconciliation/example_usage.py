"""
Example Usage of Price Reconciliation Report

This module demonstrates how to use the PriceReconciliationReport class
with sample data from the three price sources.
"""

import pandas as pd
import numpy as np
from datetime import datetime
import os

from .price_reconciliation_report import PriceReconciliationReport


def create_sample_data():
    """
    Create sample data for the three price sources.

    Returns:
        Tuple of (mag_df, desk_df, kmkt_df) DataFrames
    """
    # Sample ISINs
    isins = [
        'US912810TM64', 'US912810TN47', 'US912810TP02', 'US912810TQ80', 'US912810TR58',
        'DE0001102309', 'DE0001102317', 'DE0001102325', 'DE0001102333', 'DE0001102341',
        'GB00B24FFK65', 'GB00B24FFL72', 'GB00B24FFM89', 'GB00B24FFN96', 'GB00B24FFP13'
    ]

    # Create MAG system data
    mag_data = []
    price_sources = ['EMAIL', 'KANNON', 'MERCURY', 'GRIP', 'SPIDERSSNG', 'BLOOMBERG', None]

    for i, isin in enumerate(isins):
        base_price = 100.0 + (i * 0.5)  # Varying base prices
        spread = 0.1 + (i * 0.01)  # Varying spreads

        mag_data.append({
            'ISIN': isin,
            'MARKET_PRICE': base_price + np.random.normal(0, 0.05),
            'CLEAN_BID': base_price - spread/2 + np.random.normal(0, 0.02),
            'CLEAN_ASK': base_price + spread/2 + np.random.normal(0, 0.02),
            'DIRTY_BID': base_price - spread/2 + np.random.normal(0, 0.02) + 0.5,  # Add accrued interest
            'DIRTY_ASK': base_price + spread/2 + np.random.normal(0, 0.02) + 0.5,
            'PRICE_SOURCE_ID': np.random.choice(price_sources, p=[0.2, 0.3, 0.15, 0.1, 0.1, 0.1, 0.05])
        })

    mag_df = pd.DataFrame(mag_data)

    # Create Desk submitted data (subset of ISINs)
    desk_isins = isins[:10]  # Only first 10 ISINs
    desk_data = []

    for i, isin in enumerate(desk_isins):
        base_price = 100.0 + (i * 0.5)
        desk_data.append({
            'ISIN': isin,
            'RiskPX': base_price - 0.05 + np.random.normal(0, 0.03)  # Slightly different from MAG
        })

    desk_df = pd.DataFrame(desk_data)

    # Create K Market data (subset of ISINs)
    kmkt_isins = isins[5:12]  # Middle subset
    kmkt_data = []

    for i, isin in enumerate(kmkt_isins):
        base_price = 100.0 + ((i+5) * 0.5)
        spread = 0.1 + ((i+5) * 0.01)

        kmkt_data.append({
            'ISIN': isin,
            'K_MKT_CLEAN_BID': base_price - spread/2 + np.random.normal(0, 0.02),
            'K_MKT_CLEAN_ASK': base_price + spread/2 + np.random.normal(0, 0.02)
        })

    kmkt_df = pd.DataFrame(kmkt_data)

    return mag_df, desk_df, kmkt_df


def create_previous_date_data():
    """
    Create sample data for a previous date to demonstrate time series comparison.

    Returns:
        Tuple of (mag_df, desk_df, kmkt_df) DataFrames for previous date
    """
    # Use the same ISINs but with slightly different prices
    isins = [
        'US912810TM64', 'US912810TN47', 'US912810TP02', 'US912810TQ80', 'US912810TR58',
        'DE0001102309', 'DE0001102317', 'DE0001102325', 'DE0001102333', 'DE0001102341',
        'GB00B24FFK65', 'GB00B24FFL72', 'GB00B24FFM89', 'GB00B24FFN96', 'GB00B24FFP13'
    ]

    # Create MAG system data for previous date
    mag_data = []
    price_sources = ['EMAIL', 'KANNON', 'MERCURY', 'GRIP', 'SPIDERSSNG', 'BLOOMBERG', None]

    for i, isin in enumerate(isins):
        base_price = 100.0 + (i * 0.5) - 0.1  # Slightly lower base prices
        spread = 0.1 + (i * 0.01)

        mag_data.append({
            'ISIN': isin,
            'MARKET_PRICE': base_price + np.random.normal(0, 0.05),
            'CLEAN_BID': base_price - spread/2 + np.random.normal(0, 0.02),
            'CLEAN_ASK': base_price + spread/2 + np.random.normal(0, 0.02),
            'DIRTY_BID': base_price - spread/2 + np.random.normal(0, 0.02) + 0.5,
            'DIRTY_ASK': base_price + spread/2 + np.random.normal(0, 0.02) + 0.5,
            'PRICE_SOURCE_ID': np.random.choice(price_sources, p=[0.2, 0.3, 0.15, 0.1, 0.1, 0.1, 0.05])
        })

    mag_df = pd.DataFrame(mag_data)

    # Create Desk submitted data for previous date
    desk_isins = isins[:10]
    desk_data = []

    for i, isin in enumerate(desk_isins):
        base_price = 100.0 + (i * 0.5) - 0.1
        desk_data.append({
            'ISIN': isin,
            'RiskPX': base_price - 0.05 + np.random.normal(0, 0.03)
        })

    desk_df = pd.DataFrame(desk_data)

    # Create K Market data for previous date
    kmkt_isins = isins[5:12]
    kmkt_data = []

    for i, isin in enumerate(kmkt_isins):
        base_price = 100.0 + ((i+5) * 0.5) - 0.1
        spread = 0.1 + ((i+5) * 0.01)

        kmkt_data.append({
            'ISIN': isin,
            'K_MKT_CLEAN_BID': base_price - spread/2 + np.random.normal(0, 0.02),
            'K_MKT_CLEAN_ASK': base_price + spread/2 + np.random.normal(0, 0.02)
        })

    kmkt_df = pd.DataFrame(kmkt_data)

    return mag_df, desk_df, kmkt_df


def run_price_reconciliation_example():
    """
    Run a complete example of price reconciliation reporting.
    """
    print("Creating sample price data...")
    mag_df, desk_df, kmkt_df = create_sample_data()

    print(f"MAG data: {len(mag_df)} records")
    print(f"Desk data: {len(desk_df)} records")
    print(f"K Market data: {len(kmkt_df)} records")

    # Create the price reconciliation report
    print("\nCreating price reconciliation report...")
    report = PriceReconciliationReport(
        mag_df=mag_df,
        desk_df=desk_df,
        kmkt_df=kmkt_df,
        report_name="Sample Price Reconciliation Report"
    )

    print(f"Normalized data: {len(report.normalized_data)} records")
    print(f"Pivot sheets: {len(report.pivot_data)}")

    # Display summary statistics
    print("\n=== Summary Statistics ===")
    summary = report.get_summary_stats()
    for key, value in summary.items():
        print(f"{key}: {value}")

    # Display break analysis
    print("\n=== Break Analysis ===")
    mag_desk_breaks = report.get_mag_desk_breaks()
    mag_kmkt_breaks = report.get_mag_kmkt_breaks()
    kannon_kmkt_breaks = report.get_kannon_kmkt_breaks()

    print(f"MAG vs Desk breaks: {len(mag_desk_breaks)}")
    print(f"MAG vs K Market breaks: {len(mag_kmkt_breaks)}")
    print(f"KANNON vs K Market breaks: {len(kannon_kmkt_breaks)}")

    # Demonstrate time series comparison
    print("\n=== Time Series Comparison ===")
    prev_mag_df, prev_desk_df, prev_kmkt_df = create_previous_date_data()

    previous_report = PriceReconciliationReport(
        mag_df=prev_mag_df,
        desk_df=prev_desk_df,
        kmkt_df=prev_kmkt_df,
        report_name="Previous Date Price Reconciliation Report"
    )

    # Compare current vs previous
    comparison_data = report.compare_with_previous_date(previous_report, 'DoD')
    print(f"Time series comparison records: {len(comparison_data)}")

    # Get time series summary
    time_series_summary = report.get_time_series_summary(previous_report, 'DoD')
    print(f"Time series summary records: {len(time_series_summary)}")

    # Demonstrate bond type analysis
    print("\n=== Bond Type Analysis ===")
    if 'BOND_TYPE' in report.normalized_data.columns:
        bond_type_analysis = report._create_bond_type_break_analysis()
        print(f"Bond type analysis records: {len(bond_type_analysis)}")
        if len(bond_type_analysis) > 0 and 'Message' not in bond_type_analysis.columns:
            print("Bond types found:")
            for _, row in bond_type_analysis.iterrows():
                print(f"  {row['Bond_Type']}: {row['Total_ISINs']} ISINs, {row['Total_Breaks']} breaks ({row['Break_Rate_%']:.1f}%)")

    # Export reports
    output_dir = "price_reconciliation_outputs"
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Export to Excel
    excel_file = os.path.join(output_dir, f"price_reconciliation_report_{timestamp}.xlsx")
    print(f"\nExporting to Excel: {excel_file}")
    report.to_excel(excel_file)

    # Export to HTML
    html_file = os.path.join(output_dir, f"price_reconciliation_report_{timestamp}.html")
    print(f"Exporting to HTML: {html_file}")
    report.to_html(html_file)

    # Export to JSON
    json_file = os.path.join(output_dir, f"price_reconciliation_report_{timestamp}.json")
    print(f"Exporting to JSON: {json_file}")
    report.to_json(json_file)

    # Export to pickle
    pickle_file = os.path.join(output_dir, f"price_reconciliation_report_{timestamp}.pkl")
    print(f"Exporting to pickle: {pickle_file}")
    report.to_serialised_blob(pickle_file)

    # Create summary plots
    print(f"\nCreating summary plots...")
    plot_files = report.create_summary_plots(output_dir)
    print(f"Created {len(plot_files)} plot files:")
    for plot_name, plot_file in plot_files.items():
        print(f"  {plot_name}: {plot_file}")

    print(f"\nAll reports exported to: {output_dir}")

    return report


def demonstrate_break_analysis():
    """
    Demonstrate specific break analysis functionality.
    """
    print("\n=== Break Analysis Demonstration ===")

    # Create sample data with known breaks
    mag_df, desk_df, kmkt_df = create_sample_data()

    # Introduce some artificial breaks
    mag_df.loc[0, 'CLEAN_BID'] = 105.0  # Large difference
    desk_df.loc[0, 'RiskPX'] = 100.0

    mag_df.loc[1, 'CLEAN_ASK'] = 110.0  # Large difference
    kmkt_df.loc[0, 'K_MKT_CLEAN_ASK'] = 100.0

    report = PriceReconciliationReport(mag_df, desk_df, kmkt_df)

    # Get break analysis
    mag_desk_breaks = report.get_mag_desk_breaks()
    mag_kmkt_breaks = report.get_mag_kmkt_breaks()
    kannon_kmkt_breaks = report.get_kannon_kmkt_breaks()

    print("MAG vs Desk Breaks:")
    if len(mag_desk_breaks) > 0:
        print(mag_desk_breaks[['ISIN', 'CLEAN_BID', 'RiskPX', 'MAG_VS_DESK_CLEAN_BID_DIFF']].head())
    else:
        print("No significant breaks found")

    print("\nMAG vs K Market Breaks:")
    if len(mag_kmkt_breaks) > 0:
        print(mag_kmkt_breaks[['ISIN', 'CLEAN_BID', 'K_MKT_CLEAN_BID', 'MAG_VS_KMKT_CLEAN_BID_DIFF']].head())
    else:
        print("No significant breaks found")

    print("\nKANNON vs K Market Breaks:")
    if len(kannon_kmkt_breaks) > 0:
        print(kannon_kmkt_breaks[['ISIN', 'CLEAN_BID', 'K_MKT_CLEAN_BID', 'KANNON_VS_KMKT_CLEAN_BID_DIFF']].head())
    else:
        print("No significant breaks found")


def demonstrate_new_features():
    """
    Demonstrate the new features added in this iteration.
    """
    print("\n=== New Features Demonstration ===")

    # Create sample data
    mag_df, desk_df, kmkt_df = create_sample_data()

    # Create report
    report = PriceReconciliationReport(mag_df, desk_df, kmkt_df)

    # 1. Demonstrate prefixed raw data
    print("\n1. Prefixed Raw Data:")
    prefixed_data = report._create_prefixed_raw_data()
    print(f"Columns with prefixes: {[col for col in prefixed_data.columns if any(prefix in col for prefix in ['MAG_', 'DESK_', 'KMKT_'])]}")

    # 2. Demonstrate long format data
    print("\n2. Long Format Data:")
    long_data = report._create_long_format_data()
    print(f"Long format records: {len(long_data)}")
    print(f"Unique price sources: {long_data['PRICE_SOURCE'].unique()}")
    print(f"Unique price types: {long_data['PRICE_TYPE'].unique()}")

    # 3. Demonstrate bond type enrichment
    print("\n3. Bond Type Enrichment:")
    if 'BOND_TYPE' in report.normalized_data.columns:
        bond_types = report.normalized_data['BOND_TYPE'].value_counts()
        print("Bond type distribution:")
        for bond_type, count in bond_types.items():
            print(f"  {bond_type}: {count} ISINs")

    # 4. Demonstrate time series comparison
    print("\n4. Time Series Comparison:")
    prev_mag_df, prev_desk_df, prev_kmkt_df = create_previous_date_data()
    previous_report = PriceReconciliationReport(prev_mag_df, prev_desk_df, prev_kmkt_df)

    comparison = report.compare_with_previous_date(previous_report, 'DoD')
    print(f"Time series comparison records: {len(comparison)}")
    if len(comparison) > 0:
        print(f"Price types compared: {comparison['Price_Type'].unique()}")
        print(f"Average absolute change: {comparison['Absolute_Change'].mean():.4f}")
        print(f"Average percentage change: {comparison['Percentage_Change'].mean():.4f}%")


if __name__ == "__main__":
    print("Price Reconciliation Report Example")
    print("=" * 50)

    # Run the main example
    report = run_price_reconciliation_example()

    # Demonstrate break analysis
    demonstrate_break_analysis()

    # Demonstrate new features
    demonstrate_new_features()

    print("\nExample completed successfully!") 