"""
Asset Marks Reconciliation Module

This module provides price reconciliation functionality for bond prices from multiple sources:
1. MAG system CSV file (aggregates prices from other systems)
2. Desk submitted prices for margining purposes to MAG
3. Risk system's market (K Mkt)

The module includes:
- PriceReconciliationReport: Main class for price reconciliation and reporting
- Price comparison and difference calculations
- Excel report generation with multiple sheets
- Integration with the reporting framework
"""

from .price_reconciliation_report import PriceReconciliationReport

__all__ = ['PriceReconciliationReport'] 