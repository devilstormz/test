# Asset Marks Reconciliation Dashboard

This dashboard provides interactive visualization of price reconciliation breaks across multiple price sources (MAG, Desk, K Market) with comprehensive statistics and filtering capabilities.

## Features

### 📊 Interactive Dashboard
- **Real-time Metrics**: Total breaks, break rates, and breakdown by source
- **Interactive Charts**: Pie charts, histograms, bar charts, and trend analysis
- **Filterable Tables**: Search and filter breaks by type, ISIN, and severity
- **Export Capabilities**: Export data in CSV, JSON, and Excel formats

### 🔍 Break Analysis
- **Break Distribution**: Visual breakdown of breaks by type (MAG vs Desk, MAG vs K Market, KANNON vs K Market)
- **Severity Analysis**: Categorization of breaks by severity level (Minor, Low, Medium, High, Critical)
- **Price Difference Distribution**: Histogram showing the distribution of price differences
- **Missing Price Analysis**: Analysis of missing prices across different sources

### 📋 Data Tables
- **Interactive Breaks Table**: Sortable and filterable table with all breaks
- **Raw Data View**: Complete reconciliation data for detailed analysis
- **Search and Filter**: Real-time search by ISIN and filter by break type

### 📈 Detailed Charts
- **Price Sources Distribution**: Analysis of price sources used
- **Time Series Analysis**: Trend analysis over time (when date data available)
- **Coverage Analysis**: Data coverage across different sources

## Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Install Dependencies

```bash
# Navigate to the asset_marks_reconciliation directory
cd trading_analytics_framework/asset_marks_reconciliation

# Install Streamlit dashboard requirements
pip install -r requirements_streamlit.txt

# Install base requirements
pip install -r requirements.txt
```

## Usage

### Option 1: Streamlit Dashboard (Recommended)

1. **Run the Streamlit Dashboard**:
   ```bash
   streamlit run streamlit_dashboard.py
   ```

2. **Access the Dashboard**:
   - Open your web browser
   - Navigate to `http://localhost:8501`
   - The dashboard will load automatically

3. **Data Source Options**:
   - **Mock Data**: Use sample data for demonstration
   - **Upload Files**: Upload your own CSV files (MAG, Desk, K Market)
   - **Previous Report**: Load a previously saved report (.pkl or .json)

### Option 2: Standalone HTML Dashboard

1. **Open the HTML File**:
   - Navigate to `trading_analytics_framework/asset_marks_reconciliation/`
   - Open `html_dashboard.html` in any web browser
   - No server required - works offline

2. **Features Available**:
   - Interactive charts using Plotly.js
   - Data tables with AG-Grid
   - Export functionality
   - Responsive design

## Dashboard Features

### 📊 Overview Tab
- **Key Metrics**: Total breaks, break rates, and source-specific counts
- **Data Coverage**: Coverage statistics across different price sources
- **Break Distribution**: Pie chart showing break distribution by type

### 🔍 Break Analysis Tab
- **Break Severity**: Bar chart showing severity distribution
- **Price Difference Distribution**: Histogram of price differences
- **Missing Price Analysis**: Analysis of missing prices by source

### 📋 Data Tables Tab
- **Interactive Breaks Table**: 
  - Sortable columns
  - Real-time filtering
  - Search functionality
  - Export to CSV
- **Raw Data View**: Complete reconciliation dataset

### 📈 Detailed Charts Tab
- **Price Sources Distribution**: Analysis of price sources used
- **Price Difference Trends**: Trend analysis of price differences
- **Time Series Analysis**: When date data is available

## Data Format

### Required CSV Files (for upload option)

#### MAG System Data (`mag_data.csv`)
```csv
ISIN,MARKET_PRICE,CLEAN_BID,CLEAN_ASK,DIRTY_BID,DIRTY_ASK,PRICE_SOURCE_ID
US912810TM64,100.50,100.45,100.55,100.95,101.05,EMAIL
US912810TN47,101.00,100.95,101.05,101.45,101.55,KANNON
```

#### Desk Data (`desk_data.csv`)
```csv
ISIN,RiskPX
US912810TM64,100.48
US912810TN47,100.98
```

#### K Market Data (`kmkt_data.csv`)
```csv
ISIN,K_MKT_CLEAN_BID,K_MKT_CLEAN_ASK
US912810TM64,100.44,100.56
US912810TN47,100.94,101.06
```

## Export Options

### Streamlit Dashboard
- **Excel Report**: Complete reconciliation report with multiple sheets
- **HTML Report**: Interactive HTML report with embedded charts
- **JSON Report**: Structured data export
- **CSV Export**: Filtered breaks data

### HTML Dashboard
- **CSV Export**: Download breaks data as CSV
- **JSON Export**: Complete dataset as JSON
- **Excel Export**: Data formatted for Excel
- **Report Generation**: Comprehensive JSON report

## Configuration

### Customizing Break Thresholds
You can modify break detection thresholds in the `PriceReconciliationReport` class:

```python
# In price_reconciliation_report.py
class PriceReconciliationReport:
    # Modify these constants to adjust break detection
    BREAK_THRESHOLD_PCT = 0.1  # 0.1% threshold
    BREAK_THRESHOLD_ABS = 0.05  # Absolute threshold
```

### Adding New Visualizations
To add new charts to the dashboard:

1. **Streamlit Dashboard**: Add new chart functions in `streamlit_dashboard.py`
2. **HTML Dashboard**: Add new chart functions in the JavaScript section

## Troubleshooting

### Common Issues

1. **Import Errors**:
   ```bash
   # Ensure you're in the correct directory
   cd trading_analytics_framework/asset_marks_reconciliation
   
   # Install all dependencies
   pip install -r requirements_streamlit.txt
   ```

2. **Streamlit Not Starting**:
   ```bash
   # Check if streamlit is installed
   pip install streamlit
   
   # Run with debug info
   streamlit run streamlit_dashboard.py --logger.level debug
   ```

3. **Data Loading Issues**:
   - Ensure CSV files have the correct column names
   - Check that all required columns are present
   - Verify data types (numeric for prices)

4. **Chart Not Displaying**:
   - Check browser console for JavaScript errors
   - Ensure internet connection for CDN resources
   - Try refreshing the page

### Performance Tips

1. **Large Datasets**:
   - Use data sampling for initial testing
   - Implement pagination for large tables
   - Consider caching for repeated calculations

2. **Memory Usage**:
   - Close unused browser tabs
   - Restart Streamlit if memory usage is high
   - Use data filtering to reduce dataset size

## Development

### Adding New Features

1. **New Chart Type**:
   ```python
   # In streamlit_dashboard.py
   def create_new_chart(report):
       # Your chart creation logic
       fig = px.new_chart_type(data)
       return fig
   ```

2. **New Export Format**:
   ```python
   # Add export function
   def export_to_new_format(data):
       # Export logic
       return exported_data
   ```

3. **New Filter**:
   ```python
   # Add filter in the sidebar
   new_filter = st.sidebar.selectbox("New Filter", options)
   ```

### Testing

```bash
# Run the example usage
python example_usage.py

# Test the dashboard with mock data
streamlit run streamlit_dashboard.py
```

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review the example usage in `example_usage.py`
3. Examine the source code in `price_reconciliation_report.py`

## License

This dashboard is part of the Trading Analytics Framework and follows the same licensing terms. 