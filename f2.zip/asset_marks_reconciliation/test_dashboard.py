"""
Test script for the Asset Marks Reconciliation Dashboard
"""

import sys
import os
import pandas as pd
import numpy as np

# Add the parent directory to the path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_imports():
    """Test that all required modules can be imported."""
    try:
        from asset_marks_reconciliation.price_reconciliation_report import PriceReconciliationReport
        from asset_marks_reconciliation.example_usage import create_sample_data
        print("✅ All imports successful")
        return True
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False

def test_data_creation():
    """Test that sample data can be created."""
    try:
        mag_df, desk_df, kmkt_df = create_sample_data()
        print(f"✅ Sample data created - MAG: {len(mag_df)}, Desk: {len(desk_df)}, K Market: {len(kmkt_df)}")
        return True
    except Exception as e:
        print(f"❌ Data creation error: {e}")
        return False

def test_report_creation():
    """Test that the reconciliation report can be created."""
    try:
        mag_df, desk_df, kmkt_df = create_sample_data()
        report = PriceReconciliationReport(
            mag_df=mag_df,
            desk_df=desk_df,
            kmkt_df=kmkt_df,
            report_name="Test Report"
        )
        print(f"✅ Report created successfully - {len(report.normalized_data)} records")
        return True
    except Exception as e:
        print(f"❌ Report creation error: {e}")
        return False

def test_break_analysis():
    """Test break analysis functionality."""
    try:
        mag_df, desk_df, kmkt_df = create_sample_data()
        report = PriceReconciliationReport(
            mag_df=mag_df,
            desk_df=desk_df,
            kmkt_df=kmkt_df,
            report_name="Test Report"
        )
        
        mag_desk_breaks = report.get_mag_desk_breaks()
        mag_kmkt_breaks = report.get_mag_kmkt_breaks()
        kannon_kmkt_breaks = report.get_kannon_kmkt_breaks()
        
        total_breaks = len(mag_desk_breaks) + len(mag_kmkt_breaks) + len(kannon_kmkt_breaks)
        print(f"✅ Break analysis successful - Total breaks: {total_breaks}")
        return True
    except Exception as e:
        print(f"❌ Break analysis error: {e}")
        return False

def test_streamlit_components():
    """Test Streamlit-specific components."""
    try:
        import streamlit as st
        import plotly.express as px
        import plotly.graph_objects as go
        
        # Test basic Streamlit functionality
        print("✅ Streamlit components available")
        return True
    except ImportError as e:
        print(f"❌ Streamlit components not available: {e}")
        print("   Install with: pip install streamlit plotly")
        return False

def main():
    """Run all tests."""
    print("🧪 Testing Asset Marks Reconciliation Dashboard Components")
    print("=" * 60)
    
    tests = [
        ("Import Test", test_imports),
        ("Data Creation Test", test_data_creation),
        ("Report Creation Test", test_report_creation),
        ("Break Analysis Test", test_break_analysis),
        ("Streamlit Components Test", test_streamlit_components)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n🔍 Running {test_name}...")
        if test_func():
            passed += 1
        else:
            print(f"❌ {test_name} failed")
    
    print("\n" + "=" * 60)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Dashboard should work correctly.")
        print("\n📋 To run the dashboard:")
        print("   streamlit run streamlit_dashboard.py")
        print("\n📋 To view the HTML dashboard:")
        print("   Open html_dashboard.html in your web browser")
    else:
        print("⚠️  Some tests failed. Please check the errors above.")
        print("\n💡 Installation tips:")
        print("   pip install -r requirements_streamlit.txt")
        print("   pip install streamlit plotly pandas numpy")

if __name__ == "__main__":
    main() 