"""
Reporting Framework

This package provides a comprehensive reporting framework for trading analytics.
It includes base report classes, enhanced reports with analysis capabilities,
and column mapping functionality for flexible output formatting.
"""

from trading_analytics_framework.reporting_framework.base_report import BaseReport
from trading_analytics_framework.reporting_framework.enhanced_report import (
    EnhancedReport, BondAnalysisReport, RiskAnalysisReport, FlexibleAnalysisReport
)
from trading_analytics_framework.reporting_framework.column_mapping import (
    ColumnMappingConfig, ColumnMappingRegistry, column_mapping_registry,
    create_trade_data_mapping, create_risk_data_mapping, create_bond_data_mapping
)

__all__ = [
    'BaseReport',
    'EnhancedReport',
    'BondAnalysisReport',
    'RiskAnalysisReport',
    'FlexibleAnalysisReport',
    'ColumnMappingConfig',
    'ColumnMappingRegistry',
    'column_mapping_registry',
    'create_trade_data_mapping',
    'create_risk_data_mapping',
    'create_bond_data_mapping'
] 