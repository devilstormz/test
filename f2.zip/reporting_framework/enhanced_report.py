"""
Enhanced Report classes for trading analytics framework.

This module provides enhanced report classes that integrate with the DataProcessingPipeline
for orchestration and focus on report-specific analysis rather than automatic pivot creation.
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional, Union
from datetime import datetime
from trading_analytics_framework.reporting_framework.base_report import BaseReport
from trading_analytics_framework.trade_pipeline.simple_processor import DataProcessingPipeline
from trading_analytics_framework.trade_pipeline.data_loader import load_risk_data, load_trade_data, load_ref_data
from trading_analytics_framework.trade_pipeline.config import DatabaseType
from trading_analytics_framework.trade_pipeline.base import EnrichmentError, FilterError, DataValidationError
from trading_analytics_framework.reporting_framework.column_mapping import (
    ColumnMappingConfig, column_mapping_registry
)


class EnhancedReport(BaseReport):
    """
    Enhanced report base class that integrates with DataProcessingPipeline.
    
    This class provides orchestration capabilities for data processing
    and focuses on report-specific analysis rather than automatic pivot creation.
    """
    
    def __init__(self, data: pd.DataFrame, report_name: str, 
                 column_mapping: Optional[Union[str, ColumnMappingConfig]] = None,
                 load_date: Optional[datetime] = None):
        """
        Initialize the enhanced report.
        
        Args:
            data: Input DataFrame
            report_name: Name of the report
            column_mapping: Optional column mapping configuration or name
            load_date: Optional load date for market data dependent operations
        """
        # Apply column mapping if provided
        if column_mapping is not None:
            if isinstance(column_mapping, str):
                config = column_mapping_registry.get_config(column_mapping)
            else:
                config = column_mapping
            data = config.apply_to_dataframe(data)
        
        super().__init__(data, report_name)
        self.pipeline = DataProcessingPipeline(load_date=load_date)
        self.analysis_results = {}
        self.column_mapping = column_mapping
        self.load_date = load_date
    
    def apply_column_mapping(self, column_mapping: Union[str, ColumnMappingConfig]) -> None:
        """
        Apply column mapping to the current data.
        
        Args:
            column_mapping: Column mapping configuration or name
        """
        if isinstance(column_mapping, str):
            config = column_mapping_registry.get_config(column_mapping)
        else:
            config = column_mapping
        
        self.data = config.apply_to_dataframe(self.data)
        self.column_mapping = column_mapping
    
    def override_column_name(self, friendly_name: str, override_name: str) -> None:
        """
        Override a column name in the current mapping.
        
        Args:
            friendly_name: Current friendly name to override
            override_name: New friendly name
        """
        if self.column_mapping is not None:
            if isinstance(self.column_mapping, str):
                config = column_mapping_registry.get_config(self.column_mapping)
            else:
                config = self.column_mapping
            
            config.column_overrides[friendly_name] = override_name
            self.data = config.apply_to_dataframe(self.data)
    
    def set_column_order(self, column_order: List[str]) -> None:
        """
        Set the order of columns in the output.
        
        Args:
            column_order: List of column names in desired order
        """
        if self.column_mapping is not None:
            if isinstance(self.column_mapping, str):
                config = column_mapping_registry.get_config(self.column_mapping)
            else:
                config = self.column_mapping
            
            config.column_order = column_order
            self.data = config.apply_to_dataframe(self.data)
    
    def perform_analysis(self) -> Dict[str, Any]:
        """
        Perform report-specific analysis.
        
        This method should be overridden by subclasses to implement
        specific analysis logic for the report.
        
        Returns:
            Dictionary containing analysis results
        """
        # Base implementation - subclasses should override
        self.analysis_results = {
            'data_shape': self.data.shape,
            'columns': list(self.data.columns),
            'summary_stats': self.data.describe().to_dict()
        }
        return self.analysis_results
    
    def export_to_excel(self, filepath: str) -> None:
        """
        Export analysis results to Excel.
        
        Args:
            filepath: Path to save the Excel file
        """
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # Export main data
            self.data.to_excel(writer, sheet_name='Data', index=False)
            
            # Export analysis results
            if self.analysis_results:
                for key, value in self.analysis_results.items():
                    if isinstance(value, pd.DataFrame):
                        value.to_excel(writer, sheet_name=key, index=False)
                    elif isinstance(value, pd.Series):
                        value.to_frame().to_excel(writer, sheet_name=key)
                    else:
                        # Convert to DataFrame for export
                        pd.DataFrame([value]).to_excel(writer, sheet_name=key, index=False)
    
    def export_to_html(self, filepath: str) -> None:
        """
        Export analysis results to HTML.
        
        Args:
            filepath: Path to save the HTML file
        """
        html_content = f"""
        <html>
        <head>
            <title>{self.report_name}</title>
            <style>
                table {{ border-collapse: collapse; width: 100%; }}
                th, td {{ border: 1px solid black; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <h1>{self.report_name}</h1>
            <h2>Data</h2>
            {self.data.to_html()}
        """
        
        if self.analysis_results:
            html_content += "<h2>Analysis Results</h2>"
            for key, value in self.analysis_results.items():
                html_content += f"<h3>{key}</h3>"
                if isinstance(value, (pd.DataFrame, pd.Series)):
                    html_content += value.to_html()
                else:
                    html_content += f"<p>{value}</p>"
        
        html_content += "</body></html>"
        
        with open(filepath, 'w') as f:
            f.write(html_content)
    
    def export_to_json(self, filepath: str) -> None:
        """
        Export analysis results to JSON.
        
        Args:
            filepath: Path to save the JSON file
        """
        import json
        
        export_data = {
            'report_name': self.report_name,
            'data': self.data.to_dict('records'),
            'analysis_results': {}
        }
        
        # Convert analysis results to JSON-serializable format
        for key, value in self.analysis_results.items():
            if isinstance(value, pd.DataFrame):
                export_data['analysis_results'][key] = value.to_dict('records')
            elif isinstance(value, pd.Series):
                export_data['analysis_results'][key] = value.to_dict()
            else:
                export_data['analysis_results'][key] = value
        
        with open(filepath, 'w') as f:
            json.dump(export_data, f, indent=2, default=str)
    
    def export_to_serialised_blob(self, filepath: str) -> None:
        """
        Export analysis results to serialized blob format.
        
        Args:
            filepath: Path to save the serialized file
        """
        import pickle
        
        export_data = {
            'report_name': self.report_name,
            'data': self.data,
            'analysis_results': self.analysis_results,
            'column_mapping': self.column_mapping,
            'load_date': self.load_date
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(export_data, f)


class BondAnalysisReport(EnhancedReport):
    """
    Bond analysis report that performs bond-specific analysis.
    """
    
    def perform_analysis(self) -> Dict[str, Any]:
        """
        Perform bond-specific analysis.
        
        Returns:
            Dictionary containing bond analysis results
        """
        # Use pipeline for data processing
        processed_data = (self.pipeline
                         .set(self.data)
                         .enrich(['tenor_bucketing', 'market_value'])
                         .filter(['remove_non_relevant_prds', 'remove_wash_books'])
                         .get())
        
        # Perform bond-specific analysis
        analysis = {
            'total_bonds': len(processed_data),
            'tenor_distribution': processed_data['tenor_bucket'].value_counts().to_dict(),
            'total_market_value': processed_data['market_value'].sum(),
            'average_market_value': processed_data['market_value'].mean(),
            'currency_distribution': processed_data['currency'].value_counts().to_dict() if 'currency' in processed_data.columns else {},
            'processed_data': processed_data
        }
        
        self.analysis_results = analysis
        return analysis


class RiskAnalysisReport(EnhancedReport):
    """
    Risk analysis report that performs risk-specific analysis.
    """
    
    def perform_analysis(self) -> Dict[str, Any]:
        """
        Perform risk-specific analysis.
        
        Returns:
            Dictionary containing risk analysis results
        """
        # Use pipeline for data processing
        processed_data = (self.pipeline
                         .set(self.data)
                         .enrich(['funding_sources_uses_liquidity'])
                         .filter(['remove_internal_interdesk_trades'])
                         .get())
        
        # Perform risk-specific analysis
        analysis = {
            'total_positions': len(processed_data),
            'funding_sources': processed_data['funding_source'].value_counts().to_dict() if 'funding_source' in processed_data.columns else {},
            'liquidity_uses': processed_data['liquidity_use'].value_counts().to_dict() if 'liquidity_use' in processed_data.columns else {},
            'total_exposure': processed_data['exposure'].sum() if 'exposure' in processed_data.columns else 0,
            'processed_data': processed_data
        }
        
        self.analysis_results = analysis
        return analysis


class FlexibleAnalysisReport(EnhancedReport):
    """
    Flexible analysis report that can be configured for different types of analysis.
    """
    
    def __init__(self, data: pd.DataFrame, report_name: str, 
                 database_type: DatabaseType,
                 enrichments: Optional[List[str]] = None,
                 filters: Optional[List[str]] = None,
                 column_mapping: Optional[Union[str, ColumnMappingConfig]] = None,
                 load_date: Optional[datetime] = None):
        """
        Initialize flexible analysis report.
        
        Args:
            data: Input DataFrame
            report_name: Name of the report
            database_type: Type of database the data came from
            enrichments: Optional list of enrichment names to apply
            filters: Optional list of filter names to apply
            column_mapping: Optional column mapping configuration or name
            load_date: Optional load date for market data dependent operations
        """
        # Auto-select column mapping based on database type if not provided
        if column_mapping is None:
            if database_type == DatabaseType.TRADEDB:
                column_mapping = 'trade_data'
            elif database_type == DatabaseType.RISKDB:
                column_mapping = 'risk_data'
            elif database_type == DatabaseType.REFDB:
                column_mapping = 'bond_data'
        
        super().__init__(data, report_name, column_mapping, load_date)
        self.database_type = database_type
        self.enrichments = enrichments or []
        self.filters = filters or []
    
    def perform_analysis(self) -> Dict[str, Any]:
        """
        Perform flexible analysis based on configuration.
        
        Returns:
            Dictionary containing analysis results
        """
        # Use pipeline for data processing
        pipeline = self.pipeline.set(self.data)
        
        if self.enrichments:
            pipeline = pipeline.enrich(self.enrichments)
        
        if self.filters:
            pipeline = pipeline.filter(self.filters)
        
        processed_data = pipeline.get()
        
        # Perform general analysis
        analysis = {
            'database_type': self.database_type.value,
            'total_records': len(processed_data),
            'columns': list(processed_data.columns),
            'data_types': processed_data.dtypes.to_dict(),
            'missing_values': processed_data.isnull().sum().to_dict(),
            'processed_data': processed_data
        }
        
        # Add summary statistics for numeric columns
        numeric_cols = processed_data.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            analysis['numeric_summary'] = processed_data[numeric_cols].describe().to_dict()
        
        self.analysis_results = analysis
        return analysis
