"""
Base Report Class

This module provides the base class for all reports in the reporting framework.
It includes abstract methods for different export formats and Excel formatting utilities.
"""

import pandas as pd
import numpy as np
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Union
import json
import pickle
from datetime import datetime
import xlsxwriter
# Note: Using xlsxwriter for Excel formatting instead of openpyxl


class BaseReport(ABC):
    """
    Abstract base class for all reports in the reporting framework.
    
    This class provides a common interface for creating reports with different export formats.
    Every report should contain a "Raw Data" tab and another "Pivot" tab.
    
    Attributes:
        data (pd.DataFrame): The raw data for the report
        pivot_data (pd.DataFrame): The pivot/summary data for the report
        report_name (str): Name of the report
        created_at (datetime): Timestamp when the report was created
    """
    
    def __init__(self, data: pd.DataFrame, report_name: str = "Report"):
        """
        Initialize the base report.
        
        Args:
            data: The raw data DataFrame
            report_name: Name of the report
        """
        self.data = data.copy()
        self.pivot_data = self._create_pivot_data()
        self.report_name = report_name
        self.created_at = datetime.now()
    
    def __str__(self) -> str:
        """String representation of the report."""
        return f"{self.report_name} (Created: {self.created_at.strftime('%Y-%m-%d %H:%M:%S')})"
    
    def __repr__(self) -> str:
        """Detailed string representation of the report."""
        if isinstance(self.pivot_data, dict):
            pivot_info = f"pivot_sheets={len(self.pivot_data)}"
        else:
            pivot_info = f"pivot_shape={self.pivot_data.shape}"
        
        return (f"{self.__class__.__name__}(data_shape={self.data.shape}, "
                f"{pivot_info}, name='{self.report_name}')")
    
    @abstractmethod
    def _create_pivot_data(self):
        """
        Create pivot/summary data from the raw data.
        
        This method should be implemented by subclasses to create appropriate
        pivot tables or summary statistics based on the specific report requirements.
        
        Returns:
            DataFrame or Dict containing the pivot/summary data
        """
        pass
    
    @abstractmethod
    def to_excel(self, filepath: str) -> None:
        """
        Export the report to Excel format with professional formatting.
        
        Args:
            filepath: Path where the Excel file should be saved
        """
        pass
    
    @abstractmethod
    def to_html(self, filepath: str) -> None:
        """
        Export the report to HTML format.
        
        Args:
            filepath: Path where the HTML file should be saved
        """
        pass
    
    @abstractmethod
    def to_json(self, filepath: str) -> None:
        """
        Export the report to JSON format.
        
        Args:
            filepath: Path where the JSON file should be saved
        """
        pass
    
    @abstractmethod
    def to_serialised_blob(self, filepath: str) -> None:
        """
        Export the report as a serialized blob (pickle format).
        
        Args:
            filepath: Path where the serialized blob should be saved
        """
        pass
    
    def _apply_excel_formatting(self, workbook: xlsxwriter.Workbook) -> Dict[str, Any]:
        """
        Create Excel formatting styles according to the specified requirements.
        
        Args:
            workbook: The xlsxwriter workbook object
            
        Returns:
            Dictionary containing the formatting styles
        """
        # Deep navy background (#000080) + white text for headers
        header_format = workbook.add_format({
            'bg_color': '#000080',
            'font_color': 'white',
            'bold': True,
            'align': 'center',
            'valign': 'vcenter'
        })
        
        # White fill for all cells
        cell_format = workbook.add_format({
            'bg_color': 'white',
            'align': 'left',
            'valign': 'vcenter'
        })
        
        # Negative numbers in red with brackets format
        negative_format = workbook.add_format({
            'bg_color': 'white',
            'font_color': 'red',
            'num_format': '_(#,##0.00_);_(#,##0.00_);_(0_);_(@_)',
            'align': 'right',
            'valign': 'vcenter'
        })
        
        # Number format for positive numbers
        number_format = workbook.add_format({
            'bg_color': 'white',
            'num_format': '#,##0.00',
            'align': 'right',
            'valign': 'vcenter'
        })
        
        return {
            'header': header_format,
            'cell': cell_format,
            'negative': negative_format,
            'number': number_format
        }
    
    def _write_dataframe_to_excel(self, worksheet, 
                                 df: pd.DataFrame, start_row: int = 0, 
                                 start_col: int = 0, formats: Dict[str, Any] = None) -> None:
        """
        Write a DataFrame to an Excel worksheet with proper formatting.
        
        Args:
            worksheet: The xlsxwriter worksheet object
            df: DataFrame to write
            start_row: Starting row position
            start_col: Starting column position
            formats: Dictionary of formatting styles
        """
        if formats is None:
            formats = {}
        
        # Write headers
        for col_idx, col_name in enumerate(df.columns):
            worksheet.write(start_row, start_col + col_idx, col_name, formats.get('header', {}))
        
        # Write data
        for row_idx, (_, row) in enumerate(df.iterrows()):
            for col_idx, value in enumerate(row):
                cell_row = start_row + 1 + row_idx
                cell_col = start_col + col_idx
                
                # Determine format based on value type
                if pd.isna(value):
                    worksheet.write(cell_row, cell_col, '', formats.get('cell', {}))
                elif isinstance(value, (int, float)):
                    if value < 0:
                        worksheet.write(cell_row, cell_col, value, formats.get('negative', {}))
                    else:
                        worksheet.write(cell_row, cell_col, value, formats.get('number', {}))
                else:
                    worksheet.write(cell_row, cell_col, value, formats.get('cell', {}))
        
        # Auto-adjust column widths
        for col_idx, col_name in enumerate(df.columns):
            # Calculate max width based on header and data
            max_width = len(str(col_name))
            for _, row in df.iterrows():
                max_width = max(max_width, len(str(row.iloc[col_idx])))
            
            # Set column width (with some padding)
            worksheet.set_column(start_col + col_idx, start_col + col_idx, max_width + 2)
    
    def get_summary_stats(self) -> Dict[str, Any]:
        """
        Get summary statistics for the report data.
        
        Returns:
            Dictionary containing summary statistics
        """
        # Handle both DataFrame and dictionary pivot_data structures
        if isinstance(self.pivot_data, dict):
            pivot_shape = (sum(len(df) for df in self.pivot_data.values()), 
                         sum(len(df.columns) for df in self.pivot_data.values()))
            pivot_columns = [col for df in self.pivot_data.values() for col in df.columns]
            pivot_memory_usage = sum(df.memory_usage(deep=True).sum() for df in self.pivot_data.values())
        else:
            pivot_shape = self.pivot_data.shape
            pivot_columns = list(self.pivot_data.columns)
            pivot_memory_usage = self.pivot_data.memory_usage(deep=True).sum()
        
        return {
            'report_name': self.report_name,
            'created_at': self.created_at.isoformat(),
            'raw_data_shape': self.data.shape,
            'pivot_data_shape': pivot_shape,
            'raw_data_columns': list(self.data.columns),
            'pivot_data_columns': pivot_columns,
            'raw_data_memory_usage': self.data.memory_usage(deep=True).sum(),
            'pivot_data_memory_usage': pivot_memory_usage
        } 