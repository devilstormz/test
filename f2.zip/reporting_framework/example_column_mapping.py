"""
Example of Column Mapping Functionality in Reporting Framework.

This module demonstrates how to use the column mapping system to:
1. Map system column names to report-friendly names
2. Define column ordering for output
3. Override specific column names for individual reports
4. Use predefined configurations for different data types
"""

import pandas as pd
import numpy as np
from typing import Dict, List

from trading_analytics_framework.reporting_framework.enhanced_report import (
    EnhancedReport, BondAnalysisReport, RiskAnalysisReport, FlexibleAnalysisReport
)
from trading_analytics_framework.reporting_framework.column_mapping import (
    ColumnMappingConfig, column_mapping_registry,
    create_trade_data_mapping, create_risk_data_mapping, create_bond_data_mapping
)
from trading_analytics_framework.trade_pipeline.config import DatabaseType


def demonstrate_basic_column_mapping():
    """
    Demonstrate basic column mapping functionality.
    """
    print("=" * 60)
    print("BASIC COLUMN MAPPING DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data with system column names
    sample_data = pd.DataFrame({
        'trade_id': ['T001', 'T002', 'T003'],
        'notional': [1000000, 2000000, 3000000],
        'market_value': [950000, 1950000, 2850000],
        'currency': ['EUR', 'USD', 'GBP'],
        'counterparty': ['CP1', 'CP2', 'CP3'],
        'product': ['SWAP', 'BOND', 'OPTION'],
        'book': ['TRADING', 'WASH', 'TRADING']
    })
    
    print("Original data columns:")
    print(sample_data.columns.tolist())
    print()
    
    # Create a custom column mapping
    custom_mapping = ColumnMappingConfig(
        column_mappings={
            'trade_id': 'Trade ID',
            'notional': 'Notional Amount',
            'market_value': 'Market Value',
            'currency': 'Currency',
            'counterparty': 'Counterparty',
            'product': 'Product Type',
            'book': 'Trading Book'
        },
        column_order=[
            'Trade ID', 'Counterparty', 'Product Type',
            'Notional Amount', 'Market Value', 'Currency', 'Trading Book'
        ]
    )
    
    # Apply mapping to data
    mapped_data = custom_mapping.apply_to_dataframe(sample_data)
    
    print("Mapped data columns:")
    print(mapped_data.columns.tolist())
    print()
    print("Mapped data:")
    print(mapped_data)
    print()


def demonstrate_column_overrides():
    """
    Demonstrate column name overrides.
    """
    print("=" * 60)
    print("COLUMN OVERRIDES DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    sample_data = pd.DataFrame({
        'trade_id': ['T001', 'T002'],
        'notional': [1000000, 2000000],
        'currency': ['EUR', 'USD']
    })
    
    # Get predefined trade data mapping
    trade_mapping = column_mapping_registry.get_config('trade_data')
    
    print("Default trade data mapping:")
    print(f"trade_id -> {trade_mapping.column_mappings['trade_id']}")
    print(f"notional -> {trade_mapping.column_mappings['notional']}")
    print(f"currency -> {trade_mapping.column_mappings['currency']}")
    print()
    
    # Add overrides
    trade_mapping.add_override('Trade ID', 'Transaction ID')
    trade_mapping.add_override('Notional Amount', 'Principal Amount')
    
    print("After overrides:")
    print(f"trade_id -> {trade_mapping.get_final_mapping()['trade_id']}")
    print(f"notional -> {trade_mapping.get_final_mapping()['notional']}")
    print(f"currency -> {trade_mapping.get_final_mapping()['currency']}")
    print()
    
    # Apply to data
    mapped_data = trade_mapping.apply_to_dataframe(sample_data)
    print("Data with overrides:")
    print(mapped_data)
    print()


def demonstrate_predefined_configurations():
    """
    Demonstrate predefined column mapping configurations.
    """
    print("=" * 60)
    print("PREDEFINED CONFIGURATIONS DEMONSTRATION")
    print("=" * 60)
    
    # List available configurations
    print("Available configurations:")
    for config_name in column_mapping_registry.list_configs():
        print(f"  - {config_name}")
    print()
    
    # Demonstrate each configuration
    configs_to_demo = ['trade_data', 'risk_data', 'bond_data']
    
    for config_name in configs_to_demo:
        print(f"\n{config_name.upper()} Configuration:")
        config = column_mapping_registry.get_config(config_name)
        
        print("  Mappings:")
        for system_name, friendly_name in config.column_mappings.items():
            print(f"    {system_name} -> {friendly_name}")
        
        print("  Column Order:")
        print(f"    {config.column_order}")
        print()


def demonstrate_enhanced_report_with_mapping():
    """
    Demonstrate enhanced reports with column mapping.
    """
    print("=" * 60)
    print("ENHANCED REPORT WITH MAPPING DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    sample_data = pd.DataFrame({
        'trade_id': ['T001', 'T002', 'T003'],
        'notional': [1000000, 2000000, 3000000],
        'market_value': [950000, 1950000, 2850000],
        'currency': ['EUR', 'USD', 'GBP'],
        'counterparty': ['CP1', 'CP2', 'CP3']
    })
    
    # Create report with trade data mapping
    report = EnhancedReport(sample_data, "Sample Trade Report", 'trade_data')
    
    print("Report data with mapping:")
    print(report.data)
    print()
    
    # Override a column name
    report.override_column_name('Trade ID', 'Transaction ID')
    print("After overriding 'Trade ID' -> 'Transaction ID':")
    print(report.data)
    print()
    
    # Set custom column order
    report.set_column_order(['Transaction ID', 'Counterparty', 'Notional Amount', 'Market Value', 'Currency'])
    print("After setting custom column order:")
    print(report.data)
    print()


def demonstrate_bond_report_with_overrides():
    """
    Demonstrate bond report with column overrides.
    """
    print("=" * 60)
    print("BOND REPORT WITH OVERRIDES DEMONSTRATION")
    print("=" * 60)
    
    # Create sample bond data
    bond_data = pd.DataFrame({
        'bond_id': ['B001', 'B002', 'B003'],
        'issuer': ['Issuer A', 'Issuer B', 'Issuer C'],
        'rating': ['AAA', 'AA', 'A'],
        'maturity_date': pd.to_datetime(['2025-01-01', '2026-01-01', '2027-01-01']),
        'coupon_rate': [0.05, 0.04, 0.06]
    })
    
    # Create custom column mapping with overrides
    custom_mapping = ColumnMappingConfig(
        column_mappings={
            'bond_id': 'Bond ID',
            'issuer': 'Issuer',
            'rating': 'Credit Rating',
            'maturity_date': 'Maturity Date',
            'coupon_rate': 'Coupon Rate'
        },
        column_order=['Bond ID', 'Issuer', 'Credit Rating', 'Maturity Date', 'Coupon Rate']
    )
    
    # Add overrides
    custom_mapping.add_override('Bond ID', 'Security ID')
    custom_mapping.add_override('Credit Rating', 'Rating')
    
    # Create report with custom mapping
    report = EnhancedReport(bond_data, "Custom Bond Report", custom_mapping)
    
    print("Bond report with custom mapping and overrides:")
    print(report.data)
    print()
    
    # Perform analysis
    analysis = report.perform_analysis()
    print("Analysis results:")
    for key, value in analysis.items():
        print(f"  {key}: {value}")
    print()


def demonstrate_flexible_report_with_mapping():
    """
    Demonstrate flexible report with dynamic column mapping.
    """
    print("=" * 60)
    print("FLEXIBLE REPORT WITH MAPPING DEMONSTRATION")
    print("=" * 60)
    
    # Create sample data
    sample_data = pd.DataFrame({
        'trade_id': ['T001', 'T002'],
        'notional': [1000000, 2000000],
        'currency': ['EUR', 'USD'],
        'counterparty': ['CP1', 'CP2']
    })
    
    # Create custom mapping
    custom_mapping = ColumnMappingConfig(
        column_mappings={
            'trade_id': 'Trade ID',
            'notional': 'Notional Amount',
            'currency': 'Currency',
            'counterparty': 'Counterparty'
        },
        column_order=['Trade ID', 'Counterparty', 'Notional Amount', 'Currency']
    )
    
    # Create flexible report
    report = FlexibleAnalysisReport(
        database_type=DatabaseType.TRADEDB,
        columns=['trade_id', 'notional', 'currency', 'counterparty'],
        report_name="Flexible Trade Report",
        column_mapping=custom_mapping
    )
    
    print("Flexible report with custom mapping:")
    print(report.data)
    print()
    
    # Extend processing and see how mapping is maintained
    print("Extending processing...")
    report.extend_processing(enrichments=['counterparty_mapping'])
    print("After extending processing (mapping maintained):")
    print(report.data)
    print()


def demonstrate_column_mapping_registry():
    """
    Demonstrate column mapping registry functionality.
    """
    print("=" * 60)
    print("COLUMN MAPPING REGISTRY DEMONSTRATION")
    print("=" * 60)
    
    # Create a custom configuration
    custom_config = ColumnMappingConfig(
        column_mappings={
            'custom_field_1': 'Custom Field 1',
            'custom_field_2': 'Custom Field 2',
            'custom_field_3': 'Custom Field 3'
        },
        column_order=['Custom Field 1', 'Custom Field 2', 'Custom Field 3']
    )
    
    # Register the configuration
    column_mapping_registry.register_config('custom_data', custom_config)
    
    print("Registered configurations:")
    for config_name in column_mapping_registry.list_configs():
        print(f"  - {config_name}")
    print()
    
    # Retrieve and use the configuration
    retrieved_config = column_mapping_registry.get_config('custom_data')
    print("Retrieved configuration mappings:")
    for system_name, friendly_name in retrieved_config.column_mappings.items():
        print(f"  {system_name} -> {friendly_name}")
    print()


def main():
    """
    Main function demonstrating column mapping functionality.
    """
    print("COLUMN MAPPING FUNCTIONALITY EXAMPLES")
    print("=" * 80)
    print("This demonstrates the flexible column mapping system that provides:")
    print("1. System column names to report-friendly names mapping")
    print("2. Dynamic column ordering for output")
    print("3. Report-specific overrides of default mappings")
    print("4. Predefined configurations for common data types")
    print("5. Registry system for managing multiple configurations")
    print("=" * 80)
    
    # Run demonstrations
    demonstrate_basic_column_mapping()
    demonstrate_column_overrides()
    demonstrate_predefined_configurations()
    demonstrate_enhanced_report_with_mapping()
    demonstrate_bond_report_with_overrides()
    demonstrate_flexible_report_with_mapping()
    demonstrate_column_mapping_registry()
    
    print("=" * 80)
    print("COLUMN MAPPING FUNCTIONALITY COMPLETE")
    print("=" * 80)
    print("The column mapping system provides:")
    print("✓ Flexible mapping from system to friendly names")
    print("✓ Dynamic column ordering")
    print("✓ Report-specific overrides")
    print("✓ Predefined configurations")
    print("✓ Registry management")
    print("✓ Integration with enhanced reports")
    print("✓ Automatic reapplication after data processing")


if __name__ == "__main__":
    main()
