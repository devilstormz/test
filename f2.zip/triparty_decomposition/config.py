"""
Configuration module for tri-party decomposition framework.
Contains constants, enums, and configuration classes.
"""
from enum import Enum
from collections import namedtuple
from typing import FrozenSet, Dict, Any, List

# Column name constants
class TriPartyColumnNames:
    """Column name constants to avoid hardcoded strings."""
    TRADE_ID = 'trade_id'
    BOOKING_SYSTEM = 'booking_system'
    TRADE_TYPE = 'trade_type'
    DEAL_EXT_ID = 'deal_ext_id'
    COUNTERPARTY = 'counterparty'
    COUNTERPARTY_CODE = 'counterparty_code'
    ISIN = 'isin'
    MARKET_VALUE = 'market_value'
    ACCOUNT_ID = 'account_id'
    COLLATERAL_ISIN = 'collateral_isin'
    TRIPARTY_ISIN = 'triparty_isin'
    COLLATERAL_DIRECTION = 'collateral_direction'
    MAPPING_ID = 'mapping_id'

# Tri-party trade types
class TriPartyTradeType(Enum):
    """Tri-party trade type enumeration."""
    TP = 'TP'        # Tri-party repo
    TPR = 'TPR'      # Tri-party repo
    TPV = 'TPV'      # Tri-party repo variant
    TR = 'TR'        # Tri-party reverse repo
    TRV = 'TRV'      # Tri-party reverse repo variant
    TPB = 'TPB'      # Tri-party repo
    TPL = 'TPL'      # Tri-party repo

# Collateral direction
class CollateralDirection(Enum):
    """Collateral direction enumeration."""
    RECEIVED = 'received'
    GIVEN = 'given'

# Booking system
class BookingSystem(Enum):
    """Booking system enumeration."""
    MAG = 'MAG'

# Configuration for tri-party decomposition
TriPartyConfig = namedtuple('TriPartyConfig', [
    'enable_regex_extraction',
    'enable_network_analysis',
    'enable_agent_mapping'
])

# Regex patterns for trade ID extraction
TRADE_ID_PATTERN = r'MAG:([^.]+)\.([^.]+)'
TRIPARTY_ISIN_PATTERN = r'TRIP\d+'

# Tri-party trade types set for filtering
TRIPARTY_TRADE_TYPES = frozenset([
    TriPartyTradeType.TP.value,
    TriPartyTradeType.TPR.value,
    TriPartyTradeType.TPV.value,
    TriPartyTradeType.TR.value,
    TriPartyTradeType.TRV.value,
    TriPartyTradeType.TPB.value,
    TriPartyTradeType.TPL.value
]) 