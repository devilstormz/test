"""
Network analysis for tri-party decomposition using networkx.
Represents the tree structure of tri-party ISIN to collateral ISIN mappings.
"""
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from typing import Dict, List, Optional, Tuple, Any
from trading_analytics_framework.triparty_decomposition.config import TriPartyColumnNames
from trading_analytics_framework.triparty_decomposition.mapping import TriPartyMapper


class TriPartyNetworkAnalyzer:
    """
    Network analysis class for tri-party decomposition.
    
    This class uses networkx to create and analyze the network structure
    of tri-party ISIN to collateral ISIN mappings.
    """
    
    def __init__(self, mapper: TriPartyMapper):
        """
        Initialize the network analyzer.
        
        Args:
            mapper: TriPartyMapper instance with the mappings
        """
        self.mapper = mapper
        self.graph = nx.DiGraph()
        self._build_network()
    
    def _build_network(self):
        """Build the network graph from the mappings."""
        for mapping in self.mapper.mappings:
            # Add nodes
            self.graph.add_node(mapping.triparty_isin, 
                              node_type='triparty',
                              market_value=mapping.market_value)
            self.graph.add_node(mapping.collateral_isin, 
                              node_type='collateral',
                              market_value=mapping.market_value)
            
            # Add edge
            self.graph.add_edge(mapping.triparty_isin, 
                              mapping.collateral_isin,
                              trade_id=mapping.trade_id,
                              counterparty=mapping.counterparty,
                              direction=mapping.direction.value,
                              market_value=mapping.market_value,
                              mapping_id=mapping.mapping_id)
    
    def get_network_summary(self) -> Dict[str, Any]:
        """
        Get summary statistics for the network.
        
        Returns:
            Dictionary with network statistics
        """
        if not self.graph.nodes():
            return {}
        
        return {
            'num_nodes': self.graph.number_of_nodes(),
            'num_edges': self.graph.number_of_edges(),
            'num_triparty_nodes': len([n for n, d in self.graph.nodes(data=True) 
                                     if d.get('node_type') == 'triparty']),
            'num_collateral_nodes': len([n for n, d in self.graph.nodes(data=True) 
                                       if d.get('node_type') == 'collateral']),
            'is_connected': nx.is_connected(self.graph.to_undirected()) if self.graph.nodes() else False,
            'num_components': nx.number_connected_components(self.graph.to_undirected()) if self.graph.nodes() else 0
        }
    
    def get_triparty_subgraph(self, triparty_isin: str) -> nx.DiGraph:
        """
        Get subgraph for a specific tri-party ISIN.
        
        Args:
            triparty_isin: The tri-party ISIN to filter by
            
        Returns:
            Subgraph containing the tri-party ISIN and its connected collateral ISINs
        """
        if triparty_isin not in self.graph:
            return nx.DiGraph()
        
        # Get all nodes connected to this tri-party ISIN
        connected_nodes = [triparty_isin]
        for neighbor in self.graph.neighbors(triparty_isin):
            connected_nodes.append(neighbor)
        
        return self.graph.subgraph(connected_nodes)
    
    def get_collateral_subgraph(self, collateral_isin: str) -> nx.DiGraph:
        """
        Get subgraph for a specific collateral ISIN.
        
        Args:
            collateral_isin: The collateral ISIN to filter by
            
        Returns:
            Subgraph containing the collateral ISIN and its connected tri-party ISINs
        """
        if collateral_isin not in self.graph:
            return nx.DiGraph()
        
        # Get all nodes connected to this collateral ISIN
        connected_nodes = [collateral_isin]
        for predecessor in self.graph.predecessors(collateral_isin):
            connected_nodes.append(predecessor)
        
        return self.graph.subgraph(connected_nodes)
    
    def get_centrality_measures(self) -> pd.DataFrame:
        """
        Calculate centrality measures for all nodes.
        
        Returns:
            DataFrame with centrality measures for each node
        """
        if not self.graph.nodes():
            return pd.DataFrame()
        
        # Calculate different centrality measures
        degree_centrality = nx.degree_centrality(self.graph)
        betweenness_centrality = nx.betweenness_centrality(self.graph)
        closeness_centrality = nx.closeness_centrality(self.graph)
        
        # Combine into DataFrame
        centrality_data = []
        for node in self.graph.nodes():
            node_data = self.graph.nodes[node]
            centrality_data.append({
                'node': node,
                'node_type': node_data.get('node_type', 'unknown'),
                'market_value': node_data.get('market_value', 0.0),
                'degree_centrality': degree_centrality.get(node, 0.0),
                'betweenness_centrality': betweenness_centrality.get(node, 0.0),
                'closeness_centrality': closeness_centrality.get(node, 0.0)
            })
        
        return pd.DataFrame(centrality_data)
    
    def get_most_connected_nodes(self, top_n: int = 10) -> pd.DataFrame:
        """
        Get the most connected nodes in the network.
        
        Args:
            top_n: Number of top nodes to return
            
        Returns:
            DataFrame with the most connected nodes
        """
        centrality_df = self.get_centrality_measures()
        if centrality_df.empty:
            return pd.DataFrame()
        
        # Sort by degree centrality and return top N
        return centrality_df.nlargest(top_n, 'degree_centrality')
    
    def get_network_paths(self, source: str, target: str) -> List[List[str]]:
        """
        Get all simple paths between two nodes.
        
        Args:
            source: Source node
            target: Target node
            
        Returns:
            List of paths between the nodes
        """
        if source not in self.graph or target not in self.graph:
            return []
        
        return list(nx.all_simple_paths(self.graph, source, target))
    
    def export_network_to_graphml(self, filepath: str) -> None:
        """
        Export the network to GraphML format.
        
        Args:
            filepath: Path where the GraphML file should be saved
        """
        nx.write_graphml(self.graph, filepath)
        print(f"Network exported to GraphML: {filepath}")
    
    def visualize_network(self, 
                         figsize: Tuple[int, int] = (12, 8),
                         node_size: int = 1000,
                         font_size: int = 8) -> plt.Figure:
        """
        Create a visualization of the network.
        
        Args:
            figsize: Figure size (width, height)
            node_size: Size of nodes in the plot
            font_size: Font size for labels
            
        Returns:
            Matplotlib figure object
        """
        if not self.graph.nodes():
            print("No nodes in the network to visualize.")
            return plt.figure()
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Position nodes using spring layout
        pos = nx.spring_layout(self.graph, k=1, iterations=50)
        
        # Draw nodes with different colors for different types
        triparty_nodes = [n for n, d in self.graph.nodes(data=True) 
                         if d.get('node_type') == 'triparty']
        collateral_nodes = [n for n, d in self.graph.nodes(data=True) 
                          if d.get('node_type') == 'collateral']
        
        # Draw tri-party nodes in blue
        nx.draw_networkx_nodes(self.graph, pos, 
                              nodelist=triparty_nodes,
                              node_color='lightblue',
                              node_size=node_size,
                              alpha=0.7)
        
        # Draw collateral nodes in green
        nx.draw_networkx_nodes(self.graph, pos,
                              nodelist=collateral_nodes,
                              node_color='lightgreen',
                              node_size=node_size,
                              alpha=0.7)
        
        # Draw edges
        nx.draw_networkx_edges(self.graph, pos, alpha=0.5, arrows=True)
        
        # Draw labels
        nx.draw_networkx_labels(self.graph, pos, font_size=font_size)
        
        # Add legend
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='lightblue', alpha=0.7, label='Tri-party ISIN'),
            Patch(facecolor='lightgreen', alpha=0.7, label='Collateral ISIN')
        ]
        ax.legend(handles=legend_elements, loc='upper left')
        
        plt.title('Tri-party ISIN to Collateral ISIN Network')
        plt.axis('off')
        
        return fig
    
    def get_network_statistics(self) -> Dict[str, Any]:
        """
        Get comprehensive network statistics.
        
        Returns:
            Dictionary with detailed network statistics
        """
        if not self.graph.nodes():
            return {}
        
        # Basic network properties
        stats = self.get_network_summary()
        
        # Add centrality statistics
        centrality_df = self.get_centrality_measures()
        if not centrality_df.empty:
            stats.update({
                'avg_degree_centrality': centrality_df['degree_centrality'].mean(),
                'avg_betweenness_centrality': centrality_df['betweenness_centrality'].mean(),
                'avg_closeness_centrality': centrality_df['closeness_centrality'].mean(),
                'max_degree_centrality': centrality_df['degree_centrality'].max(),
                'max_betweenness_centrality': centrality_df['betweenness_centrality'].max(),
                'max_closeness_centrality': centrality_df['closeness_centrality'].max()
            })
        
        # Add path statistics
        if self.graph.number_of_nodes() > 1:
            try:
                avg_shortest_path = nx.average_shortest_path_length(self.graph)
                stats['avg_shortest_path_length'] = avg_shortest_path
            except nx.NetworkXError:
                stats['avg_shortest_path_length'] = None
        
        return stats 