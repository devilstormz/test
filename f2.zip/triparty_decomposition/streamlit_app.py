"""
Standalone Streamlit dashboard for tri-party decomposition.
This file can be run independently to avoid import conflicts with Jinja2.

Usage:
    streamlit run streamlit_app.py
"""

import sys
import os
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime

# Add the parent directory to the path to import the framework
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import framework components
from triparty_decomposition.decomposer import TriPartyDecomposer
from triparty_decomposition.network_analysis import TriPartyNetworkAnalyzer
from triparty_decomposition.config import TriPartyColumnNames


def create_mock_triparty_data():
    """Create mock tri-party data for demonstration."""
    mock_data = pd.DataFrame({
        'trade_id': [f'TRIP_{i:03d}' for i in range(1, 21)],
        'booking_system': ['MAG'] * 20,
        'trade_type': ['TP', 'TR', 'TPR', 'TRV', 'TPV', 'TP', 'TR', 'TPR', 'TRV', 'TPV'] * 2,
        'counterparty': [f'CP_{i:03d}' for i in range(1, 21)],
        'counterparty_code': [f'CPTY_{i:03d}' for i in range(1, 21)],
        'isin': ['TRIP001', 'TRIP002', 'TRIP003', 'TRIP004', 'TRIP005'] * 4,
        'market_value': np.random.uniform(1000000, 10000000, 20),
        'trade_date': pd.date_range('2024-01-01', periods=20, freq='D'),
        'maturity_date': pd.date_range('2025-01-01', periods=20, freq='M'),
        'currency': ['USD', 'EUR', 'GBP', 'USD', 'EUR'] * 4,
        'notional': np.random.uniform(1000000, 10000000, 20),
        'deal_ext_id': [
            'MAG:TRIP001.US0001', 'MAG:TRIP002.US0002', 'MAG:TRIP003.US0003',
            'MAG:TRIP004.US0004', 'MAG:TRIP005.US0005', 'MAG:TRIP006.US0001',
            'MAG:TRIP007.US0002', 'MAG:TRIP008.US0003', 'MAG:TRIP009.US0004',
            'MAG:TRIP010.US0005', 'MAG:TRIP011.US0001', 'MAG:TRIP012.US0002',
            'MAG:TRIP013.US0003', 'MAG:TRIP014.US0004', 'MAG:TRIP015.US0005',
            'MAG:TRIP016.US0001', 'MAG:TRIP017.US0002', 'MAG:TRIP018.US0003',
            'MAG:TRIP019.US0004', 'MAG:TRIP020.US0005'
        ]
    })
    return mock_data


def main():
    """Main Streamlit application."""
    try:
        import streamlit as st
    except ImportError:
        print("Streamlit is not installed. Install it with: pip install streamlit")
        return
    
    st.set_page_config(
        page_title="Tri-party Decomposition Dashboard",
        page_icon="📊",
        layout="wide"
    )
    
    st.title("📊 Tri-party Decomposition Dashboard")
    st.markdown("---")
    
    # Sidebar for controls
    st.sidebar.header("Controls")
    
    # Load data
    with st.spinner("Loading tri-party data..."):
        mock_trades = create_mock_triparty_data()
        decomposer = TriPartyDecomposer()
        decomposition_df = decomposer.process_triparty_decomposition(mock_trades)
    
    st.success(f"✅ Loaded {len(mock_trades)} tri-party trades")
    
    # Search functionality
    st.sidebar.subheader("Search")
    search_type = st.sidebar.selectbox(
        "Search by:",
        ["Tri-party ISIN", "Collateral ISIN"]
    )
    
    if search_type == "Tri-party ISIN":
        search_value = st.sidebar.text_input("Enter Tri-party ISIN:", "TRIP001")
        if search_value:
            mappings = decomposer.mapper.get_mappings_by_triparty_isin(search_value)
            if mappings:
                st.sidebar.success(f"Found {len(mappings)} mappings")
            else:
                st.sidebar.warning("No mappings found")
    else:
        search_value = st.sidebar.text_input("Enter Collateral ISIN:", "US0001")
        if search_value:
            mappings = decomposer.mapper.get_mappings_by_collateral_isin(search_value)
            if mappings:
                st.sidebar.success(f"Found {len(mappings)} mappings")
            else:
                st.sidebar.warning("No mappings found")
    
    # Main content
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📈 Decomposition Overview")
        
        # Summary statistics
        summary_stats = decomposer.mapper.get_summary_stats()
        
        col1a, col1b, col1c = st.columns(3)
        with col1a:
            st.metric("Total Mappings", summary_stats.get("total_mappings", 0))
        with col1b:
            st.metric("Unique Tri-party ISINs", summary_stats.get("unique_triparty_isins", 0))
        with col1c:
            st.metric("Unique Collateral ISINs", summary_stats.get("unique_collateral_isins", 0))
        
        # Decomposition table
        st.subheader("🔍 Decomposition Results")
        st.dataframe(decomposition_df, use_container_width=True)
    
    with col2:
        st.subheader("📊 Quick Stats")
        
        # Network analysis
        network_analyzer = TriPartyNetworkAnalyzer(decomposer.mapper)
        network_stats = network_analyzer.get_network_summary()
        
        st.metric("Network Nodes", network_stats.get("total_nodes", 0))
        st.metric("Network Edges", network_stats.get("total_edges", 0))
        st.metric("Connected Components", network_stats.get("connected_components", 0))
        
        # Top connected nodes
        if network_stats.get("total_nodes", 0) > 0:
            top_nodes = network_analyzer.get_most_connected_nodes(5)
            st.subheader("🏆 Top Connected Nodes")
            st.dataframe(top_nodes[['node', 'node_type', 'degree_centrality']], use_container_width=True)
    
    # Detailed analysis tabs
    st.markdown("---")
    tab1, tab2, tab3 = st.tabs(["📋 Collateral Summary", "🔄 Tri-party Summary", "🌐 Network Graph"])
    
    with tab1:
        st.subheader("Collateral Summary")
        collateral_summary = decomposer.get_collateral_summary()
        if not collateral_summary.empty:
            st.dataframe(collateral_summary, use_container_width=True)
            
            # Chart using Plotly
            fig = px.bar(
                collateral_summary.head(10),
                x='collateral_isin',
                y='total_market_value',
                title="Top 10 Collateral ISINs by Market Value",
                color='total_market_value',
                color_continuous_scale='viridis'
            )
            fig.update_layout(
                xaxis_title="Collateral ISIN",
                yaxis_title="Total Market Value",
                showlegend=False
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Additional Seaborn visualization
            st.subheader("Market Value Distribution")
            fig, ax = plt.subplots(figsize=(10, 6))
            sns.histplot(data=collateral_summary, x='total_market_value', bins=15, ax=ax)
            ax.set_title("Distribution of Market Values")
            ax.set_xlabel("Market Value")
            ax.set_ylabel("Frequency")
            st.pyplot(fig)
            plt.close()
    
    with tab2:
        st.subheader("Tri-party Summary")
        triparty_summary = decomposer.get_triparty_summary()
        if not triparty_summary.empty:
            st.dataframe(triparty_summary, use_container_width=True)
            
            # Chart using Plotly
            fig = px.bar(
                triparty_summary.head(10),
                x='triparty_isin',
                y='total_market_value',
                title="Top 10 Tri-party ISINs by Market Value",
                color='total_market_value',
                color_continuous_scale='plasma'
            )
            fig.update_layout(
                xaxis_title="Tri-party ISIN",
                yaxis_title="Total Market Value",
                showlegend=False
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Additional Seaborn correlation plot
            if len(triparty_summary) > 1:
                st.subheader("Market Value vs Trade Count Correlation")
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.scatterplot(data=triparty_summary, x='total_market_value', y='trade_count', ax=ax)
                ax.set_title("Market Value vs Number of Trades")
                ax.set_xlabel("Total Market Value")
                ax.set_ylabel("Number of Trades")
                st.pyplot(fig)
                plt.close()
    
    with tab3:
        st.subheader("Network Graph")
        
        if network_stats.get("total_nodes", 0) > 0:
            # Create network graph visualization
            G = network_analyzer.get_network_graph()
            
            # Get node positions using spring layout
            pos = network_analyzer._get_node_positions(G)
            
            # Create edge trace
            edge_x = []
            edge_y = []
            for edge in G.edges():
                x0, y0 = pos[edge[0]]
                x1, y1 = pos[edge[1]]
                edge_x.extend([x0, x1, None])
                edge_y.extend([y0, y1, None])
            
            edge_trace = go.Scatter(
                x=edge_x, y=edge_y,
                line=dict(width=0.5, color='#888'),
                hoverinfo='none',
                mode='lines')
            
            # Create node trace
            node_x = []
            node_y = []
            node_text = []
            node_color = []
            
            for node in G.nodes():
                x, y = pos[node]
                node_x.append(x)
                node_y.append(y)
                node_text.append(node)
                # Color by node type
                if 'TRIP' in str(node):
                    node_color.append('red')
                else:
                    node_color.append('blue')
            
            node_trace = go.Scatter(
                x=node_x, y=node_y,
                mode='markers+text',
                hoverinfo='text',
                text=node_text,
                textposition="top center",
                marker=dict(
                    size=10,
                    color=node_color,
                    line_width=2))
            
            # Create the figure
            fig = go.Figure(data=[edge_trace, node_trace],
                          layout=go.Layout(
                              title='Tri-party Network Graph',
                              showlegend=False,
                              hovermode='closest',
                              margin=dict(b=20,l=5,r=5,t=40),
                              xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                              yaxis=dict(showgrid=False, zeroline=False, showticklabels=False))
                          )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No network data available")
    
    # Export functionality
    st.markdown("---")
    st.subheader("💾 Export Options")
    
    col_export1, col_export2 = st.columns(2)
    
    with col_export1:
        if st.button("Export Decomposition Report (Excel)"):
            try:
                decomposer.export_decomposition_report('triparty_decomposition_report.xlsx')
                st.success("✅ Report exported: triparty_decomposition_report.xlsx")
            except Exception as e:
                st.error(f"❌ Export failed: {e}")
    
    with col_export2:
        if st.button("Export Network (GraphML)"):
            try:
                network_analyzer.export_network_to_graphml('triparty_network.graphml')
                st.success("✅ Network exported: triparty_network.graphml")
            except Exception as e:
                st.error(f"❌ Export failed: {e}")


if __name__ == "__main__":
    main() 