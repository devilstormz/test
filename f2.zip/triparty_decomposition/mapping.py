"""
Mapping classes for tri-party decomposition framework.
Handles relationships between tri-party ISINs and collateral ISINs.
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from trading_analytics_framework.triparty_decomposition.config import TriPartyColumnNames, CollateralDirection, TRADE_ID_PATTERN, TRIPARTY_ISIN_PATTERN
import re


class TriPartyMapping:
    """
    Class representation of tri-party ISIN to collateral ISIN mapping.
    
    Attributes:
        triparty_isin: The dummy tri-party ISIN (TRIPXXX)
        collateral_isin: The actual collateral ISIN
        trade_id: The original trade ID from the credit repo dataset
        counterparty: The counterparty involved
        market_value: Market value of the collateral
        direction: Whether collateral is received or given
        mapping_id: Unique identifier for this mapping
    """
    
    def __init__(self, triparty_isin: str, collateral_isin: str, trade_id: str, 
                 counterparty: str, market_value: float, direction: CollateralDirection, 
                 mapping_id: str):
        """
        Initialize the TriPartyMapping.
        
        Args:
            triparty_isin: The dummy tri-party ISIN (TRIPXXX)
            collateral_isin: The actual collateral ISIN
            trade_id: The original trade ID from the credit repo dataset
            counterparty: The counterparty involved
            market_value: Market value of the collateral
            direction: Whether collateral is received or given
            mapping_id: Unique identifier for this mapping
        """
        self.triparty_isin = triparty_isin
        self.collateral_isin = collateral_isin
        self.trade_id = trade_id
        self.counterparty = counterparty
        self.market_value = market_value
        self.direction = direction
        self.mapping_id = mapping_id
        
        # Validate the mapping after initialization
        self._validate()
    
    def _validate(self):
        """Validate the mapping after initialization."""
        if not self.triparty_isin.startswith('TRIP'):
            raise ValueError(f"Tri-party ISIN must start with 'TRIP': {self.triparty_isin}")
        if not self.collateral_isin or len(self.collateral_isin) < 2:
            raise ValueError(f"Invalid collateral ISIN: {self.collateral_isin}")


class TriPartyMapper:
    """
    Main class for handling tri-party ISIN to collateral ISIN mappings.
    
    This class provides functionality to:
    1. Extract trade IDs and ISINs from Deal.ExtID using regex
    2. Create mappings between tri-party ISINs and collateral ISINs
    3. Handle one-to-many relationships (one collateral ISIN in multiple tri-party ISINs)
    4. Provide both class and dictionary representations
    """
    
    def __init__(self):
        self.mappings: List[TriPartyMapping] = []
        self.mapping_dict: Dict[str, List[TriPartyMapping]] = {}
        self.collateral_to_triparty: Dict[str, List[str]] = {}
        self.triparty_to_collateral: Dict[str, List[str]] = {}
    
    def extract_trade_id_and_isin(self, deal_ext_id: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Extract trade ID and ISIN from Deal.ExtID using regex.
        
        Args:
            deal_ext_id: The Deal.ExtID string in format 'MAG:TRADE_ID.ISIN'
            
        Returns:
            Tuple of (trade_id, isin) or (None, None) if extraction fails
        """
        if not deal_ext_id:
            return None, None
        
        match = re.match(TRADE_ID_PATTERN, deal_ext_id)
        if match:
            trade_id = match.group(1)
            isin = match.group(2)
            return trade_id, isin
        return None, None
    
    def is_triparty_isin(self, isin: str) -> bool:
        """
        Check if an ISIN is a tri-party dummy ISIN.
        
        Args:
            isin: The ISIN to check
            
        Returns:
            True if it's a tri-party ISIN, False otherwise
        """
        return bool(re.match(TRIPARTY_ISIN_PATTERN, isin))
    
    def create_mapping(self, 
                      triparty_isin: str,
                      collateral_isin: str,
                      trade_id: str,
                      counterparty: str,
                      market_value: float,
                      direction: CollateralDirection) -> TriPartyMapping:
        """
        Create a new tri-party mapping.
        
        Args:
            triparty_isin: The dummy tri-party ISIN
            collateral_isin: The actual collateral ISIN
            trade_id: The original trade ID
            counterparty: The counterparty involved
            market_value: Market value of the collateral
            direction: Whether collateral is received or given
            
        Returns:
            TriPartyMapping object
        """
        mapping_id = f"{triparty_isin}_{collateral_isin}_{trade_id}"
        
        mapping = TriPartyMapping(
            triparty_isin=triparty_isin,
            collateral_isin=collateral_isin,
            trade_id=trade_id,
            counterparty=counterparty,
            market_value=market_value,
            direction=direction,
            mapping_id=mapping_id
        )
        
        self.mappings.append(mapping)
        self._update_dictionaries(mapping)
        
        return mapping
    
    def _update_dictionaries(self, mapping: TriPartyMapping):
        """Update internal dictionary mappings."""
        # Update tri-party to collateral mapping
        if mapping.triparty_isin not in self.triparty_to_collateral:
            self.triparty_to_collateral[mapping.triparty_isin] = []
        if mapping.collateral_isin not in self.triparty_to_collateral[mapping.triparty_isin]:
            self.triparty_to_collateral[mapping.triparty_isin].append(mapping.collateral_isin)
        
        # Update collateral to tri-party mapping
        if mapping.collateral_isin not in self.collateral_to_triparty:
            self.collateral_to_triparty[mapping.collateral_isin] = []
        if mapping.triparty_isin not in self.collateral_to_triparty[mapping.collateral_isin]:
            self.collateral_to_triparty[mapping.collateral_isin].append(mapping.triparty_isin)
        
        # Update mapping dictionary
        key = f"{mapping.triparty_isin}_{mapping.collateral_isin}"
        if key not in self.mapping_dict:
            self.mapping_dict[key] = []
        self.mapping_dict[key].append(mapping)
    
    def get_mappings_by_triparty_isin(self, triparty_isin: str) -> List[TriPartyMapping]:
        """Get all mappings for a specific tri-party ISIN."""
        return [m for m in self.mappings if m.triparty_isin == triparty_isin]
    
    def get_mappings_by_collateral_isin(self, collateral_isin: str) -> List[TriPartyMapping]:
        """Get all mappings for a specific collateral ISIN."""
        return [m for m in self.mappings if m.collateral_isin == collateral_isin]
    
    def get_collateral_isins_for_triparty(self, triparty_isin: str) -> List[str]:
        """Get all collateral ISINs for a tri-party ISIN."""
        return self.triparty_to_collateral.get(triparty_isin, [])
    
    def get_triparty_isins_for_collateral(self, collateral_isin: str) -> List[str]:
        """Get all tri-party ISINs for a collateral ISIN."""
        return self.collateral_to_triparty.get(collateral_isin, [])
    
    def to_dataframe(self) -> pd.DataFrame:
        """
        Convert mappings to a DataFrame representation.
        
        Returns:
            DataFrame with mapping information
        """
        if not self.mappings:
            return pd.DataFrame()
        
        data = []
        for mapping in self.mappings:
            data.append({
                TriPartyColumnNames.TRIPARTY_ISIN: mapping.triparty_isin,
                TriPartyColumnNames.COLLATERAL_ISIN: mapping.collateral_isin,
                TriPartyColumnNames.TRADE_ID: mapping.trade_id,
                TriPartyColumnNames.COUNTERPARTY: mapping.counterparty,
                TriPartyColumnNames.MARKET_VALUE: mapping.market_value,
                TriPartyColumnNames.COLLATERAL_DIRECTION: mapping.direction.value,
                TriPartyColumnNames.MAPPING_ID: mapping.mapping_id
            })
        
        return pd.DataFrame(data)
    
    def get_summary_stats(self) -> Dict[str, Any]:
        """
        Get summary statistics for the mappings.
        
        Returns:
            Dictionary with summary statistics
        """
        if not self.mappings:
            return {}
        
        unique_triparty_isins = len(set(m.triparty_isin for m in self.mappings))
        unique_collateral_isins = len(set(m.collateral_isin for m in self.mappings))
        total_mappings = len(self.mappings)
        
        # Count one-to-many relationships
        collateral_counts = {}
        for mapping in self.mappings:
            collateral_counts[mapping.collateral_isin] = collateral_counts.get(mapping.collateral_isin, 0) + 1
        
        one_to_many_count = sum(1 for count in collateral_counts.values() if count > 1)
        
        return {
            'total_mappings': total_mappings,
            'unique_triparty_isins': unique_triparty_isins,
            'unique_collateral_isins': unique_collateral_isins,
            'one_to_many_relationships': one_to_many_count,
            'avg_collateral_per_triparty': total_mappings / unique_triparty_isins if unique_triparty_isins > 0 else 0,
            'avg_triparty_per_collateral': total_mappings / unique_collateral_isins if unique_collateral_isins > 0 else 0
        } 