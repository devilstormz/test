"""
Tri-party decomposition class that integrates with the trading pipeline.
Handles filtering, extraction, and mapping of tri-party transactions.
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from trading_analytics_framework.triparty_decomposition.config import (
    TriPartyColumnNames, TriPartyTradeType, BookingSystem, 
    CollateralDirection, TRIPARTY_TRADE_TYPES
)
from trading_analytics_framework.triparty_decomposition.mapping import TriPartyMapper, TriPartyMapping



class TriPartyDecomposer:
    """
    Main class for tri-party decomposition and collateral tracking.
    
    This class:
    1. Integrates with the cleaned trading pipeline
    2. Filters dataset by booking_system = MAG and tri-party trade types
    3. Extracts trade IDs and ISINs from Deal.ExtID using regex
    4. Creates mappings between tri-party ISINs and collateral ISINs
    5. Handles one-to-many relationships
    6. Provides DataFrame and class representations
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the tri-party decomposer.
        
        Args:
            config: Configuration dictionary for the decomposer
        """
        self.config = config or {}
        self.mapper = TriPartyMapper()
        self.triparty_trades_df: Optional[pd.DataFrame] = None
        self.decomposition_df: Optional[pd.DataFrame] = None
        self.agent_mapping: Dict[str, str] = {}  # triparty_isin -> account_id
    
    def filter_triparty_trades(self, trades_df: pd.DataFrame) -> pd.DataFrame:
        """
        Filter the trading dataset for tri-party transactions.
        
        Args:
            trades_df: The enriched trading dataset from the pipeline
            
        Returns:
            DataFrame containing only tri-party trades
        """
        # Filter by booking system = MAG
        mag_filter = trades_df[TriPartyColumnNames.BOOKING_SYSTEM] == BookingSystem.MAG.value
        
        # Filter by tri-party trade types
        triparty_filter = trades_df[TriPartyColumnNames.TRADE_TYPE].isin(TRIPARTY_TRADE_TYPES)
        
        # Apply both filters
        filtered_df = trades_df[mag_filter & triparty_filter].copy()
        
        # Add extraction columns
        filtered_df[TriPartyColumnNames.TRADE_ID] = None
        filtered_df[TriPartyColumnNames.COLLATERAL_ISIN] = None
        filtered_df[TriPartyColumnNames.TRIPARTY_ISIN] = None
        
        self.triparty_trades_df = filtered_df
        return filtered_df
    
    def extract_deal_ext_id_components(self, trades_df: pd.DataFrame) -> pd.DataFrame:
        """
        Extract trade ID and ISIN from Deal.ExtID column using regex.
        
        Args:
            trades_df: DataFrame with Deal.ExtID column
            
        Returns:
            DataFrame with extracted trade_id and collateral_isin columns
        """
        if TriPartyColumnNames.DEAL_EXT_ID not in trades_df.columns:
            raise ValueError(f"Column {TriPartyColumnNames.DEAL_EXT_ID} not found in DataFrame")
        
        df = trades_df.copy()
        
        # Extract trade_id and collateral_isin from Deal.ExtID
        extraction_results = df[TriPartyColumnNames.DEAL_EXT_ID].apply(
            self.mapper.extract_trade_id_and_isin
        )
        
        # Split the results into separate columns
        df[TriPartyColumnNames.TRADE_ID] = [result[0] for result in extraction_results]
        df[TriPartyColumnNames.COLLATERAL_ISIN] = [result[1] for result in extraction_results]
        
        # Identify tri-party ISINs (the original ISIN column)
        df[TriPartyColumnNames.TRIPARTY_ISIN] = df['isin'].apply(
            lambda x: x if self.mapper.is_triparty_isin(x) else None
        )
        
        return df
    
    def create_mappings(self, trades_df: pd.DataFrame) -> List[TriPartyMapping]:
        """
        Create tri-party mappings from the filtered and extracted trades.
        
        Args:
            trades_df: DataFrame with extracted trade_id and collateral_isin
            
        Returns:
            List of TriPartyMapping objects
        """
        mappings = []
        
        for _, row in trades_df.iterrows():
            triparty_isin = row.get(TriPartyColumnNames.TRIPARTY_ISIN)
            collateral_isin = row.get(TriPartyColumnNames.COLLATERAL_ISIN)
            trade_id = row.get(TriPartyColumnNames.TRADE_ID)
                    counterparty = row.get(TriPartyColumnNames.COUNTERPARTY)
        market_value = row.get(TriPartyColumnNames.MARKET_VALUE, 0.0)
        
        # Determine collateral direction based on trade type
        trade_type = row.get(TriPartyColumnNames.TRADE_TYPE)
            direction = self._determine_collateral_direction(trade_type)
            
            # Only create mapping if we have valid data
            if (triparty_isin and collateral_isin and trade_id and 
                self.mapper.is_triparty_isin(triparty_isin)):
                
                mapping = self.mapper.create_mapping(
                    triparty_isin=triparty_isin,
                    collateral_isin=collateral_isin,
                    trade_id=trade_id,
                    counterparty=counterparty,
                    market_value=market_value,
                    direction=direction
                )
                mappings.append(mapping)
        
        return mappings
    
    def _determine_collateral_direction(self, trade_type: str) -> CollateralDirection:
        """
        Determine collateral direction based on trade type.
        
        Args:
            trade_type: The trade type (TP, TR, etc.)
            
        Returns:
            CollateralDirection enum value
        """
        # Repo trades (TP, TPR, TPV, TPB, TPL) - we receive collateral
        if trade_type in [TriPartyTradeType.TP.value, TriPartyTradeType.TPR.value,
                         TriPartyTradeType.TPV.value, TriPartyTradeType.TPB.value,
                         TriPartyTradeType.TPL.value]:
            return CollateralDirection.RECEIVED
        
        # Reverse repo trades (TR, TRV) - we give collateral
        elif trade_type in [TriPartyTradeType.TR.value, TriPartyTradeType.TRV.value]:
            return CollateralDirection.GIVEN
        
        # Default to received if unknown
        else:
            return CollateralDirection.RECEIVED
    
    def process_triparty_decomposition(self, trades_df: pd.DataFrame) -> pd.DataFrame:
        """
        Complete tri-party decomposition process.
        
        Args:
            trades_df: The enriched trading dataset from the pipeline
            
        Returns:
            DataFrame with tri-party decomposition results
        """
        # Step 1: Filter for tri-party trades
        triparty_trades = self.filter_triparty_trades(trades_df)
        
        # Step 2: Extract components from Deal.ExtID
        extracted_trades = self.extract_deal_ext_id_components(triparty_trades)
        
        # Step 3: Create mappings
        mappings = self.create_mappings(extracted_trades)
        
        # Step 4: Convert to DataFrame
        self.decomposition_df = self.mapper.to_dataframe()
        
        return self.decomposition_df
    
    def add_agent_mapping(self, agent_file_path: str) -> None:
        """
        Add agent mapping from tri-party ISIN to account ID.
        
        Args:
            agent_file_path: Path to the tri-party agent file
        """
        # Placeholder for agent file processing
        # This would read the agent file and create the mapping
        # For now, we'll create a mock mapping
        
        if self.decomposition_df is not None:
            unique_triparty_isins = self.decomposition_df[TriPartyColumnNames.TRIPARTY_ISIN].unique()
            
            # Create mock account IDs
            for i, triparty_isin in enumerate(unique_triparty_isins):
                self.agent_mapping[triparty_isin] = f"ACCOUNT_{i:04d}"
    
    def get_collateral_summary(self) -> pd.DataFrame:
        """
        Get a summary of collateral given and received.
        
        Returns:
            DataFrame with collateral summary
        """
        if self.decomposition_df is None or self.decomposition_df.empty:
            return pd.DataFrame()
        
        summary = self.decomposition_df.groupby([
            TriPartyColumnNames.COLLATERAL_ISIN,
            TriPartyColumnNames.COLLATERAL_DIRECTION
        ]).agg({
            TriPartyColumnNames.MARKET_VALUE: ['sum', 'count'],
            TriPartyColumnNames.COUNTERPARTY: 'nunique'
        }).round(2)
        
        summary.columns = ['total_market_value', 'num_trades', 'num_counterparties']
        summary = summary.reset_index()
        
        return summary
    
    def get_triparty_summary(self) -> pd.DataFrame:
        """
        Get a summary of tri-party ISINs and their collateral.
        
        Returns:
            DataFrame with tri-party summary
        """
        if self.decomposition_df is None or self.decomposition_df.empty:
            return pd.DataFrame()
        
        summary = self.decomposition_df.groupby([
            TriPartyColumnNames.TRIPARTY_ISIN
        ]).agg({
            TriPartyColumnNames.COLLATERAL_ISIN: 'nunique',
            TriPartyColumnNames.MARKET_VALUE: 'sum',
            TriPartyColumnNames.TRADE_ID: 'count',
            TriPartyColumnNames.COUNTERPARTY: 'nunique'
        }).round(2)
        
        summary.columns = ['num_collateral_isins', 'total_market_value', 'num_trades', 'num_counterparties']
        summary = summary.reset_index()
        
        return summary
    
    def get_one_to_many_relationships(self) -> pd.DataFrame:
        """
        Get collateral ISINs that are used in multiple tri-party ISINs.
        
        Returns:
            DataFrame showing one-to-many relationships
        """
        if self.decomposition_df is None or self.decomposition_df.empty:
            return pd.DataFrame()
        
        # Count tri-party ISINs per collateral ISIN
        collateral_counts = self.decomposition_df.groupby(
            TriPartyColumnNames.COLLATERAL_ISIN
        )[TriPartyColumnNames.TRIPARTY_ISIN].nunique().reset_index()
        
        collateral_counts.columns = [TriPartyColumnNames.COLLATERAL_ISIN, 'num_triparty_isins']
        
        # Filter for one-to-many relationships
        one_to_many = collateral_counts[collateral_counts['num_triparty_isins'] > 1]
        
        return one_to_many.sort_values('num_triparty_isins', ascending=False)
    
    def export_decomposition_report(self, filepath: str) -> None:
        """
        Export the tri-party decomposition to Excel.
        
        Args:
            filepath: Path where the Excel file should be saved
        """
        if self.decomposition_df is None or self.decomposition_df.empty:
            raise ValueError("No decomposition data available. Run process_triparty_decomposition first.")
        
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # Main decomposition data
            self.decomposition_df.to_excel(writer, sheet_name='Decomposition', index=False)
            
            # Collateral summary
            collateral_summary = self.get_collateral_summary()
            if not collateral_summary.empty:
                collateral_summary.to_excel(writer, sheet_name='Collateral_Summary', index=False)
            
            # Tri-party summary
            triparty_summary = self.get_triparty_summary()
            if not triparty_summary.empty:
                triparty_summary.to_excel(writer, sheet_name='TriParty_Summary', index=False)
            
            # One-to-many relationships
            one_to_many = self.get_one_to_many_relationships()
            if not one_to_many.empty:
                one_to_many.to_excel(writer, sheet_name='One_to_Many', index=False)
        
        print(f"Tri-party decomposition report exported to: {filepath}") 