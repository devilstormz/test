"""
Streamlit dashboard for tri-party decomposition.
Provides search functionality and table display for tri-party ISIN decomposition.
"""
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from typing import Optional
from trading_analytics_framework.triparty_decomposition.decomposer import TriPartyDecomposer
from trading_analytics_framework.triparty_decomposition.network_analysis import TriPartyNetworkAnalyzer
from trading_analytics_framework.triparty_decomposition.config import TriPartyColumnNames


class TriPartyDashboard:
    """
    Streamlit dashboard for tri-party decomposition analysis.
    
    Features:
    1. Search by tri-party ISIN or collateral ISIN
    2. Summary table of transactions
    3. Network visualization
    4. Collateral given/received analysis
    """
    
    def __init__(self, decomposer: TriPartyDecomposer):
        """
        Initialize the dashboard.
        
        Args:
            decomposer: TriPartyDecomposer instance with processed data
        """
        self.decomposer = decomposer
        self.network_analyzer = TriPartyNetworkAnalyzer(decomposer.mapper)
    
    def run_dashboard(self):
        """Run the Streamlit dashboard."""
        st.set_page_config(
            page_title="Tri-party Decomposition Dashboard",
            page_icon="📊",
            layout="wide"
        )
        
        st.title("Tri-party ISIN Decomposition Dashboard")
        st.markdown("---")
        
        # Sidebar for search and filters
        self._create_sidebar()
        
        # Main content area
        col1, col2 = st.columns([2, 1])
        
        with col1:
            self._display_search_results()
        
        with col2:
            self._display_summary_stats()
        
        # Network visualization
        st.markdown("---")
        self._display_network_visualization()
        
        # Detailed analysis tabs
        st.markdown("---")
        self._display_analysis_tabs()
    
    def _create_sidebar(self):
        """Create the sidebar with search and filter options."""
        st.sidebar.header("Search & Filters")
        
        # Search options
        search_type = st.sidebar.selectbox(
            "Search by:",
            ["Tri-party ISIN", "Collateral ISIN", "Trade ID"]
        )
        
        # Search input
        search_query = st.sidebar.text_input(
            f"Enter {search_type}:",
            placeholder="e.g., TRIP001 or US0001"
        )
        
        # Store search parameters in session state
        st.session_state.search_type = search_type
        st.session_state.search_query = search_query
        
        # Additional filters
        st.sidebar.markdown("---")
        st.sidebar.header("Filters")
        
        # Direction filter
        direction_filter = st.sidebar.multiselect(
            "Collateral Direction:",
            ["received", "given"],
            default=["received", "given"]
        )
        st.session_state.direction_filter = direction_filter
        
        # Market value range
        if self.decomposer.decomposition_df is not None and not self.decomposer.decomposition_df.empty:
            min_mv = float(self.decomposer.decomposition_df[TriPartyColumnNames.MARKET_VALUE].min())
            max_mv = float(self.decomposer.decomposition_df[TriPartyColumnNames.MARKET_VALUE].max())
            
            mv_range = st.sidebar.slider(
                "Market Value Range:",
                min_value=min_mv,
                max_value=max_mv,
                value=(min_mv, max_mv)
            )
            st.session_state.mv_range = mv_range
    
    def _display_search_results(self):
        """Display search results in the main area."""
        st.header("Search Results")
        
        if not st.session_state.search_query:
            st.info("Enter a search term in the sidebar to view results.")
            return
        
        # Get filtered data based on search
        filtered_data = self._get_filtered_data()
        
        if filtered_data.empty:
            st.warning(f"No results found for '{st.session_state.search_query}'")
            return
        
        # Display results
        st.subheader(f"Results for {st.session_state.search_type}: {st.session_state.search_query}")
        
        # Show summary statistics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Trades", len(filtered_data))
        with col2:
            total_mv = filtered_data[TriPartyColumnNames.MARKET_VALUE].sum()
            st.metric("Total Market Value", f"${total_mv:,.2f}")
        with col3:
            unique_collateral = filtered_data[TriPartyColumnNames.COLLATERAL_ISIN].nunique()
            st.metric("Unique Collateral ISINs", unique_collateral)
        with col4:
            unique_counterparties = filtered_data[TriPartyColumnNames.COUNTERPARTY].nunique()
            st.metric("Unique Counterparties", unique_counterparties)
        
        # Display detailed table
        st.subheader("Transaction Details")
        display_columns = [
            TriPartyColumnNames.TRADE_ID,
            TriPartyColumnNames.TRIPARTY_ISIN,
            TriPartyColumnNames.COLLATERAL_ISIN,
            TriPartyColumnNames.COUNTERPARTY,
            TriPartyColumnNames.MARKET_VALUE,
            TriPartyColumnNames.COLLATERAL_DIRECTION
        ]
        
        st.dataframe(
            filtered_data[display_columns].round(2),
            use_container_width=True
        )
    
    def _display_summary_stats(self):
        """Display summary statistics in the sidebar."""
        st.header("Summary Statistics")
        
        if self.decomposer.decomposition_df is None or self.decomposer.decomposition_df.empty:
            st.info("No decomposition data available.")
            return
        
        # Network statistics
        network_stats = self.network_analyzer.get_network_summary()
        if network_stats:
            st.subheader("Network Statistics")
            st.metric("Total Nodes", network_stats.get('num_nodes', 0))
            st.metric("Total Edges", network_stats.get('num_edges', 0))
            st.metric("Tri-party Nodes", network_stats.get('num_triparty_nodes', 0))
            st.metric("Collateral Nodes", network_stats.get('num_collateral_nodes', 0))
        
        # Mapping statistics
        mapping_stats = self.decomposer.mapper.get_summary_stats()
        if mapping_stats:
            st.subheader("Mapping Statistics")
            st.metric("Total Mappings", mapping_stats.get('total_mappings', 0))
            st.metric("Unique Tri-party ISINs", mapping_stats.get('unique_triparty_isins', 0))
            st.metric("Unique Collateral ISINs", mapping_stats.get('unique_collateral_isins', 0))
            st.metric("One-to-Many Relationships", mapping_stats.get('one_to_many_relationships', 0))
    
    def _display_network_visualization(self):
        """Display network visualization."""
        st.header("Network Visualization")
        
        if self.decomposer.decomposition_df is None or self.decomposer.decomposition_df.empty:
            st.info("No data available for network visualization.")
            return
        
        # Create network visualization using plotly
        fig = self._create_network_plot()
        st.plotly_chart(fig, use_container_width=True)
    
    def _display_analysis_tabs(self):
        """Display detailed analysis in tabs."""
        if self.decomposer.decomposition_df is None or self.decomposer.decomposition_df.empty:
            st.info("No data available for analysis.")
            return
        
        tab1, tab2, tab3, tab4 = st.tabs([
            "Collateral Summary", 
            "Tri-party Summary", 
            "One-to-Many Analysis",
            "Network Analysis"
        ])
        
        with tab1:
            self._display_collateral_summary()
        
        with tab2:
            self._display_triparty_summary()
        
        with tab3:
            self._display_one_to_many_analysis()
        
        with tab4:
            self._display_network_analysis()
    
    def _get_filtered_data(self) -> pd.DataFrame:
        """Get filtered data based on search and filter criteria."""
        if self.decomposer.decomposition_df is None or self.decomposer.decomposition_df.empty:
            return pd.DataFrame()
        
        df = self.decomposer.decomposition_df.copy()
        
        # Apply search filter
        if st.session_state.search_query:
            search_query = st.session_state.search_query.upper()
            
            if st.session_state.search_type == "Tri-party ISIN":
                df = df[df[TriPartyColumnNames.TRIPARTY_ISIN].str.upper().str.contains(search_query, na=False)]
            elif st.session_state.search_type == "Collateral ISIN":
                df = df[df[TriPartyColumnNames.COLLATERAL_ISIN].str.upper().str.contains(search_query, na=False)]
            elif st.session_state.search_type == "Trade ID":
                df = df[df[TriPartyColumnNames.TRADE_ID].str.upper().str.contains(search_query, na=False)]
        
        # Apply direction filter
        if hasattr(st.session_state, 'direction_filter') and st.session_state.direction_filter:
            df = df[df[TriPartyColumnNames.COLLATERAL_DIRECTION].isin(st.session_state.direction_filter)]
        
        # Apply market value filter
        if hasattr(st.session_state, 'mv_range') and st.session_state.mv_range:
            min_mv, max_mv = st.session_state.mv_range
            df = df[
                (df[TriPartyColumnNames.MARKET_VALUE] >= min_mv) & 
                (df[TriPartyColumnNames.MARKET_VALUE] <= max_mv)
            ]
        
        return df
    
    def _create_network_plot(self) -> go.Figure:
        """Create a network plot using plotly."""
        if not self.network_analyzer.graph.nodes():
            return go.Figure()
        
        # Get node positions using networkx
        import networkx as nx
        pos = nx.spring_layout(self.network_analyzer.graph, k=1, iterations=50)
        
        # Prepare data for plotly
        node_x = []
        node_y = []
        node_text = []
        node_color = []
        
        for node in self.network_analyzer.graph.nodes():
            x, y = pos[node]
            node_x.append(x)
            node_y.append(y)
            node_text.append(node)
            
            # Color based on node type
            node_data = self.network_analyzer.graph.nodes[node]
            if node_data.get('node_type') == 'triparty':
                node_color.append('lightblue')
            else:
                node_color.append('lightgreen')
        
        # Prepare edge data
        edge_x = []
        edge_y = []
        
        for edge in self.network_analyzer.graph.edges():
            x0, y0 = pos[edge[0]]
            x1, y1 = pos[edge[1]]
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])
        
        # Create the plot
        fig = go.Figure()
        
        # Add edges
        fig.add_trace(go.Scatter(
            x=edge_x, y=edge_y,
            line=dict(width=0.5, color='#888'),
            hoverinfo='none',
            mode='lines'
        ))
        
        # Add nodes
        fig.add_trace(go.Scatter(
            x=node_x, y=node_y,
            mode='markers+text',
            hoverinfo='text',
            text=node_text,
            textposition="middle center",
            marker=dict(
                size=20,
                color=node_color,
                line=dict(width=2, color='white')
            )
        ))
        
        fig.update_layout(
            title="Tri-party ISIN to Collateral ISIN Network",
            showlegend=False,
            hovermode='closest',
            margin=dict(b=20,l=5,r=5,t=40),
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
        )
        
        return fig
    
    def _display_collateral_summary(self):
        """Display collateral summary analysis."""
        st.subheader("Collateral Summary")
        
        collateral_summary = self.decomposer.get_collateral_summary()
        if not collateral_summary.empty:
            st.dataframe(collateral_summary, use_container_width=True)
            
            # Create visualization
            fig = px.bar(
                collateral_summary,
                x=TriPartyColumnNames.COLLATERAL_ISIN,
                y='total_market_value',
                color=TriPartyColumnNames.COLLATERAL_DIRECTION,
                title="Market Value by Collateral ISIN"
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No collateral summary data available.")
    
    def _display_triparty_summary(self):
        """Display tri-party summary analysis."""
        st.subheader("Tri-party Summary")
        
        triparty_summary = self.decomposer.get_triparty_summary()
        if not triparty_summary.empty:
            st.dataframe(triparty_summary, use_container_width=True)
            
            # Create visualization
            fig = px.scatter(
                triparty_summary,
                x='num_collateral_isins',
                y='total_market_value',
                size='num_trades',
                hover_data=['num_counterparties'],
                title="Tri-party ISINs: Collateral Count vs Market Value"
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No tri-party summary data available.")
    
    def _display_one_to_many_analysis(self):
        """Display one-to-many relationship analysis."""
        st.subheader("One-to-Many Relationships")
        
        one_to_many = self.decomposer.get_one_to_many_relationships()
        if not one_to_many.empty:
            st.dataframe(one_to_many, use_container_width=True)
            
            # Create visualization
            fig = px.bar(
                one_to_many.head(10),
                x=TriPartyColumnNames.COLLATERAL_ISIN,
                y='num_triparty_isins',
                title="Top 10 Collateral ISINs Used in Multiple Tri-party ISINs"
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No one-to-many relationships found.")
    
    def _display_network_analysis(self):
        """Display network analysis."""
        st.subheader("Network Analysis")
        
        centrality_df = self.network_analyzer.get_centrality_measures()
        if not centrality_df.empty:
            st.dataframe(centrality_df, use_container_width=True)
            
            # Create centrality visualization
            fig = px.scatter(
                centrality_df,
                x='degree_centrality',
                y='betweenness_centrality',
                color='node_type',
                size='market_value',
                hover_data=['node'],
                title="Node Centrality Analysis"
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No network analysis data available.")


def run_triparty_dashboard(decomposer: TriPartyDecomposer):
    """
    Run the tri-party decomposition dashboard.
    
    Args:
        decomposer: TriPartyDecomposer instance with processed data
    """
    dashboard = TriPartyDashboard(decomposer)
    dashboard.run_dashboard() 