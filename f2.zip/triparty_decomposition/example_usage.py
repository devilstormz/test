"""
Example usage of the tri-party decomposition framework.
Demonstrates usage of all components without dependency on the trading pipeline.
"""
import pandas as pd
import numpy as np
from trading_analytics_framework.triparty_decomposition.decomposer import TriPartyDecomposer
from trading_analytics_framework.triparty_decomposition.network_analysis import TriPartyNetworkAnalyzer
# Streamlit dashboard import removed to avoid conflicts
# Use the standalone streamlit_app.py instead


def create_mock_triparty_data():
    """
    Create mock tri-party data for demonstration.
    In a real scenario, this would come from your actual data sources.
    """
    # Mock tri-party trades with Deal.ExtID in the required format
    mock_data = pd.DataFrame({
        'trade_id': [f'TRIP_{i:03d}' for i in range(1, 21)],
        'booking_system': ['MAG'] * 20,
        'trade_type': ['TP', 'TR', 'TPR', 'TRV', 'TPV', 'TP', 'TR', 'TPR', 'TRV', 'TPV'] * 2,
        'counterparty': [f'CP_{i:03d}' for i in range(1, 21)],
        'counterparty_code': [f'CPTY_{i:03d}' for i in range(1, 21)],
        'isin': ['TRIP001', 'TRIP002', 'TRIP003', 'TRIP004', 'TRIP005'] * 4,
        'market_value': np.random.uniform(1000000, 10000000, 20),
        'trade_date': pd.date_range('2024-01-01', periods=20, freq='D'),
        'maturity_date': pd.date_range('2025-01-01', periods=20, freq='M'),
        'currency': ['USD', 'EUR', 'GBP', 'USD', 'EUR'] * 4,
        'notional': np.random.uniform(1000000, 10000000, 20),
        # Deal.ExtID column with the required format: MAG:TRADE_ID.ISIN
        'deal_ext_id': [
            'MAG:TRIP001.US0001', 'MAG:TRIP002.US0002', 'MAG:TRIP003.US0003',
            'MAG:TRIP004.US0004', 'MAG:TRIP005.US0005', 'MAG:TRIP006.US0001',
            'MAG:TRIP007.US0002', 'MAG:TRIP008.US0003', 'MAG:TRIP009.US0004',
            'MAG:TRIP010.US0005', 'MAG:TRIP011.US0001', 'MAG:TRIP012.US0002',
            'MAG:TRIP013.US0003', 'MAG:TRIP014.US0004', 'MAG:TRIP015.US0005',
            'MAG:TRIP016.US0001', 'MAG:TRIP017.US0002', 'MAG:TRIP018.US0003',
            'MAG:TRIP019.US0004', 'MAG:TRIP020.US0005'
        ]
    })
    
    return mock_data


def main():
    """Main function demonstrating tri-party decomposition usage."""
    print("=== Tri-party Decomposition Framework Example ===\n")
    
    # Step 1: Create mock data (replace with actual pipeline output)
    print("1. Creating mock tri-party data...")
    mock_trades = create_mock_triparty_data()
    print(f"   Created {len(mock_trades)} mock tri-party trades")
    print(f"   Sample Deal.ExtID: {mock_trades['deal_ext_id'].iloc[0]}")
    print()
    
    # Step 2: Initialize the tri-party decomposer
    print("2. Initializing tri-party decomposer...")
    decomposer = TriPartyDecomposer()
    print("   ✓ TriPartyDecomposer initialized")
    print()
    
    # Step 3: Process tri-party decomposition
    print("3. Processing tri-party decomposition...")
    try:
        decomposition_df = decomposer.process_triparty_decomposition(mock_trades)
        print(f"   ✓ Decomposition completed successfully")
        print(f"   ✓ Found {len(decomposition_df)} mappings")
        print(f"   ✓ Unique tri-party ISINs: {decomposition_df['triparty_isin'].nunique()}")
        print(f"   ✓ Unique collateral ISINs: {decomposition_df['collateral_isin'].nunique()}")
        print()
    except Exception as e:
        print(f"   ✗ Error during decomposition: {e}")
        return
    
    # Step 4: Display sample results
    print("4. Sample decomposition results:")
    print(decomposition_df.head().to_string())
    print()
    
    # Step 5: Generate summaries
    print("5. Generating summaries...")
    
    # Collateral summary
    collateral_summary = decomposer.get_collateral_summary()
    print("   Collateral Summary:")
    print(collateral_summary.to_string())
    print()
    
    # Tri-party summary
    triparty_summary = decomposer.get_triparty_summary()
    print("   Tri-party Summary:")
    print(triparty_summary.to_string())
    print()
    
    # One-to-many relationships
    one_to_many = decomposer.get_one_to_many_relationships()
    if not one_to_many.empty:
        print("   One-to-Many Relationships:")
        print(one_to_many.to_string())
        print()
    
    # Step 6: Network analysis
    print("6. Performing network analysis...")
    network_analyzer = TriPartyNetworkAnalyzer(decomposer.mapper)
    
    # Network statistics
    network_stats = network_analyzer.get_network_summary()
    print("   Network Statistics:")
    for key, value in network_stats.items():
        print(f"     {key}: {value}")
    print()
    
    # Centrality measures
    centrality_df = network_analyzer.get_centrality_measures()
    if not centrality_df.empty:
        print("   Top 5 Most Connected Nodes:")
        top_nodes = network_analyzer.get_most_connected_nodes(5)
        print(top_nodes[['node', 'node_type', 'degree_centrality']].to_string())
        print()
    
    # Step 7: Export results
    print("7. Exporting results...")
    try:
        decomposer.export_decomposition_report('triparty_decomposition_report.xlsx')
        network_analyzer.export_network_to_graphml('triparty_network.graphml')
        print("   ✓ Decomposition report exported: triparty_decomposition_report.xlsx")
        print("   ✓ Network exported: triparty_network.graphml")
        print()
    except Exception as e:
        print(f"   ✗ Error exporting results: {e}")
        print()
    
    # Step 8: Mapping statistics
    print("8. Mapping statistics:")
    mapping_stats = decomposer.mapper.get_summary_stats()
    for key, value in mapping_stats.items():
        print(f"   {key}: {value}")
    print()
    
    # Step 9: Demonstrate search functionality
    print("9. Search functionality examples:")
    
    # Search by tri-party ISIN
    triparty_isin = "TRIP001"
    mappings = decomposer.mapper.get_mappings_by_triparty_isin(triparty_isin)
    print(f"   Mappings for tri-party ISIN '{triparty_isin}': {len(mappings)} found")
    
    # Search by collateral ISIN
    collateral_isin = "US0001"
    mappings = decomposer.mapper.get_mappings_by_collateral_isin(collateral_isin)
    print(f"   Mappings for collateral ISIN '{collateral_isin}': {len(mappings)} found")
    
    # Get one-to-many relationships
    collateral_isins = decomposer.mapper.get_triparty_isins_for_collateral(collateral_isin)
    print(f"   Tri-party ISINs using collateral '{collateral_isin}': {collateral_isins}")
    print()
    
    print("=== Example completed successfully! ===")
    print("\nTo run the Streamlit dashboard:")
    print("1. Install Streamlit: pip install streamlit")
    print("2. Run: streamlit run streamlit_app.py")
    print("\nTo integrate with your actual pipeline:")
    print("1. Replace create_mock_triparty_data() with your actual pipeline output")
    print("2. Ensure your data has the required columns including 'deal_ext_id'")
    print("3. Update the column names if they differ from the expected format")


# Streamlit dashboard function removed - use standalone streamlit_app.py instead


if __name__ == "__main__":
    main() 