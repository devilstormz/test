"""
Standalone Streamlit dashboard for collateral tracking.
This file can be run independently to avoid import conflicts with Jinja2.

Usage:
    streamlit run streamlit_app.py
"""

import sys
import os
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime

# Add the parent directory to the path to import the framework
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import framework components
from collateral_tracking.network_model import CollateralNetwork
from collateral_tracking.tracking import summarize_movements_by_isin, add_unique_group_id


def create_mock_collateral_data():
    """Create mock collateral data for demonstration."""
    mock_data = pd.DataFrame({
        'trade_id': [f'TRADE_{i:03d}' for i in range(1, 31)],
        'booking_system': ['MAG', 'K-E', 'B-E'] * 10,
        'trade_type': ['REP', 'REV', 'BB', 'BL', 'TP', 'TR'] * 5,
        'transaction_type': ['financing', 'funding'] * 15,
        'counterparties': [f'CP_{i:03d}' for i in range(1, 31)],
        'trade_date': pd.date_range('2024-01-01', periods=30, freq='D'),
        'maturity_date': pd.date_range('2025-01-01', periods=30, freq='M'),
        'mv_of_cash': np.random.uniform(1000000, 10000000, 30),
        'mv_of_security': np.random.uniform(1000000, 10000000, 30),
        'isin': ['ISIN001', 'ISIN002', 'ISIN003', 'ISIN004', 'ISIN005'] * 6
    })
    return mock_data


def main():
    """Main Streamlit application."""
    try:
        import streamlit as st
    except ImportError:
        print("Streamlit is not installed. Install it with: pip install streamlit")
        return
    
    st.set_page_config(
        page_title="Collateral Tracking Dashboard",
        page_icon="📈",
        layout="wide"
    )
    
    st.title("📈 Collateral Tracking Dashboard")
    st.markdown("---")
    
    # Sidebar for controls
    st.sidebar.header("Controls")
    
    # Load data
    with st.spinner("Loading collateral data..."):
        mock_trades = create_mock_collateral_data()
        
        # Add unique group ID
        mock_trades = add_unique_group_id(mock_trades)
        
        # Summarize movements by ISIN
        movements_summary = summarize_movements_by_isin(mock_trades)
        
        # Create network model
        network = CollateralNetwork()
        network.build_network_from_data(mock_trades)
    
    st.success(f"✅ Loaded {len(mock_trades)} collateral trades")
    
    # Search functionality
    st.sidebar.subheader("Search")
    search_type = st.sidebar.selectbox(
        "Search by:",
        ["Group ID", "ISIN"]
    )
    
    if search_type == "Group ID":
        search_value = st.sidebar.text_input("Enter Group ID:", "GROUP_001")
        if search_value:
            filtered_data = mock_trades[mock_trades['group_id'] == search_value]
            if not filtered_data.empty:
                st.sidebar.success(f"Found {len(filtered_data)} trades")
            else:
                st.sidebar.warning("No trades found")
    else:
        search_value = st.sidebar.text_input("Enter ISIN:", "ISIN001")
        if search_value:
            filtered_data = mock_trades[mock_trades['isin'] == search_value]
            if not filtered_data.empty:
                st.sidebar.success(f"Found {len(filtered_data)} trades")
            else:
                st.sidebar.warning("No trades found")
    
    # Main content
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📊 Collateral Overview")
        
        # Summary statistics
        col1a, col1b, col1c = st.columns(3)
        with col1a:
            st.metric("Total Trades", len(mock_trades))
        with col1b:
            st.metric("Unique ISINs", mock_trades['isin'].nunique())
        with col1c:
            st.metric("Unique Groups", mock_trades['group_id'].nunique())
        
        # Movements summary table
        st.subheader("🔄 Collateral Movements")
        st.dataframe(movements_summary, use_container_width=True)
    
    with col2:
        st.subheader("📈 Quick Stats")
        
        # Network statistics
        network_stats = network.get_network_summary()
        
        st.metric("Network Nodes", network_stats.get("total_nodes", 0))
        st.metric("Network Edges", network_stats.get("total_edges", 0))
        st.metric("Connected Components", network_stats.get("connected_components", 0))
        
        # Top connected nodes
        if network_stats.get("total_nodes", 0) > 0:
            top_nodes = network.get_most_connected_nodes(5)
            st.subheader("🏆 Top Connected Nodes")
            st.dataframe(top_nodes, use_container_width=True)
    
    # Detailed analysis tabs
    st.markdown("---")
    tab1, tab2, tab3 = st.tabs(["📋 Summary Table", "🔄 Movements Analysis", "🌐 Network Graph"])
    
    with tab1:
        st.subheader("Collateral Summary Table")
        st.dataframe(mock_trades, use_container_width=True)
        
        # Chart by booking system using Plotly
        booking_summary = mock_trades.groupby('booking_system').size().reset_index(name='count')
        fig = px.bar(
            booking_summary,
            x='booking_system',
            y='count',
            title="Trades by Booking System",
            color='count',
            color_continuous_scale='blues'
        )
        fig.update_layout(
            xaxis_title="Booking System",
            yaxis_title="Number of Trades",
            showlegend=False
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        st.subheader("Movements Analysis")
        
        # Chart by ISIN using Plotly
        isin_summary = mock_trades.groupby('isin').agg({
            'mv_of_cash': 'sum',
            'mv_of_security': 'sum',
            'trade_id': 'count'
        }).reset_index()
        
        fig = px.bar(
            isin_summary.head(10),
            x='isin',
            y='mv_of_cash',
            title="Top 10 ISINs by Cash Market Value",
            color='mv_of_cash',
            color_continuous_scale='greens'
        )
        fig.update_layout(
            xaxis_title="ISIN",
            yaxis_title="Cash Market Value",
            showlegend=False
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Additional Seaborn visualization
        st.subheader("Cash vs Security Market Value Comparison")
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.scatterplot(data=isin_summary, x='mv_of_cash', y='mv_of_security', ax=ax)
        ax.set_title("Cash vs Security Market Value")
        ax.set_xlabel("Cash Market Value")
        ax.set_ylabel("Security Market Value")
        st.pyplot(fig)
        plt.close()
        
        # Chart by transaction type using Plotly
        transaction_summary = mock_trades.groupby('transaction_type').size().reset_index(name='count')
        fig = px.pie(
            transaction_summary,
            values='count',
            names='transaction_type',
            title="Trades by Transaction Type",
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        fig.update_traces(textposition='inside', textinfo='percent+label')
        st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        st.subheader("Network Graph")
        
        if network_stats.get("total_nodes", 0) > 0:
            # Create network graph visualization
            G = network.get_network_graph()
            
            # Get node positions using spring layout
            pos = network._get_node_positions(G)
            
            # Create edge trace
            edge_x = []
            edge_y = []
            for edge in G.edges():
                x0, y0 = pos[edge[0]]
                x1, y1 = pos[edge[1]]
                edge_x.extend([x0, x1, None])
                edge_y.extend([y0, y1, None])
            
            edge_trace = go.Scatter(
                x=edge_x, y=edge_y,
                line=dict(width=0.5, color='#888'),
                hoverinfo='none',
                mode='lines')
            
            # Create node trace
            node_x = []
            node_y = []
            node_text = []
            node_color = []
            
            for node in G.nodes():
                x, y = pos[node]
                node_x.append(x)
                node_y.append(y)
                node_text.append(node)
                # Color by node type
                if 'ISIN' in str(node):
                    node_color.append('red')
                else:
                    node_color.append('blue')
            
            node_trace = go.Scatter(
                x=node_x, y=node_y,
                mode='markers+text',
                hoverinfo='text',
                text=node_text,
                textposition="top center",
                marker=dict(
                    size=10,
                    color=node_color,
                    line_width=2))
            
            # Create the figure
            fig = go.Figure(data=[edge_trace, node_trace],
                          layout=go.Layout(
                              title='Collateral Network Graph',
                              showlegend=False,
                              hovermode='closest',
                              margin=dict(b=20,l=5,r=5,t=40),
                              xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                              yaxis=dict(showgrid=False, zeroline=False, showticklabels=False))
                          )
            
            st.plotly_chart(fig, use_container_width=True)
else:
            st.info("No network data available")
    
    # Export functionality
    st.markdown("---")
    st.subheader("💾 Export Options")
    
    col_export1, col_export2 = st.columns(2)
    
    with col_export1:
        if st.button("Export Summary Report (Excel)"):
            try:
                # Create Excel report
                with pd.ExcelWriter('collateral_tracking_report.xlsx', engine='xlsxwriter') as writer:
                    mock_trades.to_excel(writer, sheet_name='Raw Data', index=False)
                    movements_summary.to_excel(writer, sheet_name='Movements Summary', index=False)
                    
                    # Add summary statistics
                    summary_stats = pd.DataFrame({
                        'Metric': ['Total Trades', 'Unique ISINs', 'Unique Groups', 'Total Cash MV', 'Total Security MV'],
                        'Value': [
                            len(mock_trades),
                            mock_trades['isin'].nunique(),
                            mock_trades['group_id'].nunique(),
                            mock_trades['mv_of_cash'].sum(),
                            mock_trades['mv_of_security'].sum()
                        ]
                    })
                    summary_stats.to_excel(writer, sheet_name='Summary Stats', index=False)
                
                st.success("✅ Report exported: collateral_tracking_report.xlsx")
            except Exception as e:
                st.error(f"❌ Export failed: {e}")
    
    with col_export2:
        if st.button("Export Network (GraphML)"):
            try:
                network.export_network_to_graphml('collateral_network.graphml')
                st.success("✅ Network exported: collateral_network.graphml")
            except Exception as e:
                st.error(f"❌ Export failed: {e}")


if __name__ == "__main__":
    main()