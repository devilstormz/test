import pandas as pd

def export_collateral_movements_report(trades_df: pd.DataFrame, filepath: str):
    # Select and rename columns for reporting
    cols = [
        'trade_id', 'booking_system', 'trade_type', 'transaction_type',
        'counterparty', 'counterparty_code', 'trade_date', 'maturity_date',
        'market_value', 'isin', 'group_id'
    ]
    report_df = trades_df[cols]
    report_df.to_excel(filepath, index=False)