import pandas as pd
import networkx as nx

class CollateralNetwork:
    """
    Models collateral movements as a directed network graph using ISIN as the key.
    Nodes: counterparties, edges: collateral movements (with trade info).
    """
    def __init__(self, trades_df: pd.DataFrame):
        self.trades_df = trades_df
        self.graph = nx.MultiDiGraph()
        self._build_graph()

    def _build_graph(self):
        for _, row in self.trades_df.iterrows():
            isin = row.get('isin')
            cpty_from = row.get('counterparty')
            cpty_to = row.get('counterparty_code')
            trade_id = row.get('trade_id')
            mv = row.get('market_value')
            trade_type = row.get('trade_type')
            booking_system = row.get('booking_system')
            tx_type = row.get('transaction_type')
            trade_date = row.get('trade_date')
            maturity_date = row.get('maturity_date')
            # Add nodes and edge
            self.graph.add_edge(
                cpty_from, cpty_to, key=trade_id,
                isin=isin, mv=mv, trade_type=trade_type,
                booking_system=booking_system, tx_type=tx_type,
                trade_date=trade_date, maturity_date=maturity_date
            )

    def get_isin_subgraph(self, isin):
        edges = [(u, v, k) for u, v, k, d in self.graph.edges(keys=True, data=True) if d.get('isin') == isin]
        return self.graph.edge_subgraph(edges).copy()

    def get_movements_summary(self, isin):
        # Returns a DataFrame summarizing all movements for a given ISIN
        records = []
        for u, v, k, d in self.graph.edges(keys=True, data=True):
            if d.get('isin') == isin:
                rec = d.copy()
                rec['from'] = u
                rec['to'] = v
                records.append(rec)
        return pd.DataFrame(records)