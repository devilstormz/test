import pandas as pd
from .network_model import CollateralNetwork

def summarize_movements_by_isin(trades_df: pd.DataFrame) -> pd.DataFrame:
    # Group by ISIN and summarize
    summary = trades_df.groupby('isin').agg({
        'market_value': 'sum',
        'trade_id': 'count'
    }).rename(columns={'trade_id': 'num_trades'}).reset_index()
    return summary

def add_group_id(trades_df: pd.DataFrame) -> pd.DataFrame:
    # Create a unique group id for each ISIN + counterparty group
    trades_df = trades_df.copy()
    trades_df['group_id'] = trades_df.groupby(['isin', 'counterparty', 'counterparty_code']).ngroup()
    return trades_df